import { act, fireEvent, render } from '@testing-library/react'
import { createMemoryRouter, RouterProvider } from 'react-router-dom'
import { describe, expect, it, vi } from 'vitest'
import ContentFrame from './ContentFrame.jsx'
import {
  forwardPrototypeShortcutEvent,
  isEligiblePrototypeShortcutFrame,
} from './prototypeShortcutBridge.js'

function postFromFrame(frame, data) {
  const event = new Event('message')
  Object.defineProperties(event, {
    source: { value: frame.contentWindow },
    origin: { value: window.location.origin },
    data: { value: data },
  })
  window.dispatchEvent(event)
}

describe('ContentFrame route lifetime', () => {
  it('keeps the iframe mounted while a child-approved host POP commits', async () => {
    const router = createMemoryRouter([
      {
        Component: () => <ContentFrame kind="prototype" />,
        children: [
          { path: '/Demo', Component: () => null },
          { path: '/Demo/details', Component: () => null },
        ],
      },
    ], { initialEntries: ['/Demo', '/Demo/details'], initialIndex: 1 })

    const { container, unmount } = render(<RouterProvider router={router} />)
    const frame = container.querySelector('iframe')
    const initialSrc = frame.getAttribute('src')
    const posted = []
    vi.spyOn(frame.contentWindow, 'postMessage').mockImplementation(data => posted.push(data))
    expect(initialSrc).toBe('/Demo/details?_sb_embed=')
    await act(async () => postFromFrame(frame, { type: 'storyboard:embed:ready' }))

    await act(async () => { await router.navigate(-1) })
    expect(router.state.location.pathname).toBe('/Demo/details')
    const request = posted.find(data => data.type === 'storyboard:embed:navigate-request')
    expect(request?.target).toBe('/Demo')
    const blocker = [...router.state.blockers.values()].find(item => item.state === 'blocked')
    expect(blocker).toBeDefined()
    const proceed = vi.spyOn(blocker, 'proceed')
    await act(async () => postFromFrame(frame, {
      type: 'storyboard:embed:navigate', id: 'stale-response',
      src: `${window.location.origin}/Demo`,
    }))
    expect(router.state.location.pathname).toBe('/Demo/details')
    await act(async () => postFromFrame(frame, {
      type: 'storyboard:embed:navigate', id: request.id,
      src: `${window.location.origin}/Demo`,
    }))
    expect(proceed).toHaveBeenCalledOnce()

    expect(router.state.location.pathname).toBe('/Demo')
    expect([...router.state.blockers.values()].every(item => item.state !== 'blocked')).toBe(true)
    expect(container.querySelector('iframe')).toBe(frame)
    expect(frame.getAttribute('src')).toBe(initialSrc)
    unmount()
    postFromFrame(frame, {
      type: 'storyboard:embed:navigate',
      src: `${window.location.origin}/Demo/after-unmount`,
    })
    expect(router.state.location.pathname).toBe('/Demo')
  })

  it('lets a child cancellation keep the host route in place', async () => {
    const router = createMemoryRouter([
      {
        Component: () => <ContentFrame kind="prototype" />,
        children: [
          { path: '/Demo', Component: () => null },
          { path: '/Demo/details', Component: () => null },
        ],
      },
    ], { initialEntries: ['/Demo'] })

    const { container } = render(<RouterProvider router={router} />)
    const frame = container.querySelector('iframe')
    const posted = []
    vi.spyOn(frame.contentWindow, 'postMessage').mockImplementation(data => posted.push(data))
    await act(async () => postFromFrame(frame, { type: 'storyboard:embed:ready' }))
    await act(async () => { await router.navigate('/Demo/details') })
    const request = posted.find(data => data.type === 'storyboard:embed:navigate-request')
    expect(request).toBeDefined()
    await act(async () => postFromFrame(frame, { type: 'storyboard:embed:navigate-cancelled', id: request.id }))
    expect(router.state.location.pathname).toBe('/Demo')
    expect([...router.state.blockers.values()].every(item => item.state !== 'blocked')).toBe(true)
  })
})

function makeShortcutFrame({
  kind = 'prototype',
  marker = true,
  origin = window.location.origin,
  parent = window,
  top = window,
  sandbox = false,
} = {}) {
  const childDocument = document.implementation.createHTMLDocument('child')
  const childWindow = {
    document: childDocument,
    location: { origin },
    parent,
    top,
    postMessage: vi.fn(),
  }
  return {
    childDocument,
    childWindow,
    frame: {
      contentDocument: childDocument,
      contentWindow: childWindow,
      getAttribute: name => name === 'data-hypercanvas-content' && marker ? kind : null,
      hasAttribute: name => name === 'sandbox' && sandbox,
    },
  }
}

function trustedKeydown({ key = 'k', ctrlKey = false, metaKey = true, shiftKey = false, altKey = false } = {}) {
  return {
    isTrusted: true,
    key,
    ctrlKey,
    metaKey,
    shiftKey,
    altKey,
    preventDefault: vi.fn(),
    stopImmediatePropagation: vi.fn(),
  }
}

describe('ContentFrame direct prototype shortcut bridge', () => {
  it('only accepts the direct same-origin unsandboxed prototype frame', () => {
    expect(isEligiblePrototypeShortcutFrame(makeShortcutFrame().frame, window)).toBe(true)
    expect(isEligiblePrototypeShortcutFrame(makeShortcutFrame({ marker: false }).frame, window)).toBe(false)
    expect(isEligiblePrototypeShortcutFrame(makeShortcutFrame({ kind: 'story' }).frame, window, 'story')).toBe(false)
    expect(isEligiblePrototypeShortcutFrame(makeShortcutFrame({ sandbox: true }).frame, window)).toBe(false)
    expect(isEligiblePrototypeShortcutFrame(makeShortcutFrame({ origin: 'https://elsewhere.test' }).frame, window)).toBe(false)
    expect(isEligiblePrototypeShortcutFrame(makeShortcutFrame({ origin: 'null' }).frame, window)).toBe(false)
    expect(isEligiblePrototypeShortcutFrame(makeShortcutFrame({ parent: {} }).frame, window)).toBe(false)
    expect(isEligiblePrototypeShortcutFrame(makeShortcutFrame({ top: {} }).frame, window)).toBe(false)
  })

  it('forwards trusted canonical k/K and consumes the child event only when the host claims it', () => {
    const hostEvents = []
    const hostHandler = event => {
      hostEvents.push(event)
      if (event.key === 'K') event.preventDefault()
    }
    window.document.addEventListener('keydown', hostHandler)

    const claimed = trustedKeydown({ key: 'K', shiftKey: true, ctrlKey: true, metaKey: false })
    expect(forwardPrototypeShortcutEvent(claimed, window)).toBe(true)
    expect(hostEvents).toHaveLength(1)
    expect(hostEvents[0]).toMatchObject({ key: 'K', code: 'KeyK', ctrlKey: true, shiftKey: true })
    expect(claimed.preventDefault).toHaveBeenCalledOnce()
    expect(claimed.stopImmediatePropagation).toHaveBeenCalledOnce()

    const unclaimed = trustedKeydown({ key: 'k' })
    expect(forwardPrototypeShortcutEvent(unclaimed, window)).toBe(false)
    expect(hostEvents).toHaveLength(2)
    expect(hostEvents[1]).toMatchObject({ key: 'k', code: 'KeyK', metaKey: true, shiftKey: false })
    expect(unclaimed.preventDefault).not.toHaveBeenCalled()
    expect(unclaimed.stopImmediatePropagation).not.toHaveBeenCalled()

    expect(forwardPrototypeShortcutEvent({ ...trustedKeydown(), isTrusted: false }, window)).toBe(false)
    expect(forwardPrototypeShortcutEvent(trustedKeydown({ key: 'x' }), window)).toBe(false)
    expect(forwardPrototypeShortcutEvent(trustedKeydown({ altKey: true }), window)).toBe(false)
    expect(hostEvents).toHaveLength(2)

    window.document.removeEventListener('keydown', hostHandler)
  })

  it('rebinds on load and removes the current child listener on navigation and unmount', async () => {
    const router = createMemoryRouter([
      { path: '/Demo/*', Component: () => <ContentFrame kind="prototype" /> },
    ], { initialEntries: ['/Demo'] })
    const { container, unmount } = render(<RouterProvider router={router} />)
    const frame = container.querySelector('iframe')
    const firstDocument = document.implementation.createHTMLDocument('first child')
    Object.defineProperties(frame, {
      contentDocument: { configurable: true, value: firstDocument },
      contentWindow: {
        configurable: true,
        value: {
          document: firstDocument,
          location: {
            origin: window.location.origin,
            href: `${window.location.origin}/Demo?_sb_embed=`,
            pathname: '/Demo',
            search: '?_sb_embed=',
            hash: '',
            replace: vi.fn(),
          },
          parent: window,
          top: window,
          postMessage: vi.fn(),
        },
      },
    })
    const firstAdd = vi.spyOn(firstDocument, 'addEventListener')
    const firstRemove = vi.spyOn(firstDocument, 'removeEventListener')
    fireEvent.load(frame)
    const firstBinding = firstAdd.mock.calls.find(([type]) => type === 'keydown')
    expect(firstBinding).toBeDefined()
    const hostKeydown = vi.fn(event => {
      if (event.key === 'K') event.preventDefault()
    })
    window.document.addEventListener('keydown', hostKeydown)
    const claimed = trustedKeydown({ key: 'K', shiftKey: true })
    firstBinding[1](claimed)
    expect(hostKeydown).toHaveBeenCalledOnce()
    expect(claimed.preventDefault).toHaveBeenCalledOnce()
    const unclaimed = trustedKeydown({ key: 'k' })
    firstBinding[1](unclaimed)
    expect(hostKeydown).toHaveBeenCalledTimes(2)
    expect(unclaimed.preventDefault).not.toHaveBeenCalled()
    window.document.removeEventListener('keydown', hostKeydown)

    await act(async () => { await router.navigate('/Demo/next') })
    expect(firstRemove).toHaveBeenCalledWith('keydown', firstBinding[1], true)

    const secondDocument = document.implementation.createHTMLDocument('next child')
    const secondWindow = {
      document: secondDocument,
      location: {
        origin: window.location.origin,
        href: `${window.location.origin}/Demo?_sb_embed=`,
        pathname: '/Demo/next',
        search: '?_sb_embed=',
        hash: '',
        replace: vi.fn(),
      },
      parent: window,
      top: window,
      postMessage: vi.fn(),
    }
    const secondAdd = vi.spyOn(secondDocument, 'addEventListener')
    const secondRemove = vi.spyOn(secondDocument, 'removeEventListener')
    Object.defineProperties(frame, {
      contentDocument: { configurable: true, value: secondDocument },
      contentWindow: { configurable: true, value: secondWindow },
    })
    fireEvent.load(frame)
    expect(firstRemove).toHaveBeenCalledWith('keydown', firstBinding[1], true)
    const secondBinding = secondAdd.mock.calls.find(([type]) => type === 'keydown')
    expect(secondBinding).toBeDefined()

    unmount()
    expect(secondRemove).toHaveBeenCalledWith('keydown', secondBinding[1], true)
  })
})
