import { useEffect, useRef, useState } from 'react'
import { useBlocker, useLocation, useNavigate } from 'react-router-dom'
import { contentFrameUrl, contentNavigationTarget } from '../canvas/isolation/contentRouting.js'
import { computeEmbedNavigationSrc } from '../../core/embedNavigation.js'
import { bindPrototypeShortcutBridge } from './prototypeShortcutBridge.js'
import styles from './ContentFrame.module.css'

/** Public routes keep the app shell while authored content owns its document. */
export default function ContentFrame({ kind = 'prototype' }) {
  const location = useLocation()
  const navigate = useNavigate()
  const frame = useRef(null)
  const base = import.meta.env.BASE_URL || '/'
  const [initialSrc] = useState(() => contentFrameUrl(location, base))
  const childReady = useRef(false)
  const shortcutCleanup = useRef(null)
  const route = `${location.pathname}${location.search}${location.hash}`
  const pendingNavigation = useRef(null)
  const bypassBlockerFor = useRef(null)
  const blocker = useBlocker(({ nextLocation }) => {
    const next = `${nextLocation.pathname}${nextLocation.search}${nextLocation.hash}`
    if (bypassBlockerFor.current === next) {
      bypassBlockerFor.current = null
      return false
    }
    const currentPrototype = location.pathname.split('/').filter(Boolean)[0]
    const nextPrototype = nextLocation.pathname.split('/').filter(Boolean)[0]
    return Boolean(childReady.current && currentPrototype && currentPrototype === nextPrototype && route !== next)
  })
  const blockerRef = useRef(blocker)
  useEffect(() => { blockerRef.current = blocker }, [blocker])

  useEffect(() => {
    const onNavigate = event => {
      if (event.source !== frame.current?.contentWindow || event.origin !== window.location.origin) return
      const data = event.data
      if (data?.type === 'storyboard:embed:ready') {
        childReady.current = true
        return
      }
      if (data?.type === 'storyboard:embed:navigate-cancelled') {
        if (pendingNavigation.current?.id === data.id && blockerRef.current.state === 'blocked') {
          pendingNavigation.current = null
          blockerRef.current.reset()
        }
        return
      }
      if (data?.type !== 'storyboard:embed:navigate') return
      const target = contentNavigationTarget(data.src, window.location.origin, base)
      if (!target || target === route) return
      const pending = pendingNavigation.current
      if (pending && data.id && data.id !== pending.id) return
      if (pending?.target === target && data.id === pending.id && blockerRef.current.state === 'blocked') {
        pendingNavigation.current = null
        blockerRef.current.proceed()
        return
      }
      if (pending && !data.id) {
        pendingNavigation.current = null
        if (blockerRef.current.state === 'blocked') blockerRef.current.reset()
      }
      // The child has already committed this navigation after its own route
      // blockers settled, so the host must not ask it to leave a second time.
      bypassBlockerFor.current = target
      navigate(target, { replace: data.replace === true })
    }
    window.addEventListener('message', onNavigate)
    return () => window.removeEventListener('message', onNavigate)
  }, [base, navigate, route])

  useEffect(() => {
    if (blocker.state !== 'blocked') return
    const target = `${blocker.location.pathname}${blocker.location.search}${blocker.location.hash}`
    if (pendingNavigation.current?.target === target) return
    const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`
    pendingNavigation.current = { id, target }
    frame.current?.contentWindow?.postMessage({
      type: 'storyboard:embed:navigate-request', id, target,
      replace: blocker.historyAction === 'REPLACE',
    }, window.location.origin)
  }, [blocker])

  useEffect(() => {
    const child = frame.current?.contentWindow
    if (!child) return
    try {
      // Child navigation has already changed its document URL; mirroring the
      // public route must not reload it and discard the component's state.
      if (child.location.href === 'about:blank') return
      const current = computeEmbedNavigationSrc(child.location.pathname, child.location.hash, base, child.location.search)
      if (current !== route) {
        childReady.current = false
        shortcutCleanup.current?.()
        shortcutCleanup.current = null
        child.location.replace(contentFrameUrl(location, base))
      }
    } catch {
      shortcutCleanup.current?.()
      shortcutCleanup.current = null
      frame.current.src = contentFrameUrl(location, base)
    }
  }, [base, location, route])

  const onFrameLoad = () => {
    childReady.current = false
    shortcutCleanup.current?.()
    shortcutCleanup.current = bindPrototypeShortcutBridge(frame.current, window, kind)
    frame.current?.contentWindow?.postMessage({ type: 'storyboard:embed:hello' }, window.location.origin)
  }

  useEffect(() => () => {
    shortcutCleanup.current?.()
    shortcutCleanup.current = null
  }, [])

  return <iframe ref={frame} src={initialSrc} className={styles.frame}
    onLoad={onFrameLoad} data-hypercanvas-content={kind}
    title={kind === 'story' ? 'Component preview' : 'Prototype preview'} />
}
