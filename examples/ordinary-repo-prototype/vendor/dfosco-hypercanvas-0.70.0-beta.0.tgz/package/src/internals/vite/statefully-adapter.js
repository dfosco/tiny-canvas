import * as statefullyCore from '@dfosco/statefully/core'

/** Host adapter around Statefully's public discovery, store, and knob APIs. */
export function createPrototypeCompatibilityView(index = {}) {
  return {
    flows: index.flows ?? {},
    scenes: index.flows ?? {},
    objects: index.objects ?? {},
    records: index.records ?? {},
    prototypes: index.prototypes ?? {},
  }
}

export function createHypercanvasStatefullyAdapter({
  discovery,
  statefully: statefullyRuntime = statefullyCore,
  onCompatibilityIndex = () => {},
  resolveIframe = () => null,
} = {}) {
  if (!discovery?.setRoots || !discovery?.rebuild) throw new TypeError('The Statefully Vite discovery API must expose setRoots() and rebuild().')
  if (!statefullyRuntime?.createPrototypeStore || !statefullyRuntime?.setKnobValue || !statefullyRuntime?.clearKnobValue) {
    throw new TypeError('The Statefully runtime must expose createPrototypeStore(), setKnobValue(), and clearKnobValue().')
  }

  let store = statefullyRuntime.createPrototypeStore()
  let notebookRoot = null
  let route = null
  let disposed = false

  function publish(result) {
    if (disposed) return null
    const index = result?.index ?? result ?? {}
    store.replaceIndex(index)
    onCompatibilityIndex(createPrototypeCompatibilityView(index), result?.diagnostics ?? [])
    return index
  }

  function setNotebookRoot(root) {
    if (disposed) return null
    notebookRoot = root || null
    if (!notebookRoot) {
      const index = discovery.setRoots([]) ?? {}
      return publish({ index, diagnostics: discovery.getDiagnostics?.() ?? [] })
    }
    const index = discovery.setRoots([{
      path: `${notebookRoot}/src`,
      identityRoot: 'src',
      identityProfile: 'hypercanvas',
    }]) ?? {}
    return publish({ index, diagnostics: discovery.getDiagnostics?.() ?? [] })
  }

  function prepare({ prototype, dataset, flow, route: routeBinding } = {}) {
    route = routeBinding ?? null
    return {
      store,
      prototype: prototype ?? null,
      dataset: dataset ?? null,
      flow: flow ?? 'default',
      route,
      setKnobValue(id, value, options = {}) {
        const target = options.target ?? resolveIframe(options.pageId, options.route ?? route)
        return statefullyRuntime.setKnobValue(id, value, { ...options, route: options.route ?? route?.pathname, target })
      },
      clearKnobValue(id, options = {}) {
        const target = options.target ?? resolveIframe(options.pageId, options.route ?? route)
        return statefullyRuntime.clearKnobValue(id, { ...options, route: options.route ?? route?.pathname, target })
      },
    }
  }

  function update() {
    if (!notebookRoot || disposed) return null
    return publish(discovery.rebuild())
  }

  function dispose() {
    if (disposed) return
    disposed = true
    notebookRoot = null
    route = null
    store.replaceIndex({})
  }

  return Object.freeze({ setNotebookRoot, prepare, update, dispose, getStore: () => store })
}
