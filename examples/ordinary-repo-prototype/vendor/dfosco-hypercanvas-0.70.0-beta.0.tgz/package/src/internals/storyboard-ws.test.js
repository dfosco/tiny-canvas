import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

class FakeWebSocket {
  static CONNECTING = 0
  static OPEN = 1
  static CLOSING = 2
  static CLOSED = 3

  constructor(url) {
    this.url = url
    this.readyState = FakeWebSocket.CONNECTING
    this.handlers = new Map()
    FakeWebSocket.instances.push(this)
  }

  addEventListener(name, callback, options = {}) {
    const entries = this.handlers.get(name) || new Set()
    entries.add({ callback, once: options.once === true })
    this.handlers.set(name, entries)
  }

  dispatch(name, event = {}) {
    for (const entry of [...(this.handlers.get(name) || [])]) {
      entry.callback(event)
      if (entry.once) this.handlers.get(name).delete(entry)
    }
  }

  open() {
    this.readyState = FakeWebSocket.OPEN
    this.dispatch('open')
  }

  close() {
    this.readyState = FakeWebSocket.CLOSED
    this.dispatch('close')
  }

  send() {}
}

let storyboardWs

async function flushConnectionStart() {
  for (let i = 0; i < 5; i += 1) await Promise.resolve()
}

beforeEach(async () => {
  FakeWebSocket.instances = []
  vi.useFakeTimers()
  vi.stubEnv('MODE', 'development')
  vi.stubGlobal('__HYPERCANVAS_WS_TEST_MODE__', true)
  vi.stubGlobal('WebSocket', FakeWebSocket)
  vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ json: async () => ({ url: 'ws://localhost/_hypercanvas/ws' }) }))
  vi.resetModules()
  ;({ storyboardWs } = await import('./storyboard-ws.js'))
})

afterEach(() => {
  vi.useRealTimers()
  vi.unstubAllEnvs()
  vi.unstubAllGlobals()
})

describe('storyboard workspace connection lifecycle', () => {
  it('connects without feature listeners and reconnects after a disconnect', async () => {
    const release = storyboardWs.start()
    await flushConnectionStart()
    expect(FakeWebSocket.instances).toHaveLength(1)
    expect(FakeWebSocket.instances[0].url).toBe('ws://localhost/_hypercanvas/ws')

    FakeWebSocket.instances[0].open()
    expect(storyboardWs.connectionState()).toBe('connected')
    FakeWebSocket.instances[0].close()
    expect(storyboardWs.connectionState()).toBe('disconnected')

    await vi.advanceTimersByTimeAsync(499)
    expect(FakeWebSocket.instances).toHaveLength(1)
    await vi.advanceTimersByTimeAsync(1)
    expect(FakeWebSocket.instances).toHaveLength(2)
    FakeWebSocket.instances[1].open()
    expect(storyboardWs.connectionState()).toBe('connected')

    release()
    expect(FakeWebSocket.instances[1].readyState).toBe(FakeWebSocket.CLOSED)
  })

  it('caps retry delays and cancels retries after the workspace releases ownership', async () => {
    const release = storyboardWs.start()
    await flushConnectionStart()
    FakeWebSocket.instances[0].close()
    await vi.advanceTimersByTimeAsync(500)
    expect(FakeWebSocket.instances).toHaveLength(2)
    FakeWebSocket.instances[1].close()
    await vi.advanceTimersByTimeAsync(999)
    expect(FakeWebSocket.instances).toHaveLength(2)
    await vi.advanceTimersByTimeAsync(1)
    expect(FakeWebSocket.instances).toHaveLength(3)

    release()
    await vi.runOnlyPendingTimersAsync()
    expect(FakeWebSocket.instances).toHaveLength(3)
  })

  it('ignores queued error and message events from a retired socket', async () => {
    const release = storyboardWs.start()
    const received = vi.fn()
    storyboardWs.on('workspace:test', received)
    await flushConnectionStart()
    const retired = FakeWebSocket.instances[0]
    retired.open()

    retired.close()
    await vi.advanceTimersByTimeAsync(500)
    const active = FakeWebSocket.instances[1]
    active.open()
    expect(storyboardWs.connectionState()).toBe('connected')

    retired.dispatch('error')
    retired.dispatch('message', { data: JSON.stringify({ event: 'workspace:test', data: 'stale' }) })

    expect(storyboardWs.connectionState()).toBe('connected')
    expect(received).not.toHaveBeenCalled()
    release()
  })
})
