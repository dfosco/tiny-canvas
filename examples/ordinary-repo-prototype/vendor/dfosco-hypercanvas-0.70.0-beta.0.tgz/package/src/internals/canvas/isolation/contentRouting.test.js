import { describe, expect, it } from 'vitest'
import { contentDocumentKind, contentFrameUrl, contentNavigationTarget } from './contentRouting.js'

describe('content document boundary', () => {
  it.each(['/', '/branch--ui-quality/'])('selects embedded content before workspace imports at %s', base => {
    const location = (path, query = '') => ({ pathname: base + path, search: query })
    expect(contentDocumentKind(location('chrome-overview'), base)).toBeNull()
    expect(contentDocumentKind(location('chrome-overview', '?_sb_embed=&flow=empty'), base)).toBe('prototype')
    expect(contentDocumentKind(location('components/Sidebar', '?_sb_embed='), base)).toBe('story')
    expect(contentDocumentKind(location('canvas/work', '?_sb_embed='), base)).toBeNull()
    expect(contentDocumentKind(location('stories.html/components/Sidebar'), base)).toBe('story')
    expect(contentDocumentKind(location('prototypes.html/signup'), base)).toBe('prototype')
  })

  it('preserves query and fragment state in a branch frame URL', () => {
    expect(contentFrameUrl({ pathname: '/signup/details', search: '?flow=signup%2Fempty', hash: '#name=Ada' }, '/branch--ui/'))
      .toBe('/branch--ui/signup/details?flow=signup%2Fempty&_sb_embed=#name=Ada')
  })

  it('routes host hideUI directly to content and keeps the host flag out of authored URLs', () => {
    expect(contentDocumentKind({ pathname: '/branch--preview/Demo/details', search: '?hideUI=1&flow=empty' }, '/branch--preview/'))
      .toBe('prototype')
    expect(contentDocumentKind({ pathname: '/branch--preview/canvas/work', search: '?hideUI=1' }, '/branch--preview/'))
      .toBeNull()
    expect(contentFrameUrl({ pathname: '/Demo/details', search: '?hideUI=1&flow=empty', hash: '#tab=profile' }, '/branch--preview/'))
      .toBe('/branch--preview/Demo/details?flow=empty&_sb_embed=#tab=profile')
  })

  it('accepts only same-origin absolute route messages', () => {
    expect(contentNavigationTarget('/signup?flow=empty#name=Ada', 'https://app.test')).toBe('/signup?flow=empty#name=Ada')
    expect(contentNavigationTarget('https://app.test/signup?flow=empty#name=Ada', 'https://app.test'))
      .toBe('/signup?flow=empty#name=Ada')
    expect(contentNavigationTarget('/branch--preview/signup?flow=empty#name=Ada', 'https://app.test', '/branch--preview/'))
      .toBe('/signup?flow=empty#name=Ada')
    for (const src of ['//evil.test', '/\\evil.test', 'https://evil.test', 'javascript:alert(1)', 'relative/path', null]) {
      expect(contentNavigationTarget(src, 'https://app.test')).toBeNull()
    }
    expect(contentNavigationTarget('/branch--other/signup', 'https://app.test', '/branch--preview/')).toBeNull()
  })
})
