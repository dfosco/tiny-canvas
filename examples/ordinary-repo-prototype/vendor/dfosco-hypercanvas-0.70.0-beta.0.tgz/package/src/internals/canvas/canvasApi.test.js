import { afterEach, describe, expect, it, vi } from 'vitest'
import { patchWidget } from './canvasApi.js'

afterEach(() => {
  vi.unstubAllGlobals()
  vi.unstubAllEnvs()
})

describe('widget persistence', () => {
  it('returns acknowledged changes through the branch-prefixed Core route', async () => {
    vi.stubEnv('BASE_URL', '/branch--rename/')
    const result = { success: true, eventIds: ['saved-event'] }
    const fetch = vi.fn().mockResolvedValue({ ok: true, status: 200, json: async () => result })
    vi.stubGlobal('fetch', fetch)

    await expect(patchWidget('welcome', 'file-1', { props: { path: 'assets/renamed.txt' } })).resolves.toEqual(result)
    expect(fetch).toHaveBeenCalledWith('/branch--rename/_hypercanvas/canvas/widget', expect.objectContaining({
      method: 'PATCH',
      body: JSON.stringify({ name: 'welcome', widgetId: 'file-1', props: { path: 'assets/renamed.txt' } }),
    }))
  })

  it('rejects a failed PATCH instead of reporting an unsaved reference as complete', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: false, status: 404, json: async () => ({ error: 'Widget not found' }) }))
    await expect(patchWidget('welcome', 'gone', { props: { path: 'assets/renamed.txt' } })).rejects.toThrow('Widget not found')
  })
})
