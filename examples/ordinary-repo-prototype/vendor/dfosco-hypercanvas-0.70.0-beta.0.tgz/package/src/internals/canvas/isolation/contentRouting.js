/** Pure URL contract shared by the document bootstrap and the frame host. */
export function contentDocumentKind(location, base = '/') {
  const prefix = base.replace(/\/$/, '')
  const path = prefix && location.pathname.startsWith(`${prefix}/`)
    ? location.pathname.slice(prefix.length) : location.pathname
  if (/^\/stories\.html(?:\/|$)/.test(path)) return 'story'
  if (/^\/prototypes\.html(?:\/|$)/.test(path)) return 'prototype'
  const params = new URLSearchParams(location.search)
  // `hideUI` is a host instruction for opening authored content without the
  // workspace shell. It is deliberately separate from the page's query/hash.
  if (!params.has('_sb_embed') && !params.has('hideUI')) return null
  if (/^\/components(?:\/|$)/.test(path)) return 'story'
  if (/^\/(?:canvas|sites|notebook|workspace|viewfinder|create|home)(?:\/|$)/.test(path)) return null
  return 'prototype'
}

export function contentFrameUrl({ pathname, search = '', hash = '' }, base = '/') {
  const prefix = base.replace(/\/$/, '')
  const params = new URLSearchParams(search)
  params.delete('hideUI')
  params.set('_sb_embed', '')
  return `${prefix}${pathname.startsWith('/') ? pathname : `/${pathname}`}?${params}${hash}`
}

export function contentNavigationTarget(src, origin, base = '/') {
  if (typeof src !== 'string' || src.startsWith('//') || src.includes('\\')) return null
  if (!src.startsWith('/') && !/^https?:\/\//i.test(src)) return null
  let url
  try {
    url = new URL(src, origin)
  } catch {
    return null
  }
  if (url.origin !== origin || !['http:', 'https:'].includes(url.protocol)) return null
  const prefix = base.replace(/\/$/, '')
  if (prefix && url.pathname !== prefix && !url.pathname.startsWith(`${prefix}/`)) return null
  const pathname = prefix ? url.pathname.slice(prefix.length) || '/' : url.pathname
  return `${pathname}${url.search}${url.hash}`
}
