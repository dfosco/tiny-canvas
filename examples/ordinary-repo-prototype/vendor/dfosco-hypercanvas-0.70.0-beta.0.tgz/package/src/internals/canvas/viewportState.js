export function canvasViewportStorageKey(canvasId) {
  return `sb-canvas-viewport:${canvasId}`
}

export function parseCanvasViewportState(raw, { zoomMin, zoomMax } = {}) {
  if (typeof raw !== 'string' || !raw) return null
  try {
    const state = JSON.parse(raw)
    if (!state || typeof state !== 'object' || Array.isArray(state)) return null
    const hasZoom = Object.hasOwn(state, 'zoom')
    const hasScrollLeft = Object.hasOwn(state, 'scrollLeft')
    const hasScrollTop = Object.hasOwn(state, 'scrollTop')
    if (!hasZoom && !hasScrollLeft && !hasScrollTop) return null
    if (hasZoom && (!Number.isFinite(state.zoom) || state.zoom <= 0)) return null
    if (hasScrollLeft && (!Number.isFinite(state.scrollLeft) || state.scrollLeft < 0)) return null
    if (hasScrollTop && (!Number.isFinite(state.scrollTop) || state.scrollTop < 0)) return null
    const zoom = hasZoom && Number.isFinite(zoomMin) && Number.isFinite(zoomMax)
      ? Math.min(zoomMax, Math.max(zoomMin, state.zoom))
      : hasZoom ? state.zoom : null
    return {
      zoom,
      scrollLeft: hasScrollLeft ? state.scrollLeft : null,
      scrollTop: hasScrollTop ? state.scrollTop : null,
    }
  } catch {
    return null
  }
}
