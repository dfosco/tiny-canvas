import { describe, expect, it } from 'vitest'
import { canvasViewportStorageKey, parseCanvasViewportState } from './viewportState.js'

describe('Canvas viewport state', () => {
  it('uses the existing per-Canvas storage key and ignores old timestamps', () => {
    expect(canvasViewportStorageKey('canvas-a')).toBe('sb-canvas-viewport:canvas-a')
    expect(parseCanvasViewportState(JSON.stringify({ zoom: 125, scrollLeft: 40, scrollTop: 90, timestamp: 1 }), {
      zoomMin: 25,
      zoomMax: 200,
    })).toEqual({ zoom: 125, scrollLeft: 40, scrollTop: 90 })
  })

  it('clamps finite zoom values and rejects invalid stored state', () => {
    expect(parseCanvasViewportState('{"zoom":500,"scrollLeft":0,"scrollTop":0}', { zoomMin: 25, zoomMax: 200 }).zoom).toBe(200)
    expect(parseCanvasViewportState('{"zoom":null,"scrollLeft":0,"scrollTop":0}', { zoomMin: 25, zoomMax: 200 })).toBeNull()
    expect(parseCanvasViewportState('{"zoom":100,"scrollLeft":-1,"scrollTop":0}', { zoomMin: 25, zoomMax: 200 })).toBeNull()
    expect(parseCanvasViewportState('{broken')).toBeNull()
  })
})
