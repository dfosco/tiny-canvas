import { afterEach, describe, expect, it, vi } from 'vitest'
import { createSessionStore } from '@dfosco/statefully/core'
import { createStoryboardQuerySession } from './query-session.ts'

const originalUrl = `${window.location.pathname}${window.location.search}${window.location.hash}`

function navigate(url) {
  window.history.pushState(window.history.state, '', url)
}

afterEach(() => {
  window.history.replaceState(window.history.state, '', originalUrl)
})

describe('Storyboard query session bridge', () => {
  it('uses Statefully session APIs while storing runtime values in query params', () => {
    navigate('/branch--feature/prototypes/Booking?flow=checkout&keep=1#details')
    const runtime = createStoryboardQuerySession(createSessionStore, window)

    runtime.session.setParam('traveler.name', 'Alex Smith')

    expect(runtime.session.getParam('traveler.name')).toBe('Alex Smith')
    expect(runtime.session.getAllParams()).toEqual({ 'traveler.name': 'Alex Smith' })
    expect(window.location.pathname).toBe('/branch--feature/prototypes/Booking')
    expect(new URLSearchParams(window.location.search).get('sb.traveler.name')).toBe('Alex Smith')
    expect(new URLSearchParams(window.location.search).get('flow')).toBe('checkout')
    expect(new URLSearchParams(window.location.search).get('keep')).toBe('1')
    expect(window.location.hash).toBe('#details')
    runtime.dispose()
  })

  it('restores values after creating a fresh Statefully session', () => {
    navigate('/branch--feature/Booking?keep=yes')
    const first = createStoryboardQuerySession(createSessionStore, window)
    first.session.setParam('booking.status', 'confirmed')
    first.dispose()

    const reloaded = createStoryboardQuerySession(createSessionStore, window)
    expect(reloaded.session.getParam('booking.status')).toBe('confirmed')
    reloaded.dispose()
  })

  it('does not persist Storyboard session values through Statefully local storage APIs', () => {
    navigate('/Booking?keep=yes')
    const runtime = createStoryboardQuerySession(createSessionStore, window)

    runtime.session.setLocal('shadow', { value: 'local-only' })

    expect(runtime.session.getLocal('shadow', 'fallback')).toBe('fallback')
    expect(window.location.search).toBe('?keep=yes')
    runtime.dispose()
  })

  it('notifies Statefully subscribers when query state changes or browser history moves', async () => {
    navigate('/Booking?step=search')
    const runtime = createStoryboardQuerySession(createSessionStore, window)
    const listener = vi.fn()
    const unsubscribe = runtime.session.subscribe(listener)

    runtime.session.setParam('selected', 'flight-1')
    expect(listener).toHaveBeenCalledTimes(1)

    const changed = new URL(window.location.href)
    changed.searchParams.set('sb.selected', 'flight-2')
    window.history.replaceState(window.history.state, '', `${changed.pathname}${changed.search}${changed.hash}`)
    window.dispatchEvent(new PopStateEvent('popstate'))
    expect(listener).toHaveBeenCalledTimes(2)
    expect(runtime.session.getParam('selected')).toBe('flight-2')

    unsubscribe()
    runtime.dispose()
  })

  it('removes only Storyboard query values and preserves route/search state', () => {
    navigate('/branch--feature/Booking?flow=payment&keep=yes&sb.selected=flight-1&sb.step=search')
    const runtime = createStoryboardQuerySession(createSessionStore, window)
    runtime.session.removeParam('selected')
    const search = new URLSearchParams(window.location.search)

    expect(search.get('flow')).toBe('payment')
    expect(search.get('keep')).toBe('yes')
    expect(search.get('sb.selected')).toBeNull()
    expect(search.get('sb.step')).toBe('search')
    expect(window.location.pathname).toBe('/branch--feature/Booking')
    runtime.dispose()
  })
})
