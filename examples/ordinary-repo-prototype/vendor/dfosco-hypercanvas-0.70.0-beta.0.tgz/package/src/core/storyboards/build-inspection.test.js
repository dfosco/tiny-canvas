import { describe, expect, it } from 'vitest'
import { buildStoryboardInspectionGraph } from './build-inspection.ts'

const declarations = {
  prototype: 'TravelBooking',
  scenarios: [{ name: 'ready', data: { flights: { $ref: 'flights' }, unrelated: { $ref: 'missing' } } }],
  objects: { flights: { entries: [] } },
  records: {},
}

const behavior = {
  conditions: [{ id: 'has-flight', description: 'A flight is selected.', reads: ['booking.flight'] }],
  controls: [{ id: 'pay', action: 'submit-payment', condition: 'has-flight' }],
  actions: [{ id: 'submit-payment', writes: ['booking.status'] }],
}

describe('Storyboard Build inspection graph', () => {
  it('derives declared data, condition, control, action, and structural relationships', () => {
    const graph = buildStoryboardInspectionGraph({
      declarations,
      behavior,
      structure: [
        { sourcePath: 'prototypes/TravelBooking/index.tsx', nodeId: 'shell', component: 'main', kind: 'view', line: 1, column: 1, children: ['button'] },
        { sourcePath: 'prototypes/TravelBooking/index.tsx', nodeId: 'button', component: 'button', kind: 'block', line: 2, column: 3, children: [] },
      ],
    })

    expect(graph.edges).toEqual(expect.arrayContaining([
      expect.objectContaining({ kind: 'references', from: 'scenario:ready', to: 'object:flights' }),
      expect.objectContaining({ kind: 'reads', from: 'condition:has-flight', to: 'state:booking.flight' }),
      expect.objectContaining({ kind: 'guarded-by', from: 'control:pay', to: 'condition:has-flight' }),
      expect.objectContaining({ kind: 'invokes', from: 'control:pay', to: 'action:submit-payment' }),
      expect.objectContaining({ kind: 'writes', from: 'action:submit-payment', to: 'state:booking.status' }),
      expect.objectContaining({ kind: 'contains', from: 'structure:prototypes/TravelBooking/index.tsx:shell', to: 'structure:prototypes/TravelBooking/index.tsx:button' }),
    ]))
    expect(graph.diagnostics).toEqual([
      expect.objectContaining({ code: 'unresolved-reference', message: expect.stringContaining('missing') }),
    ])
  })

  it('reports unresolved Control bindings instead of inferring graph edges', () => {
    const graph = buildStoryboardInspectionGraph({
      declarations: { prototype: 'Example', scenarios: [], objects: {}, records: {} },
      behavior: {
        conditions: [],
        controls: [{ id: 'submit', action: 'missing-action', condition: 'missing-condition' }],
        actions: [],
      },
    })

    expect(graph.edges).toEqual([])
    expect(graph.diagnostics.map(diagnostic => diagnostic.code)).toEqual(['unresolved-action', 'unresolved-condition'])
  })

  it('reports a Statefully reference when its name is declared as both Object and Record', () => {
    const graph = buildStoryboardInspectionGraph({
      declarations: {
        prototype: 'Example',
        scenarios: [{ name: 'default', data: { catalog: { $ref: 'catalog' } } }],
        objects: { catalog: { selected: 'flight-1' } },
        records: { catalog: [{ id: 'flight-1' }] },
      },
      behavior: { conditions: [], controls: [], actions: [] },
    })

    expect(graph.edges).toEqual([])
    expect(graph.diagnostics).toEqual([
      expect.objectContaining({ code: 'ambiguous-reference', message: expect.stringContaining('both an Object and a Record') }),
    ])
  })

  it('does not mutate its input or expose mutable graph collections', () => {
    const graph = buildStoryboardInspectionGraph({ declarations, behavior })
    expect(Object.isFrozen(graph)).toBe(true)
    expect(Object.isFrozen(graph.nodes)).toBe(true)
    expect(Object.isFrozen(graph.edges)).toBe(true)
    expect(declarations.scenarios[0].data.flights).toEqual({ $ref: 'flights' })
  })
})
