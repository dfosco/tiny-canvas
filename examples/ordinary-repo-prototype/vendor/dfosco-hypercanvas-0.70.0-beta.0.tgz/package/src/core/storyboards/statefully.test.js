import { describe, expect, it, vi } from 'vitest'
import {
  parseStoryboardStateDeclarations,
  replaceStoryboardStateDeclarations,
} from './statefully.ts'

function createStore(initial) {
  let index = initial
  return {
    getIndex: () => index,
    replaceIndex: vi.fn(next => { index = next }),
  }
}

describe('Storyboard Statefully adapter', () => {
  it('maps scenarios, objects, and records into scoped Statefully index entries', () => {
    const store = createStore({
      flows: { 'Other/default': { title: 'Keep me' }, 'Booking/old': { old: true } },
      objects: { 'Other/customer': { name: 'Other' } },
      records: { 'Other/trips': [{ id: 'other' }] },
      prototypes: { Booking: { source: 'Booking.tsx' } },
      customField: 'preserved',
    })

    const next = replaceStoryboardStateDeclarations(store, {
      prototype: 'Booking',
      scenarios: [
        { name: 'search', data: { destination: 'AMS', passengerCount: 1 } },
        { name: 'confirmed', data: { booking: { status: 'confirmed' } } },
      ],
      objects: { traveler: { name: 'Alex' } },
      records: { flights: [{ id: 'flight-1', price: 210 }] },
    })

    expect(next.flows).toEqual({
      'Other/default': { title: 'Keep me' },
      'Booking/search': { destination: 'AMS', passengerCount: 1 },
      'Booking/confirmed': { booking: { status: 'confirmed' } },
    })
    expect(next.objects).toEqual({
      'Other/customer': { name: 'Other' },
      'Booking/traveler': { name: 'Alex' },
    })
    expect(next.records).toEqual({
      'Other/trips': [{ id: 'other' }],
      'Booking/flights': [{ id: 'flight-1', price: 210 }],
    })
    expect(next.prototypes).toEqual({ Booking: { source: 'Booking.tsx' } })
    expect(next.customField).toBe('preserved')
    expect(store.replaceIndex).toHaveBeenCalledTimes(1)
  })

  it('removes stale entries for the same Storyboard on replacement', () => {
    const store = createStore({ flows: { 'Booking/old': {}, 'Other/default': {} } })
    replaceStoryboardStateDeclarations(store, {
      prototype: 'Booking',
      scenarios: [{ name: 'new', data: {} }],
    })
    expect(store.getIndex().flows).toEqual({ 'Other/default': {}, 'Booking/new': {} })
  })

  it('rejects malformed and non-JSON declarations before touching the store', () => {
    const store = createStore({ flows: {} })
    expect(() => replaceStoryboardStateDeclarations(store, {
      prototype: 'Booking',
      scenarios: [{ name: '../escape', data: {} }],
    })).toThrow(/single non-empty path segment/)
    expect(() => parseStoryboardStateDeclarations({
      prototype: 'Booking',
      scenarios: [{ name: 'invalid', data: { callback: () => null } }],
    })).toThrow()
    expect(store.replaceIndex).not.toHaveBeenCalled()
  })

  it('rejects duplicate Scenario names', () => {
    const store = createStore({ flows: {} })
    expect(() => replaceStoryboardStateDeclarations(store, {
      prototype: 'Booking',
      scenarios: [
        { name: 'default', data: {} },
        { name: 'default', data: { step: 2 } },
      ],
    })).toThrow('Duplicate Storyboard Scenario: default')
    expect(store.replaceIndex).not.toHaveBeenCalled()
  })
})
