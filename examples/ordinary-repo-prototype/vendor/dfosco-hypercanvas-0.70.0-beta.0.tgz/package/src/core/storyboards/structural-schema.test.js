import { describe, expect, it } from 'vitest'
import {
  componentRegistrationSchema,
  createComponentRegistrationIndex,
  parseComponentRegistration,
} from './structural-schema.ts'
import {
  createRuntimeIdentityIndex,
  parseAuthoredNodeIdentity,
  parseRuntimeInstanceIdentity,
} from './identity-index.ts'

describe('Storyboard component registrations', () => {
  it('parses typed props and named composition slots with defaults', () => {
    const registration = parseComponentRegistration({
      name: 'ProductCard',
      kind: 'block',
      props: {
        title: { type: 'text', default: 'Product' },
        featured: { type: 'boolean' },
        columns: { type: 'number', min: 1, max: 4, default: 2 },
        density: { type: 'enum', values: ['compact', 'comfortable'], default: 'compact' },
      },
      layout: {
        gap: { type: 'number', min: 0, default: 8 },
        display: { type: 'enum', values: ['flex', 'grid'], default: 'flex' },
      },
      slots: { footer: {} },
    })

    expect(registration.props.columns).toMatchObject({ type: 'number', min: 1, max: 4, default: 2 })
    expect(registration.slots.footer.accepts).toEqual(['block', 'control'])
    expect(registration.slots.footer.minChildren).toBe(0)
    expect(registration.layout.gap).toMatchObject({ type: 'number', min: 0, default: 8 })
  })

  it('rejects invalid prop ranges, enum defaults, and slot constraints', () => {
    expect(componentRegistrationSchema.safeParse({
      name: 'InvalidBlock', kind: 'block',
      props: { count: { type: 'number', min: 5, max: 2 } },
    }).success).toBe(false)
    expect(componentRegistrationSchema.safeParse({
      name: 'InvalidBlock', kind: 'block', layout: { gap: { type: 'number', min: 10, max: 2 } },
    }).success).toBe(false)
    expect(componentRegistrationSchema.safeParse({
      name: 'InvalidBlock', kind: 'block',
      props: { size: { type: 'enum', values: ['small', 'large'], default: 'medium' } },
    }).success).toBe(false)
    expect(componentRegistrationSchema.safeParse({
      name: 'InvalidBlock', kind: 'block',
      props: { size: { type: 'enum', values: ['small', 'small'] } },
    }).success).toBe(false)
    expect(componentRegistrationSchema.safeParse({
      name: 'InvalidBlock', kind: 'block',
      slots: { body: { minChildren: 2, maxChildren: 1 } },
    }).success).toBe(false)
  })

  it('indexes registrations by component name and rejects duplicates', () => {
    const registration = { name: 'ProductCard', kind: 'block' }
    const index = createComponentRegistrationIndex([registration])

    expect(index.get('ProductCard')).toMatchObject({ name: 'ProductCard', kind: 'block' })
    expect(index.has('Missing')).toBe(false)
    expect(Object.isFrozen(index.get('ProductCard'))).toBe(true)
    expect(() => createComponentRegistrationIndex([registration, registration])).toThrow(/Duplicate/)
  })
})

describe('Storyboard authored and runtime identities', () => {
  it('validates source identity separately from runtime instance identity', () => {
    expect(parseAuthoredNodeIdentity({ sourcePath: 'src/views/Cart.tsx', nodeId: 'jsx:124:168' }))
      .toEqual({ sourcePath: 'src/views/Cart.tsx', nodeId: 'jsx:124:168' })
    expect(parseRuntimeInstanceIdentity({
      sourcePath: 'src/views/Cart.tsx', nodeId: 'jsx:124:168', instancePath: 'cart/line-items/0',
    })).toMatchObject({ instancePath: 'cart/line-items/0' })
    expect(() => parseRuntimeInstanceIdentity({ sourcePath: 'Cart.tsx', nodeId: 'jsx:1:2' })).toThrow()
  })

  it('returns explicit ambiguity for repeated rendered instances', () => {
    const source = { sourcePath: 'src/views/Cart.tsx', nodeId: 'jsx:124:168' }
    const index = createRuntimeIdentityIndex([
      { ...source, instancePath: 'cart/line-items/0' },
      { ...source, instancePath: 'cart/line-items/1' },
    ])

    expect(index.resolve(source)).toEqual({
      status: 'ambiguous',
      instances: [
        { ...source, instancePath: 'cart/line-items/0' },
        { ...source, instancePath: 'cart/line-items/1' },
      ],
    })
  })

  it('distinguishes missing from unique source mappings and rejects duplicate instance ids', () => {
    const source = { sourcePath: 'src/views/Cart.tsx', nodeId: 'jsx:124:168' }
    const instance = { ...source, instancePath: 'cart/line-items/0' }
    const index = createRuntimeIdentityIndex([instance])

    expect(index.resolve(source)).toEqual({ status: 'unique', instance })
    expect(index.resolve({ sourcePath: 'src/views/Cart.tsx', nodeId: 'jsx:900:930' })).toEqual({ status: 'missing' })
    expect(() => createRuntimeIdentityIndex([instance, instance])).toThrow(/Duplicate/)
  })
})
