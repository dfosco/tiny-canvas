import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { initializeNotebook, inspectNotebook } from '../notebook/notebook.js'
import { resolveNotebookPath } from '../notebook/runtime.js'
import { createComponentRegistrationIndex } from './structural-schema.ts'
import { createStoryboardSourceRoutes, deleteStoryboardNode, duplicateStoryboardNode, editStoryboardBinding, editStoryboardLayout, editStoryboardProp, insertStoryboardNode, inspectStoryboardBindings, inspectStoryboardSource, reorderStoryboardNode, reparentStoryboardNode } from './source-editor.ts'

const roots = []
const behaviorSource = `export const travelBookingBehavior = {
  controls: [
    { id: 'payment-submit', action: 'payment-success', condition: 'payment-ready', label: 'keep this field' },
    { id: 'payment-retry', action: 'payment-failure' },
  ],
  actions: [{ id: 'payment-success' }, { id: 'payment-failure' }, { id: 'restart-booking' }],
  conditions: [{ id: 'payment-ready' }, { id: 'payment-failed' }],
} as const\n`
const registrations = createComponentRegistrationIndex([
  { name: 'BookingCard', kind: 'block', props: { title: { type: 'text' }, columns: { type: 'number', min: 1, max: 4 }, highlighted: { type: 'boolean' }, tone: { type: 'enum', values: ['neutral', 'accent'] }, 'data-hc-node': { type: 'text' } }, layout: { gap: { type: 'number', min: 0, max: 64 }, width: { type: 'text' }, display: { type: 'enum', values: ['block', 'flex', 'grid'] } }, slots: { children: { accepts: ['block', 'control'], minChildren: 1, maxChildren: 3 } } },
  { name: 'CardTitle', kind: 'control', props: { title: { type: 'text' } }, slots: {} },
])

function fixture(source = '<BookingCard title="Flight" columns={2} />\n', { activeNotebook = true, fallbackRoot = null, sourcePath = 'prototypes/booking.view.tsx' } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'hypercanvas-storyboard-source-'))
  roots.push(root)
  const workspaceSourceRoot = fallbackRoot || path.join(root, 'src')
  if (fallbackRoot) roots.push(fallbackRoot)
  const sourceRoot = activeNotebook ? root : workspaceSourceRoot
  const absolutePath = path.join(sourceRoot, sourcePath)
  fs.mkdirSync(path.dirname(absolutePath), { recursive: true })
  fs.writeFileSync(absolutePath, source)
  if (activeNotebook) initializeNotebook(root, { id: 'storyboard-source', title: 'Source API' })
  const runtime = {
    status: () => activeNotebook
      ? ({ active: true, root, notebook: inspectNotebook(root), generation: 3 })
      : ({ active: false, root: null, notebook: null, generation: 0 }),
    refreshNotebook: vi.fn(),
  }
  const events = []
  const routes = createStoryboardSourceRoutes({
    runtime,
    fallbackRoot: workspaceSourceRoot,
    registrations,
    resolvePath: resolveNotebookPath,
    sendJson: (res, status, data) => { res.result = { status, data } },
    eventSender: event => events.push(event),
  })
  const call = async (method, route, body = {}) => {
    const res = {}
    await routes({}, res, { method, path: route, body })
    return res.result
  }
  return { root, sourceRoot, sourcePath, absolutePath, runtime, events, call }
}

afterEach(() => {
  while (roots.length) fs.rmSync(roots.pop(), { recursive: true, force: true })
})

describe('Storyboard TSX source editor', () => {
  it('inspects registered JSX nodes, literal props, identity, and opaque nodes', () => {
    const source = '<section><BookingCard title={"Flight"}><CardTitle title="Hello" /></BookingCard><Unknown /></section>'
    const result = inspectStoryboardSource('prototypes/booking.view.tsx', source, registrations)

    expect(result.nodes).toHaveLength(2)
    expect(result.nodes[0]).toMatchObject({ component: 'BookingCard', kind: 'block', props: { title: 'Flight' }, layout: {}, editableLayout: { gap: { type: 'number' }, width: { type: 'text' } }, children: [result.nodes[1].nodeId] })
    expect(result.nodes[1]).toMatchObject({ component: 'CardTitle', kind: 'control', props: { title: 'Hello' } })
    expect(result.opaqueCount).toBe(2)
  })

  it('uses authored identities stably and revision-bound offsets for unannotated source nodes', () => {
    const source = 'const view = <BookingCard data-hc-node="booking-card" title="Flight" />\n'
    const first = inspectStoryboardSource('prototypes/booking.view.tsx', source, registrations)
    const afterUnrelatedEdit = inspectStoryboardSource('prototypes/booking.view.tsx', `// moved source\n${source}`, registrations)
    const internal = inspectStoryboardSource('prototypes/booking.view.tsx', '<BookingCard title="Flight" />', registrations)

    expect(first.nodes[0].nodeId).toBe('booking-card')
    expect(afterUnrelatedEdit.nodes[0].nodeId).toBe('booking-card')
    expect(first.nodes[0].props).not.toHaveProperty('data-hc-node')
    expect(first.nodes[0].editableProps).not.toHaveProperty('data-hc-node')
    expect(internal.nodes[0].nodeId).toBe(`jsx:${internal.revision}:0`)
    expect(() => inspectStoryboardSource('prototypes/booking.view.tsx', '<><BookingCard data-hc-node="same" /><Unknown data-hc-node="same" /></>', registrations)).toThrow(/identity is duplicated/)
    expect(() => inspectStoryboardSource('prototypes/booking.view.tsx', '<BookingCard data-hc-node={nodeId} />', registrations)).toThrow(/static, non-empty string/)
    expect(() => inspectStoryboardSource('prototypes/booking.view.tsx', '<BookingCard data-hc-node="" />', registrations)).toThrow(/static, non-empty string/)
    expect(() => inspectStoryboardSource('prototypes/booking.view.tsx', '<BookingCard data-hc-node="stable" {...props} />', registrations)).toThrow(/later JSX spread/)
  })

  it('sets only a schema-declared literal property and preserves unrelated source', () => {
    const source = 'const view = <BookingCard title="Flight" columns={2} />\n'
    const inspection = inspectStoryboardSource('prototypes/booking.view.tsx', source, registrations)
    const result = editStoryboardProp('prototypes/booking.view.tsx', source, {
      type: 'setProp',
      target: { sourcePath: inspection.sourcePath, nodeId: inspection.nodes[0].nodeId },
      expectedRevision: inspection.revision,
      prop: 'title',
      value: 'Round trip "plus"',
    }, registrations)

    expect(result.source).toBe('const view = <BookingCard title={"Round trip \\"plus\\""} columns={2} />\n')
    expect(result.revision).not.toBe(inspection.revision)
  })

  it('inspects and sets declared inline layout fields while preserving literal style properties', () => {
    const source = `const view = <BookingCard data-hc-node="card" title="Flight" style={{ color: 'navy', gap: 8 }} />\n`
    const inspection = inspectStoryboardSource('prototypes/booking.view.tsx', source, registrations)
    expect(inspection.nodes[0].layout).toEqual({ color: 'navy', gap: 8 })
    expect(inspection.nodes[0].editableLayout).toHaveProperty('gap')

    const changedGap = editStoryboardLayout(inspection.sourcePath, source, {
      type: 'setLayout', target: { sourcePath: inspection.sourcePath, nodeId: 'card' },
      expectedRevision: inspection.revision, field: 'gap', value: 16,
    }, registrations)
    expect(changedGap.source).toContain(`style={{ color: 'navy', gap: 16 }}`)

    const changedWidth = editStoryboardLayout(inspection.sourcePath, changedGap.source, {
      type: 'setLayout', target: { sourcePath: inspection.sourcePath, nodeId: 'card' },
      expectedRevision: changedGap.revision, field: 'width', value: '100%',
    }, registrations)
    expect(changedWidth.source).toContain(`color: 'navy', gap: 16, width: "100%"`)

    const withoutStyle = '<BookingCard data-hc-node="card" title="Flight" />'
    const noStyleInspection = inspectStoryboardSource(inspection.sourcePath, withoutStyle, registrations)
    const added = editStoryboardLayout(inspection.sourcePath, withoutStyle, {
      type: 'setLayout', target: { sourcePath: inspection.sourcePath, nodeId: 'card' },
      expectedRevision: noStyleInspection.revision, field: 'display', value: 'flex',
    }, registrations)
    expect(added.source).toContain('style={{ display: "flex" }}')
  })

  it('rejects computed, spread, duplicated, undeclared, stale, and out-of-range layout edits', () => {
    const commandFor = source => {
      const inspection = inspectStoryboardSource('prototypes/booking.view.tsx', source, registrations)
      return { inspection, command: { type: 'setLayout', target: { sourcePath: inspection.sourcePath, nodeId: inspection.nodes[0].nodeId }, expectedRevision: inspection.revision, field: 'gap', value: 8 } }
    }
    for (const source of [
      '<BookingCard style={styles} />',
      '<BookingCard style={{ ...styles, gap: 4 }} />',
      '<BookingCard style={{ [field]: 4 }} />',
      '<BookingCard style={{ gap: spacing }} />',
    ]) {
      const { inspection, command } = commandFor(source)
      expect(() => editStoryboardLayout(inspection.sourcePath, source, command, registrations)).toThrow(/literal|opaque|Computed/)
    }
    const source = '<BookingCard />'
    const { inspection, command } = commandFor(source)
    expect(() => editStoryboardLayout(inspection.sourcePath, source, { ...command, field: 'position' }, registrations)).toThrow(/not editable/)
    expect(() => editStoryboardLayout(inspection.sourcePath, source, { ...command, value: -1 }, registrations)).toThrow(/registered schema/)
    expect(() => editStoryboardLayout(inspection.sourcePath, source, { ...command, expectedRevision: '0'.repeat(64) }, registrations)).toThrow(/changed since it was inspected/)
  })

  it('inspects declared Control bindings and updates only static action/condition metadata', () => {
    const sourcePath = 'prototypes/TravelBooking/state.ts'
    const inspection = inspectStoryboardBindings(sourcePath, behaviorSource)
    expect(inspection.controls).toEqual([
      { id: 'payment-submit', action: 'payment-success', condition: 'payment-ready' },
      { id: 'payment-retry', action: 'payment-failure', condition: null },
    ])
    const updated = editStoryboardBinding(sourcePath, behaviorSource, {
      type: 'setBinding', controlId: 'payment-submit', actionId: 'restart-booking',
      conditionId: 'payment-failed', expectedRevision: inspection.revision,
    })
    expect(updated.source).toContain("action: \"restart-booking\", condition: \"payment-failed\", label: 'keep this field'")
    expect(inspectStoryboardBindings(sourcePath, updated.source).controls[0]).toEqual({
      id: 'payment-submit', action: 'restart-booking', condition: 'payment-failed',
    })

    const cleared = editStoryboardBinding(sourcePath, updated.source, {
      type: 'setBinding', controlId: 'payment-submit', actionId: 'payment-success',
      conditionId: null, expectedRevision: updated.revision,
    })
    expect(inspectStoryboardBindings(sourcePath, cleared.source).controls[0].condition).toBeNull()
    expect(cleared.source).toContain('condition: undefined')
  })

  it('rejects unknown Controls, Actions, Conditions, stale revisions, and dynamic declaration shapes', () => {
    const sourcePath = 'prototypes/TravelBooking/state.ts'
    const inspection = inspectStoryboardBindings(sourcePath, behaviorSource)
    const command = { type: 'setBinding', controlId: 'payment-submit', actionId: 'payment-failure', conditionId: null, expectedRevision: inspection.revision }
    expect(() => editStoryboardBinding(sourcePath, behaviorSource, { ...command, controlId: 'missing' })).toThrow(/not declared/)
    expect(() => editStoryboardBinding(sourcePath, behaviorSource, { ...command, actionId: 'missing' })).toThrow(/Action .* not declared/)
    expect(() => editStoryboardBinding(sourcePath, behaviorSource, { ...command, conditionId: 'missing' })).toThrow(/Condition .* not declared/)
    expect(() => editStoryboardBinding(sourcePath, behaviorSource, { ...command, expectedRevision: '0'.repeat(64) })).toThrow(/changed since it was inspected/)
    const dynamicAction = behaviorSource.replace("action: 'payment-success'", 'action: selectedAction')
    expect(() => editStoryboardBinding(sourcePath, dynamicAction, { ...command, expectedRevision: inspectStoryboardBindings(sourcePath, dynamicAction).revision })).toThrow(/static string/)
    const spreadControl = behaviorSource.replace("{ id: 'payment-submit'", "{ ...commonControl, id: 'payment-submit'")
    expect(() => editStoryboardBinding(sourcePath, spreadControl, { ...command, expectedRevision: inspectStoryboardBindings(sourcePath, spreadControl).revision })).toThrow(/spreads or computed keys/)
  })

  it('inspects and updates a typed binding in a .ts declaration file through the source API', async () => {
    const sourcePath = 'prototypes/TravelBooking/state.ts'
    const app = fixture(behaviorSource, { sourcePath })
    const inspected = await app.call('GET', `/source?path=${encodeURIComponent(sourcePath)}`)
    expect(inspected.status).toBe(200)
    expect(inspected.data.controls[0]).toEqual({ id: 'payment-submit', action: 'payment-success', condition: 'payment-ready' })
    const updated = await app.call('POST', '/source/binding', {
      notebookId: inspected.data.notebookId, generation: inspected.data.generation,
      path: sourcePath, expectedRevision: inspected.data.revision, type: 'setBinding',
      controlId: 'payment-submit', actionId: 'payment-failure', conditionId: 'payment-failed',
    })
    expect(updated.status).toBe(200)
    expect(fs.readFileSync(app.absolutePath, 'utf8')).toContain("action: \"payment-failure\", condition: \"payment-failed\"")
    expect(updated.data.history).toEqual({ canUndo: true, canRedo: false })
    expect(app.events[0]).toMatchObject({ event: 'storyboard:source-updated', data: { path: sourcePath } })
  })

  it('rejects stale binding writes without mutating the declaration file', async () => {
    const sourcePath = 'prototypes/TravelBooking/state.ts'
    const app = fixture(behaviorSource, { sourcePath })
    const inspected = await app.call('GET', `/source?path=${encodeURIComponent(sourcePath)}`)
    const before = fs.readFileSync(app.absolutePath, 'utf8')
    const result = await app.call('POST', '/source/binding', {
      notebookId: inspected.data.notebookId, generation: inspected.data.generation,
      path: sourcePath, expectedRevision: '0'.repeat(64), type: 'setBinding',
      controlId: 'payment-submit', actionId: 'payment-failure', conditionId: null,
    })
    expect(result.status).toBe(409)
    expect(fs.readFileSync(app.absolutePath, 'utf8')).toBe(before)
  })

  it('rejects stale revisions, undeclared props, out-of-range values, malformed TSX, and missing targets without a source change', () => {
    const source = '<BookingCard title="Flight" columns={2} />'
    const inspection = inspectStoryboardSource('prototypes/booking.view.tsx', source, registrations)
    const target = { sourcePath: inspection.sourcePath, nodeId: inspection.nodes[0].nodeId }
    const command = { type: 'setProp', target, expectedRevision: inspection.revision, prop: 'title', value: 'New' }

    expect(() => editStoryboardProp(inspection.sourcePath, `${source}\n`, command, registrations)).toThrow(/changed since it was inspected/)
    expect(() => editStoryboardProp(inspection.sourcePath, source, { ...command, prop: 'onClick' }, registrations)).toThrow(/not editable/)
    expect(() => editStoryboardProp(inspection.sourcePath, source, { ...command, prop: 'columns', value: 9 }, registrations)).toThrow(/registered schema/)
    expect(() => inspectStoryboardSource(inspection.sourcePath, '<BookingCard title=', registrations)).toThrow(/syntax errors/)
    expect(() => editStoryboardProp(inspection.sourcePath, source, { ...command, target: { ...target, nodeId: 'missing' } }, registrations)).toThrow(/no longer exists/)
  })

  it('rejects attempts to edit the source identity attribute even when registered', () => {
    const source = '<BookingCard data-hc-node="stable-card" />'
    const inspection = inspectStoryboardSource('prototypes/booking.view.tsx', source, registrations)
    expect(() => editStoryboardProp('prototypes/booking.view.tsx', source, {
      type: 'setProp',
      target: { sourcePath: inspection.sourcePath, nodeId: inspection.nodes[0].nodeId },
      expectedRevision: inspection.revision,
      prop: 'data-hc-node',
      value: 'changed-card',
    }, registrations)).toThrow(/source identity metadata/)
  })

  it('deletes one direct child only when the parent schema permits it', () => {
    const source = 'const view = <BookingCard title="Flight"><CardTitle title="Keep" /><CardTitle title="Remove" /></BookingCard>\n'
    const inspection = inspectStoryboardSource('prototypes/booking.view.tsx', source, registrations)
    const result = deleteStoryboardNode(inspection.sourcePath, source, {
      type: 'deleteNode',
      target: { sourcePath: inspection.sourcePath, nodeId: inspection.nodes[2].nodeId },
      expectedRevision: inspection.revision,
    }, registrations)

    expect(result.source).toBe('const view = <BookingCard title="Flight"><CardTitle title="Keep" /></BookingCard>\n')
    expect(result.revision).not.toBe(inspection.revision)
  })

  it('rejects deleting roots, the last required child, and conditional children without changing source', () => {
    const rootSource = '<BookingCard title="Root" />'
    const rootInspection = inspectStoryboardSource('prototypes/booking.view.tsx', rootSource, registrations)
    expect(() => deleteStoryboardNode(rootInspection.sourcePath, rootSource, {
      type: 'deleteNode', target: { sourcePath: rootInspection.sourcePath, nodeId: rootInspection.nodes[0].nodeId }, expectedRevision: rootInspection.revision,
    }, registrations)).toThrow(/Root Storyboard nodes/)

    const childSource = '<BookingCard title="Flight"><CardTitle title="Only" /></BookingCard>'
    const childInspection = inspectStoryboardSource('prototypes/booking.view.tsx', childSource, registrations)
    expect(() => deleteStoryboardNode(childInspection.sourcePath, childSource, {
      type: 'deleteNode', target: { sourcePath: childInspection.sourcePath, nodeId: childInspection.nodes[1].nodeId }, expectedRevision: childInspection.revision,
    }, registrations)).toThrow(/requires at least 1 child/)

    const conditionalSource = '<BookingCard title="Flight">{visible && <CardTitle title="Maybe" />}<CardTitle title="Keep" /></BookingCard>'
    const conditionalInspection = inspectStoryboardSource('prototypes/booking.view.tsx', conditionalSource, registrations)
    expect(() => deleteStoryboardNode(conditionalInspection.sourcePath, conditionalSource, {
      type: 'deleteNode', target: { sourcePath: conditionalInspection.sourcePath, nodeId: conditionalInspection.nodes[1].nodeId }, expectedRevision: conditionalInspection.revision,
    }, registrations)).toThrow(/direct JSX children|opaque children/)
  })

  it('inserts a registered child at a schema-checked direct-child index with a fresh identity', () => {
    const source = 'const view = <BookingCard title="Flight"><CardTitle title="First" /><CardTitle title="Last" /></BookingCard>\n'
    const inspection = inspectStoryboardSource('prototypes/booking.view.tsx', source, registrations)
    const result = insertStoryboardNode(inspection.sourcePath, source, {
      type: 'insertNode',
      target: { sourcePath: inspection.sourcePath, nodeId: inspection.nodes[0].nodeId },
      expectedRevision: inspection.revision,
      slot: 'children',
      index: 1,
      component: 'CardTitle',
      props: { title: 'Inserted' },
    }, registrations)
    const after = inspectStoryboardSource(inspection.sourcePath, result.source, registrations)

    expect(result.source).toContain('<CardTitle data-hc-node=')
    expect(result.source).toContain('<CardTitle data-hc-node="' + result.nodeId + '" title={"Inserted"} />')
    expect(after.nodes.map(node => node.props.title)).toEqual(['Flight', 'First', 'Inserted', 'Last'])
    expect(after.nodes[2].nodeId).toBe(result.nodeId)
    expect(result.revision).not.toBe(inspection.revision)
  })

  it('rejects insertion into opaque, incompatible, overfull, or computed slot shapes', () => {
    const run = source => {
      const inspection = inspectStoryboardSource('prototypes/booking.view.tsx', source, registrations)
      return insertStoryboardNode(inspection.sourcePath, source, {
        type: 'insertNode', target: { sourcePath: inspection.sourcePath, nodeId: inspection.nodes[0].nodeId },
        expectedRevision: inspection.revision, slot: 'children', index: 0, component: 'CardTitle', props: {},
      }, registrations)
    }
    expect(() => run('<BookingCard title="Flight">{visible && <CardTitle />}</BookingCard>')).toThrow(/opaque JSX children/)
    expect(() => run('<BookingCard title="Flight"><Unknown /></BookingCard>')).toThrow(/opaque JSX children/)
    expect(() => run('<BookingCard title="Flight"><CardTitle /><CardTitle /><CardTitle /></BookingCard>')).toThrow(/at most 3/)
    expect(() => {
      const source = '<BookingCard title="Flight" />'
      const inspection = inspectStoryboardSource('prototypes/booking.view.tsx', source, registrations)
      insertStoryboardNode(inspection.sourcePath, source, {
        type: 'insertNode', target: { sourcePath: inspection.sourcePath, nodeId: inspection.nodes[0].nodeId },
        expectedRevision: inspection.revision, slot: 'children', index: 0, component: 'Unregistered', props: {},
      }, registrations)
    }).toThrow(/not registered/)
  })

  it('duplicates a direct child and assigns fresh stable identities throughout the copied subtree', () => {
    const source = 'const view = <BookingCard title="Flight"><CardTitle data-hc-node="original-title" title="First" /></BookingCard>\n'
    const inspection = inspectStoryboardSource('prototypes/booking.view.tsx', source, registrations)
    const result = duplicateStoryboardNode(inspection.sourcePath, source, {
      type: 'duplicateNode', target: { sourcePath: inspection.sourcePath, nodeId: 'original-title' },
      expectedRevision: inspection.revision, slot: 'children', index: 1,
    }, registrations)
    const after = inspectStoryboardSource(inspection.sourcePath, result.source, registrations)

    expect(after.nodes.map(node => node.component)).toEqual(['BookingCard', 'CardTitle', 'CardTitle'])
    expect(after.nodes.map(node => node.nodeId)).toContain('original-title')
    expect(after.nodes.map(node => node.nodeId)).toContain(result.nodeId)
    expect(result.nodeId).not.toBe('original-title')
    expect(result.source.match(/data-hc-node=/g)).toHaveLength(2)
    expect(after.nodes[2].props.title).toBe('First')
  })

  it('reorders only direct registered children while preserving unrelated source', () => {
    const source = 'const view = <BookingCard title="Flight"><CardTitle title="First" /><CardTitle title="Second" /></BookingCard>\n'
    const inspection = inspectStoryboardSource('prototypes/booking.view.tsx', source, registrations)
    const result = reorderStoryboardNode(inspection.sourcePath, source, {
      type: 'reorderNode', target: { sourcePath: inspection.sourcePath, nodeId: inspection.nodes[1].nodeId },
      expectedRevision: inspection.revision, index: 1,
    }, registrations)
    const after = inspectStoryboardSource(inspection.sourcePath, result.source, registrations)

    expect(after.nodes.map(node => node.props.title)).toEqual(['Flight', 'Second', 'First'])
    expect(result.source.startsWith('const view = ')).toBe(true)
    expect(() => reorderStoryboardNode(inspection.sourcePath, source, {
      type: 'reorderNode', target: { sourcePath: inspection.sourcePath, nodeId: inspection.nodes[1].nodeId },
      expectedRevision: inspection.revision, index: 3,
    }, registrations)).toThrow(/outside the target slot/)
  })

  it('reparents a direct child between schema-allowed parents and enforces parent constraints', () => {
    const source = '<BookingCard data-hc-node="outer" title="Outer"><BookingCard data-hc-node="inner" title="Inner"><CardTitle data-hc-node="move" title="Move" /><CardTitle title="Stay" /></BookingCard><CardTitle data-hc-node="keep" title="Keep" /></BookingCard>'
    const inspection = inspectStoryboardSource('prototypes/booking.view.tsx', source, registrations)
    const moved = reparentStoryboardNode(inspection.sourcePath, source, {
      type: 'reparentNode', target: { sourcePath: inspection.sourcePath, nodeId: 'move' },
      parent: { sourcePath: inspection.sourcePath, nodeId: 'outer' }, expectedRevision: inspection.revision,
      slot: 'children', index: 1,
    }, registrations)
    const after = inspectStoryboardSource(inspection.sourcePath, moved.source, registrations)

    expect(after.nodes.find(node => node.nodeId === 'outer').children).toContain('move')
    expect(after.nodes.find(node => node.nodeId === 'inner').children).not.toContain('move')
    expect(after.nodes.find(node => node.nodeId === 'inner').children).toHaveLength(1)

    expect(() => reparentStoryboardNode(inspection.sourcePath, source, {
      type: 'reparentNode', target: { sourcePath: inspection.sourcePath, nodeId: 'inner' },
      parent: { sourcePath: inspection.sourcePath, nodeId: 'move' }, expectedRevision: inspection.revision,
      slot: 'children', index: 0,
    }, registrations)).toThrow(/own descendant/)
  })

  it('serves inspect and revision-guarded atomic property edits for the active Notebook', async () => {
    const app = fixture()
    const inspected = await app.call('GET', '/source?path=prototypes%2Fbooking.view.tsx')
    expect(inspected.status).toBe(200)
    const updated = await app.call('POST', '/source/prop', {
      notebookId: inspected.data.notebookId,
      generation: inspected.data.generation,
      path: app.sourcePath,
      expectedRevision: inspected.data.revision,
      type: 'setProp',
      target: { sourcePath: app.sourcePath, nodeId: inspected.data.nodes[0].nodeId },
      prop: 'highlighted',
      value: true,
    })

    expect(updated.status).toBe(200)
    expect(fs.readFileSync(app.absolutePath, 'utf8')).toContain('highlighted={true}')
    expect(updated.data.revision).not.toBe(inspected.data.revision)
    expect(app.events[0]).toMatchObject({ event: 'storyboard:source-updated', data: { path: app.sourcePath } })
  })

  it('serves revision-guarded layout edits and exposes style fields in source inspection', async () => {
    const app = fixture('<BookingCard data-hc-node="card" title="Flight" style={{ gap: 4 }} />')
    const inspected = await app.call('GET', '/source?path=prototypes%2Fbooking.view.tsx')
    expect(inspected.data.nodes[0]).toMatchObject({ layout: { gap: 4 }, editableLayout: { gap: { type: 'number' } } })
    const updated = await app.call('POST', '/source/layout', {
      notebookId: inspected.data.notebookId, generation: inspected.data.generation,
      path: app.sourcePath, expectedRevision: inspected.data.revision, type: 'setLayout',
      target: { sourcePath: app.sourcePath, nodeId: 'card' }, field: 'gap', value: 12,
    })

    expect(updated.status).toBe(200)
    expect(fs.readFileSync(app.absolutePath, 'utf8')).toContain('style={{ gap: 12 }}')
  })

  it('keeps revision-guarded source undo and redo separate from URL state', async () => {
    const original = '<BookingCard data-hc-node="card" title="Original" />'
    const app = fixture(original)
    const inspected = await app.call('GET', '/source?path=prototypes%2Fbooking.view.tsx')
    expect(inspected.data.history).toEqual({ canUndo: false, canRedo: false })
    const edited = await app.call('POST', '/source/prop', {
      notebookId: inspected.data.notebookId, generation: inspected.data.generation,
      path: app.sourcePath, expectedRevision: inspected.data.revision, type: 'setProp',
      target: { sourcePath: app.sourcePath, nodeId: 'card' }, prop: 'title', value: 'Edited',
    })
    expect(edited.status).toBe(200)
    expect(edited.data.history).toEqual({ canUndo: true, canRedo: false })

    const afterEdit = fs.readFileSync(app.absolutePath, 'utf8')
    const staleUndo = await app.call('POST', '/source/undo', {
      notebookId: inspected.data.notebookId, generation: inspected.data.generation,
      path: app.sourcePath, expectedRevision: inspected.data.revision, type: 'undoSource',
    })
    expect(staleUndo.status).toBe(409)
    expect(fs.readFileSync(app.absolutePath, 'utf8')).toBe(afterEdit)

    const undone = await app.call('POST', '/source/undo', {
      notebookId: inspected.data.notebookId, generation: inspected.data.generation,
      path: app.sourcePath, expectedRevision: edited.data.revision, type: 'undoSource',
    })
    expect(undone.status).toBe(200)
    expect(undone.data.content).toBe(original)
    expect(undone.data.history).toEqual({ canUndo: false, canRedo: true })

    const staleRedo = await app.call('POST', '/source/redo', {
      notebookId: inspected.data.notebookId, generation: inspected.data.generation,
      path: app.sourcePath, expectedRevision: edited.data.revision, type: 'redoSource',
    })
    expect(staleRedo.status).toBe(409)
    expect(fs.readFileSync(app.absolutePath, 'utf8')).toBe(original)

    const redone = await app.call('POST', '/source/redo', {
      notebookId: inspected.data.notebookId, generation: inspected.data.generation,
      path: app.sourcePath, expectedRevision: undone.data.revision, type: 'redoSource',
    })
    expect(redone.status).toBe(200)
    expect(redone.data.content).toBe(afterEdit)
    expect(redone.data.history).toEqual({ canUndo: true, canRedo: false })
  })

  it('rejects source undo when the API history has no entry', async () => {
    const app = fixture()
    const inspected = await app.call('GET', '/source?path=prototypes%2Fbooking.view.tsx')
    const before = fs.readFileSync(app.absolutePath, 'utf8')
    const result = await app.call('POST', '/source/undo', {
      notebookId: inspected.data.notebookId, generation: inspected.data.generation,
      path: app.sourcePath, expectedRevision: inspected.data.revision, type: 'undoSource',
    })
    expect(result.status).toBe(409)
    expect(result.data.error.code).toBe('SOURCE_HISTORY_EMPTY')
    expect(fs.readFileSync(app.absolutePath, 'utf8')).toBe(before)
  })

  it('uses workspace-root scope to inspect and edit repository source when no Notebook is active', async () => {
    const app = fixture('<BookingCard title="Workspace" />', { activeNotebook: false })
    const inspected = await app.call('GET', '/source?path=prototypes%2Fbooking.view.tsx')
    expect(inspected.status).toBe(200)
    expect(inspected.data).toMatchObject({ notebookId: 'workspace-root', generation: 0, nodes: [{ props: { title: 'Workspace' } }] })

    const updated = await app.call('POST', '/source/prop', {
      notebookId: 'workspace-root',
      generation: 0,
      path: app.sourcePath,
      expectedRevision: inspected.data.revision,
      type: 'setProp',
      target: { sourcePath: app.sourcePath, nodeId: inspected.data.nodes[0].nodeId },
      prop: 'title',
      value: 'Edited workspace',
    })

    expect(updated.status).toBe(200)
    expect(fs.readFileSync(app.absolutePath, 'utf8')).toContain('title={"Edited workspace"}')
  })

  it('serves schema-checked deletion through the active source scope', async () => {
    const app = fixture('<BookingCard title="Flight"><CardTitle title="Keep" /><CardTitle title="Remove" /></BookingCard>')
    const inspected = await app.call('GET', '/source?path=prototypes%2Fbooking.view.tsx')
    const deleted = await app.call('POST', '/source/delete', {
      notebookId: inspected.data.notebookId,
      generation: inspected.data.generation,
      path: app.sourcePath,
      expectedRevision: inspected.data.revision,
      type: 'deleteNode',
      target: { sourcePath: app.sourcePath, nodeId: inspected.data.nodes[2].nodeId },
    })

    expect(deleted.status).toBe(200)
    expect(fs.readFileSync(app.absolutePath, 'utf8')).toBe('<BookingCard title="Flight"><CardTitle title="Keep" /></BookingCard>')
    expect(app.events[0]).toMatchObject({ event: 'storyboard:source-updated', data: { path: app.sourcePath } })
  })

  it('serves schema-checked insertion through the active source scope', async () => {
    const app = fixture('<BookingCard title="Flight"><CardTitle title="First" /></BookingCard>')
    const inspected = await app.call('GET', '/source?path=prototypes%2Fbooking.view.tsx')
    const inserted = await app.call('POST', '/source/insert', {
      notebookId: inspected.data.notebookId,
      generation: inspected.data.generation,
      path: app.sourcePath,
      expectedRevision: inspected.data.revision,
      type: 'insertNode',
      target: { sourcePath: app.sourcePath, nodeId: inspected.data.nodes[0].nodeId },
      slot: 'children',
      index: 1,
      component: 'CardTitle',
      props: { title: 'Second' },
    })

    expect(inserted.status).toBe(200)
    expect(inserted.data.nodeId).toEqual(expect.any(String))
    expect(fs.readFileSync(app.absolutePath, 'utf8')).toContain(`data-hc-node="${inserted.data.nodeId}" title={"Second"}`)
  })

  it('serves schema-checked duplication and returns the fresh node identity', async () => {
    const app = fixture('<BookingCard title="Flight"><CardTitle data-hc-node="first" title="First" /></BookingCard>')
    const inspected = await app.call('GET', '/source?path=prototypes%2Fbooking.view.tsx')
    const duplicated = await app.call('POST', '/source/duplicate', {
      notebookId: inspected.data.notebookId, generation: inspected.data.generation,
      path: app.sourcePath, expectedRevision: inspected.data.revision, type: 'duplicateNode',
      target: { sourcePath: app.sourcePath, nodeId: 'first' }, slot: 'children', index: 1,
    })

    expect(duplicated.status).toBe(200)
    expect(duplicated.data.nodeId).not.toBe('first')
    expect(fs.readFileSync(app.absolutePath, 'utf8').match(/data-hc-node=/g)).toHaveLength(2)
  })

  it('serves revision-guarded reparenting through the source route', async () => {
    const source = '<BookingCard data-hc-node="outer" title="Outer"><BookingCard data-hc-node="inner" title="Inner"><CardTitle data-hc-node="move" title="Move" /><CardTitle title="Stay" /></BookingCard><CardTitle data-hc-node="keep" title="Keep" /></BookingCard>'
    const app = fixture(source)
    const inspected = await app.call('GET', '/source?path=prototypes%2Fbooking.view.tsx')
    const updated = await app.call('POST', '/source/reparent', {
      notebookId: inspected.data.notebookId, generation: inspected.data.generation,
      path: app.sourcePath, expectedRevision: inspected.data.revision, type: 'reparentNode',
      target: { sourcePath: app.sourcePath, nodeId: 'move' },
      parent: { sourcePath: app.sourcePath, nodeId: 'outer' }, slot: 'children', index: 1,
    })

    expect(updated.status).toBe(200)
    const after = inspectStoryboardSource(app.sourcePath, fs.readFileSync(app.absolutePath, 'utf8'), registrations)
    expect(after.nodes.find(node => node.nodeId === 'outer').children).toContain('move')
    expect(after.nodes.find(node => node.nodeId === 'inner').children).not.toContain('move')
  })

  it('serves schema-checked reordering through the source route', async () => {
    const app = fixture('<BookingCard title="Flight"><CardTitle data-hc-node="first" title="First" /><CardTitle data-hc-node="second" title="Second" /></BookingCard>')
    const inspected = await app.call('GET', '/source?path=prototypes%2Fbooking.view.tsx')
    const reordered = await app.call('POST', '/source/reorder', {
      notebookId: inspected.data.notebookId, generation: inspected.data.generation,
      path: app.sourcePath, expectedRevision: inspected.data.revision, type: 'reorderNode',
      target: { sourcePath: app.sourcePath, nodeId: 'first' }, index: 1,
    })

    expect(reordered.status).toBe(200)
    const after = inspectStoryboardSource(app.sourcePath, fs.readFileSync(app.absolutePath, 'utf8'), registrations)
    expect(after.nodes.map(node => node.component)).toEqual(['BookingCard', 'CardTitle', 'CardTitle'])
    expect(after.nodes.slice(1).map(node => node.nodeId)).toEqual(['second', 'first'])
    expect(after.nodes.map(node => node.props.title)).toEqual(['Flight', 'Second', 'First'])
  })

  it('prefers an active Notebook source over the workspace-root fallback', async () => {
    const fallbackRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'hypercanvas-storyboard-fallback-'))
    const fallbackSource = path.join(fallbackRoot, 'prototypes/booking.view.tsx')
    fs.mkdirSync(path.dirname(fallbackSource), { recursive: true })
    fs.writeFileSync(fallbackSource, '<BookingCard title="Workspace fallback" />')
    const app = fixture('<BookingCard title="Active Notebook" />', { fallbackRoot })
    const inspected = await app.call('GET', '/source?path=prototypes%2Fbooking.view.tsx')

    expect(inspected.status).toBe(200)
    expect(inspected.data).toMatchObject({ notebookId: 'storyboard-source', generation: 3, nodes: [{ props: { title: 'Active Notebook' } }] })
  })

  it('rejects ambiguous scope and stale or unsafe writes without changing the file', async () => {
    const app = fixture('<BookingCard title="Flight" />')
    const inspected = await app.call('GET', '/source?path=prototypes%2Fbooking.view.tsx')
    const command = {
      notebookId: inspected.data.notebookId,
      generation: inspected.data.generation,
      path: app.sourcePath,
      expectedRevision: inspected.data.revision,
      type: 'setProp',
      target: { sourcePath: app.sourcePath, nodeId: inspected.data.nodes[0].nodeId },
      prop: 'title',
      value: 'Updated',
    }
    const before = fs.readFileSync(app.absolutePath, 'utf8')
    const stale = await app.call('POST', '/source/prop', { ...command, expectedRevision: '0'.repeat(64) })
    const scopeMismatch = await app.call('POST', '/source/prop', { ...command, generation: 2 })
    const pathTraversal = await app.call('POST', '/source/prop', { ...command, path: 'prototypes/../escape.tsx' })

    expect(stale.status).toBe(409)
    expect(scopeMismatch.status).toBe(409)
    expect(pathTraversal.status).toBe(400)
    expect(fs.readFileSync(app.absolutePath, 'utf8')).toBe(before)
  })

  it('serializes concurrent writes from one revision so only one can commit', async () => {
    const app = fixture('<BookingCard title="Flight" />')
    const inspected = await app.call('GET', '/source?path=prototypes%2Fbooking.view.tsx')
    const command = value => ({
      notebookId: inspected.data.notebookId,
      generation: inspected.data.generation,
      path: app.sourcePath,
      expectedRevision: inspected.data.revision,
      type: 'setProp',
      target: { sourcePath: app.sourcePath, nodeId: inspected.data.nodes[0].nodeId },
      prop: 'title',
      value,
    })
    const results = await Promise.all([
      app.call('POST', '/source/prop', command('One')),
      app.call('POST', '/source/prop', command('Two')),
    ])

    expect(results.map(result => result.status).sort()).toEqual([200, 409])
  })
})
