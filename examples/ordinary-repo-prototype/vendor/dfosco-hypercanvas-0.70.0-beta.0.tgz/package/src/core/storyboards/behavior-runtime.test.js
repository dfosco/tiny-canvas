import { describe, expect, it, vi } from 'vitest'
import { createStoryboardBehaviorExecutor } from './behavior-runtime.ts'

describe('Storyboard executable behavior', () => {
  it('applies only guarded actions through the caller-owned commit path', async () => {
    const commits = []
    const behavior = {
      conditions: {
        ready: { description: 'state is ready', reads: ['ready'], test: state => state.ready },
      },
      controls: {
        submit: { action: 'submit', condition: 'ready' },
      },
      actions: {
        submit: {
          writes: ['status'],
          run: async state => ({ ...state, status: 'done' }),
        },
      },
    }
    const executor = createStoryboardBehaviorExecutor(behavior, next => commits.push(next))

    expect(executor.isEnabled('submit', { ready: false, status: 'idle' })).toBe(false)
    expect(await executor.execute('submit', { ready: false, status: 'idle' }, undefined)).toBe(false)
    expect(commits).toEqual([])

    expect(await executor.execute('submit', { ready: true, status: 'idle' }, undefined)).toBe(true)
    expect(commits).toEqual([{ ready: true, status: 'done' }])
  })

  it('does not commit when an async action rejects', async () => {
    const commit = vi.fn()
    const executor = createStoryboardBehaviorExecutor({
      conditions: {},
      controls: { run: { action: 'run' } },
      actions: { run: { writes: ['status'], run: async () => { throw new Error('failed') } } },
    }, commit)

    await expect(executor.execute('run', { status: 'idle' }, undefined)).rejects.toThrow('failed')
    expect(commit).not.toHaveBeenCalled()
  })
})
