import { describe, expect, it } from 'vitest'
import { storyboardComponentRegistry } from './component-registry.ts'

describe('Storyboard component registry', () => {
  it('exposes semantic layout and the travel-booking Views to typed inspection', () => {
    expect(storyboardComponentRegistry.get('main')).toMatchObject({ kind: 'view' })
    expect(storyboardComponentRegistry.get('section')).toMatchObject({ kind: 'view' })
    expect(storyboardComponentRegistry.get('SearchView')).toMatchObject({
      kind: 'view',
      props: { heading: { type: 'text' } },
    })
    expect(storyboardComponentRegistry.get('ConfirmationView')).toMatchObject({ kind: 'view' })
  })

  it('keeps event handlers source-owned while exposing only schema-backed literal props', () => {
    const button = storyboardComponentRegistry.get('button')
    expect(button?.props.disabled).toEqual({ type: 'boolean' })
    expect(button?.props.type).toMatchObject({ type: 'enum', values: ['button', 'submit', 'reset'] })
    expect(button?.props.onClick).toBeUndefined()
  })
})
