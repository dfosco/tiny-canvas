import { afterEach, describe, expect, it } from 'vitest'
import { clearDraft, getDraft, replyDraftKey, saveDraft, composerDraftKey } from './commentDrafts.js'

const STORAGE_KEY = 'sb-comment-drafts'

afterEach(() => localStorage.removeItem(STORAGE_KEY))

describe('comment drafts', () => {
  it('uses stable route and comment keys', () => {
    expect(composerDraftKey('/Overview')).toBe('comment:/Overview')
    expect(replyDraftKey('comment-1')).toBe('reply:comment-1')
  })

  it('saves, reads, and clears drafts', () => {
    const key = composerDraftKey('/Overview')
    saveDraft(key, { type: 'comment', text: 'unfinished' })
    expect(getDraft(key)).toEqual({ type: 'comment', text: 'unfinished' })
    clearDraft(key)
    expect(getDraft(key)).toBeNull()
  })

  it('ignores persisted entries that do not match the draft contract', () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      valid: { type: 'reply', text: 'unfinished' },
      invalid: { type: 'other', text: 42 },
    }))
    expect(getDraft('valid')).toEqual({ type: 'reply', text: 'unfinished' })
    expect(getDraft('invalid')).toBeNull()
  })
})
