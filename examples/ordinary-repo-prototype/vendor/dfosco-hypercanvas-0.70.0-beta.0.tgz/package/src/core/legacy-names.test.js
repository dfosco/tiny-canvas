// @vitest-environment node
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import {
  APP_CONFIG_LEGACY,
  APP_CONFIG_PRIMARY,
  readAppConfig,
  readAppConfigRaw,
  resolveAppConfigPath,
} from './configFile.js'
import {
  LEGACY_RUNTIME_DIR_NAME,
  RUNTIME_DIR_NAME,
  resolveRuntimeDir,
} from './runtimeDir.js'
import { legacySessionEnv, withLegacySessionAliases } from './envCompat.js'

const temporary = []

function tempDir(prefix) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), prefix))
  temporary.push(dir)
  return dir
}

afterEach(() => {
  for (const dir of temporary.splice(0)) fs.rmSync(dir, { recursive: true, force: true })
  delete process.env.HYPERCANVAS_WIDGET_ID
  delete process.env.STORYBOARD_WIDGET_ID
})

describe('application config filename rename', () => {
  it('reads the legacy storyboard.config.json when no primary file exists', () => {
    const root = tempDir('legacy-config-')
    fs.writeFileSync(path.join(root, APP_CONFIG_LEGACY), '{"repository":{"name":"legacy"}}')
    const config = readAppConfig(root)
    expect(config.repository.name).toBe('legacy')
    expect(path.basename(resolveAppConfigPath(root))).toBe(APP_CONFIG_LEGACY)
  })

  it('prefers hypercanvas.config.json when both files exist', () => {
    const root = tempDir('dual-config-')
    fs.writeFileSync(path.join(root, APP_CONFIG_LEGACY), '{"repository":{"name":"legacy"}}')
    fs.writeFileSync(path.join(root, APP_CONFIG_PRIMARY), '{"repository":{"name":"primary"}}')
    expect(readAppConfig(root).repository.name).toBe('primary')
  })

  it('reads raw text with the legacy fallback and tolerates JSONC comments', () => {
    const root = tempDir('legacy-raw-')
    fs.writeFileSync(path.join(root, APP_CONFIG_LEGACY), '{\n  // comment\n  "devDomainColor": "#663399"\n}')
    expect(readAppConfigRaw(root)).toContain('devDomainColor')
    expect(readAppConfig(root).devDomainColor).toBe('#663399')
  })

  it('returns null when no config file exists', () => {
    expect(readAppConfig(tempDir('no-config-'))).toBeNull()
  })
})

describe('runtime directory rename', () => {
  it('keeps legacy Notebooks on .storyboard when it already exists', () => {
    const root = tempDir('legacy-runtime-')
    fs.mkdirSync(path.join(root, LEGACY_RUNTIME_DIR_NAME, 'terminals'), { recursive: true })
    expect(resolveRuntimeDir(root)).toBe(path.join(root, LEGACY_RUNTIME_DIR_NAME))
    expect(path.basename(resolveRuntimeDir(root))).toBe('.storyboard')
  })

  it('uses .hypercanvas for fresh Notebooks', () => {
    const root = tempDir('fresh-runtime-')
    expect(resolveRuntimeDir(root)).toBe(path.join(root, RUNTIME_DIR_NAME))
  })
})

describe('session environment aliases', () => {
  it('prefers the primary HYPERCANVAS_* name and falls back to STORYBOARD_*', () => {
    process.env.HYPERCANVAS_WIDGET_ID = 'primary'
    expect(legacySessionEnv('HYPERCANVAS_WIDGET_ID')).toBe('primary')

    delete process.env.HYPERCANVAS_WIDGET_ID
    process.env.STORYBOARD_WIDGET_ID = 'legacy'
    expect(legacySessionEnv('HYPERCANVAS_WIDGET_ID')).toBe('legacy')
  })

  it('adds legacy aliases for every primary name written to a child env', () => {
    const env = withLegacySessionAliases({
      HYPERCANVAS_WIDGET_ID: 'w',
      HYPERCANVAS_SERVER_URL: 'http://x',
      TERM_PROGRAM: 'hypercanvas',
    })
    expect(env.STORYBOARD_WIDGET_ID).toBe('w')
    expect(env.STORYBOARD_SERVER_URL).toBe('http://x')
    expect(env.TERM_PROGRAM).toBe('hypercanvas')
  })
})
