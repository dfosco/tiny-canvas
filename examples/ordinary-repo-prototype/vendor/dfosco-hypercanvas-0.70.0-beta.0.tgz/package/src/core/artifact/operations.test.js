// @vitest-environment node
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { createArtifact, deleteArtifact, editArtifact } from './operations.js'
import { createArtifactRoutes } from './routes.js'
import { initializeNotebook, inspectNotebook } from '../notebook/notebook.js'
import { SiteStore } from '../site/site.js'
import * as widgetLifecycle from '../canvas/widget-session-lifecycle.js'

const roots = []
function createRoot() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'storyboard-artifact-'))
  roots.push(root)
  return root
}
function notebook(title) {
  const root = createRoot()
  initializeNotebook(root, { title })
  return root
}
function canvasWithTerminal() {
  const root = notebook('Lifecycle')
  const created = createArtifact('canvas', { name: 'overview' }, root)
  const relativePath = 'canvas/overview.canvas.jsonl'
  const filePath = path.join(root, relativePath)
  const widget = { id: 'terminal-test', type: 'terminal', props: {}, position: { x: 0, y: 0 } }
  fs.appendFileSync(filePath, JSON.stringify({ event: 'widget_added', timestamp: new Date().toISOString(), widget }) + '\n')
  return { root, filePath, relativePath, widget, pageId: created.pageId }
}
function deferred() {
  let resolve, reject
  const promise = new Promise((onResolve, onReject) => { resolve = onResolve; reject = onReject })
  return { promise, resolve, reject }
}
afterEach(() => {
  vi.restoreAllMocks()
  roots.splice(0).forEach(root => fs.rmSync(root, { recursive: true, force: true }))
  delete globalThis.__HYPERCANVAS_NOTIFY_ARTIFACT_CHANGE__
})

describe('Notebook artifact ownership', () => {
  it('renames a module-only Notebook prototype without creating metadata or changing identity', () => {
    const root = notebook('Titles')
    const created = createArtifact('prototype', { name: 'welcome', title: 'Welcome' }, root)
    fs.unlinkSync(path.join(root, 'prototypes/welcome/welcome.prototype.json'))
    expect(editArtifact('prototype', 'welcome', { title: 'Renamed' }, root)).toMatchObject({ success: true, files: ['hypercanvas.notebook.json'] })
    expect(inspectNotebook(root).manifest.pages[0]).toMatchObject({ id: created.pageId, path: 'prototypes/welcome', title: 'Renamed' })
    expect(fs.existsSync(path.join(root, 'prototypes/welcome/welcome.prototype.json'))).toBe(false)
    expect(editArtifact('prototype', 'welcome', { description: 'Unsupported without metadata' }, root).success).toBe(false)
  })

  it('writes created artifacts to the Notebook content directories', () => {
    const root = notebook('Authoring')
    expect(createArtifact('canvas', { name: 'owned-canvas', title: 'Owned' }, root).success).toBe(true)
    expect(fs.existsSync(path.join(root, 'canvas/owned-canvas.canvas.jsonl'))).toBe(true)
    expect(fs.existsSync(path.join(root, 'src'))).toBe(false)
  })

  it('creates pages at the Notebook root, places them in virtual sections, and confirms page deletion', async () => {
    const root = notebook('Pages')
    const canvas = createArtifact('canvas', { name: 'overview', title: 'Overview', folder: 'Research' }, root)
    const prototype = createArtifact('prototype', { name: 'portal', title: 'Portal', folder: 'Research' }, root)
    expect(canvas.success).toBe(true)
    expect(prototype.success).toBe(true)
    expect(fs.existsSync(path.join(root, 'canvas', 'overview.canvas.jsonl'))).toBe(true)
    expect(fs.existsSync(path.join(root, 'canvas', 'Research'))).toBe(false)
    expect(fs.existsSync(path.join(root, 'prototypes', 'portal', 'portal.prototype.json'))).toBe(true)
    expect(fs.existsSync(path.join(root, 'prototypes', 'Research.folder'))).toBe(false)

    const state = inspectNotebook(root)
    const section = state.manifest.navigation.files.sections[0]
    expect(section.title).toBe('Research')
    expect(section.pageIds).toEqual([canvas.pageId, prototype.pageId])
    expect(state.pages.map(page => page.type)).toEqual(['canvas', 'prototype'])

    const oldId = canvas.pageId
    editArtifact('canvas', 'overview', { title: 'Updated Overview' }, root)
    expect(inspectNotebook(root).pages.find(page => page.id === oldId).title).toBe('Updated Overview')
    const preview = await deleteArtifact('canvas', 'overview', {}, root)
    expect(preview).toMatchObject({ success: false, code: 'CONFIRMATION_REQUIRED', affectedFiles: ['canvas/overview.canvas.jsonl'] })
    const deleted = await deleteArtifact('canvas', 'overview', { confirmedFiles: preview.affectedFiles }, root)
    expect(deleted.success).toBe(true)
    const remaining = inspectNotebook(root)
    expect(remaining.manifest.pages.map(page => page.id)).toEqual([prototype.pageId])
    expect(remaining.manifest.navigation.files.flatOrder).toEqual([prototype.pageId])
    expect(remaining.manifest.navigation.files.sections[0].pageIds).toEqual([prototype.pageId])
  })
})

describe('artifact CRUD operations', () => {
  it('edits and deletes a prototype while reporting changed files', async () => {
    const root = createRoot()
    expect(createArtifact('prototype', { name: 'demo', title: 'Demo' }, root).success).toBe(true)
    const edited = editArtifact('prototype', 'demo', { title: 'Updated' }, root)
    expect(edited.files).toEqual(['src/prototypes/demo/demo.prototype.json'])
    expect((await deleteArtifact('prototype', 'demo', {}, root)).files).toContain('src/prototypes/demo/demo.prototype.json')
  })

  it('updates and deletes canvases from root, page, and workspace layouts', async () => {
    const root = createRoot()
    expect(createArtifact('canvas', { name: 'root-canvas' }, root).success).toBe(true)
    expect(createArtifact('canvas', { name: 'overview', folder: 'tour', folderKind: 'pages' }, root).success).toBe(true)
    expect(createArtifact('canvas', { name: 'landing', folder: 'marketing', folderKind: 'workspace', jsx: true }, root).success).toBe(true)
    expect(editArtifact('canvas', 'landing', { folder: 'marketing', title: 'Landing Page' }, root).success).toBe(true)
    for (const [name, folder] of [['root-canvas', undefined], ['overview', 'tour'], ['landing', 'marketing']]) {
      expect((await deleteArtifact('canvas', name, { folder }, root)).success).toBe(true)
    }
  })

  it('removes a Site local runtime binding on delete', async () => {
    const root = createRoot()
    createArtifact('site', { name: 'docs', title: 'Docs', productionBaseUrl: 'https://docs.example' }, root)
    const store = new SiteStore(root)
    store.upsertBinding('docs', { source: 'managed', root, startCommand: 'npm run dev' })
    expect((await deleteArtifact('site', 'docs', {}, root)).success).toBe(true)
    expect(store.getBinding('docs')).toBeNull()
  })

  it('creates and edits Site description, local URL, run command, and deploy URL', () => {
    const root = createRoot()
    const created = createArtifact('site', {
      name: 'docs',
      title: 'Docs',
      description: 'Documentation',
      developmentBaseUrl: 'http://localhost:4317/docs',
      startCommand: 'npm run dev',
      productionBaseUrl: 'https://docs.example.com',
    }, root)
    expect(created).toMatchObject({
      success: true,
      site: {
        description: 'Documentation',
        deployments: { production: { baseUrl: 'https://docs.example.com/' } },
        binding: { source: 'url', developmentBaseUrl: 'http://localhost:4317/docs/', startCommand: 'npm run dev' },
      },
    })

    const updated = editArtifact('site', 'docs', {
      description: 'Updated documentation',
      developmentBaseUrl: 'http://127.0.0.1:4318/docs',
      startCommand: 'npm run preview',
      productionBaseUrl: 'https://docs.example.com/v2',
    }, root)
    expect(updated).toMatchObject({
      success: true,
      updated: {
        description: 'Updated documentation',
        deployments: { production: { baseUrl: 'https://docs.example.com/v2/' } },
        binding: { developmentBaseUrl: 'http://127.0.0.1:4318/docs/', startCommand: 'npm run preview' },
      },
    })
  })
})

describe('canvas deletion lifecycle', () => {
  it('previews confirmation without stopping sessions or changing the Notebook', async () => {
    const { root, filePath, relativePath, pageId } = canvasWithTerminal()
    const close = vi.spyOn(widgetLifecycle, 'closeWidgetSession').mockResolvedValue(undefined)

    await expect(deleteArtifact('canvas', 'overview', {}, root)).resolves.toMatchObject({
      success: false, code: 'CONFIRMATION_REQUIRED', affectedFiles: [relativePath],
    })

    expect(close).not.toHaveBeenCalled()
    expect(fs.existsSync(filePath)).toBe(true)
    expect(inspectNotebook(root).manifest.pages.map(page => page.id)).toContain(pageId)
  })

  it('waits for confirmed session closure before removing the canvas and its manifest entry', async () => {
    const { root, filePath, relativePath, widget, pageId } = canvasWithTerminal()
    const shutdown = deferred()
    const close = vi.spyOn(widgetLifecycle, 'closeWidgetSession').mockReturnValue(shutdown.promise)

    const deleting = deleteArtifact('canvas', 'overview', { confirmedFiles: [relativePath] }, root)
    const canvasExistsDuringShutdown = fs.existsSync(filePath)
    const pagesDuringShutdown = inspectNotebook(root).manifest.pages.map(page => page.id)
    shutdown.resolve()
    await expect(deleting).resolves.toMatchObject({ success: true, deleted: 'overview' })

    expect(close).toHaveBeenCalledExactlyOnceWith(root, 'overview', expect.objectContaining(widget))
    expect(canvasExistsDuringShutdown).toBe(true)
    expect(pagesDuringShutdown).toContain(pageId)
    expect(fs.existsSync(filePath)).toBe(false)
    expect(inspectNotebook(root).manifest.pages.map(page => page.id)).not.toContain(pageId)
  })

  it('preserves the canvas and manifest when session shutdown fails', async () => {
    const { root, filePath, relativePath } = canvasWithTerminal()
    const manifestPath = path.join(root, 'hypercanvas.notebook.json')
    const canvasBefore = fs.readFileSync(filePath, 'utf8')
    const manifestBefore = fs.readFileSync(manifestPath, 'utf8')
    vi.spyOn(widgetLifecycle, 'closeWidgetSession').mockRejectedValue(new Error('Paseo refused to close the terminal'))

    await expect(deleteArtifact('canvas', 'overview', { confirmedFiles: [relativePath] }, root)).resolves.toEqual({
      success: false, code: 'CANVAS_DELETE_FAILED', error: 'Paseo refused to close the terminal',
    })

    expect(fs.readFileSync(filePath, 'utf8')).toBe(canvasBefore)
    expect(fs.readFileSync(manifestPath, 'utf8')).toBe(manifestBefore)
  })
})

describe('artifact routes', () => {
  it.each([['successful', true], ['failed', false]])('awaits %s canvas shutdown before responding to HTTP deletion', async (_outcome, succeeds) => {
    const { root, filePath, relativePath } = canvasWithTerminal()
    const shutdown = deferred()
    vi.spyOn(widgetLifecycle, 'closeWidgetSession').mockReturnValue(shutdown.promise)
    const sendJson = vi.fn()
    const notify = vi.fn()
    globalThis.__HYPERCANVAS_NOTIFY_ARTIFACT_CHANGE__ = notify
    const handler = createArtifactRoutes({ root, sendJson })

    const request = handler({ url: 'http://localhost/' }, null, {
      method: 'DELETE', path: '/',
      body: { type: 'canvas', name: 'overview', confirmedFiles: [relativePath] },
    })
    const responsesBeforeShutdown = [...sendJson.mock.calls]
    const notificationsBeforeShutdown = [...notify.mock.calls]
    if (succeeds) shutdown.resolve()
    else shutdown.reject(new Error('Paseo refused to close the terminal'))
    await request

    expect(responsesBeforeShutdown).toEqual([])
    expect(notificationsBeforeShutdown).toEqual([])
    if (succeeds) {
      expect(sendJson).toHaveBeenCalledExactlyOnceWith(null, 200, expect.objectContaining({ success: true, deleted: 'overview' }))
      expect(notify).toHaveBeenCalledWith(filePath, 'unlink')
      expect(fs.existsSync(filePath)).toBe(false)
    } else {
      expect(sendJson).toHaveBeenCalledExactlyOnceWith(null, 400, {
        code: 'CANVAS_DELETE_FAILED', error: 'Paseo refused to close the terminal',
      })
      expect(notify).not.toHaveBeenCalled()
      expect(fs.existsSync(filePath)).toBe(true)
    }
  })

  it('delegates Site deletion to the lifecycle owner', async () => {
    const root = notebook('Sites')
    let response
    const deleteSite = vi.fn(async name => ({ success: true, deleted: name, files: ['.hypercanvas/sites.config.json'] }))
    const handler = createArtifactRoutes({
      root,
      sendJson: (_res, status, body) => { response = { status, body } },
      deleteSite,
    })

    await handler({ url: 'http://localhost/' }, null, {
      method: 'DELETE',
      path: '/',
      body: { type: 'site', name: 'docs' },
    })

    expect(deleteSite).toHaveBeenCalledWith('docs', {})
    expect(response).toEqual({
      status: 200,
      body: { success: true, deleted: 'docs', files: ['.hypercanvas/sites.config.json'] },
    })
  })

  it('notifies the data index after metadata updates and deletes', async () => {
    const root = createRoot()
    const notifications = []
    globalThis.__HYPERCANVAS_NOTIFY_ARTIFACT_CHANGE__ = (file, event) => notifications.push({ file: path.relative(root, file), event })
    let response
    const handler = createArtifactRoutes({ root, sendJson: (_res, status, body) => { response = { status, body } } })
    await handler({ url: 'http://localhost/' }, null, { method: 'POST', path: '/', body: { type: 'prototype', name: 'demo' } })
    await handler({ url: 'http://localhost/' }, null, { method: 'PATCH', path: '/', body: { type: 'prototype', name: 'demo', title: 'Updated' } })
    await handler({ url: 'http://localhost/' }, null, { method: 'DELETE', path: '/', body: { type: 'prototype', name: 'demo' } })
    expect(response.status).toBe(200)
    expect(notifications.map(item => item.event)).toEqual(expect.arrayContaining(['add', 'change', 'unlink']))
  })
})
