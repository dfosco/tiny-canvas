import { describe, expect, it, vi } from 'vitest'
import { getComponentInfo, getComponentChain, getFiberFromElement, inspectElement } from './fiberWalker.js'
import { createInspectorHighlighter } from './highlighter.js'
import { createMouseMode } from './mouseMode.js'

function Button() {}

function makeFiberTree() {
  const owner = { type: function Panel() {}, return: null, memoizedProps: {} }
  const component = {
    type: Button,
    return: owner,
    memoizedProps: { label: 'Save' },
    _debugSource: { fileName: 'Panel.jsx', lineNumber: 8, columnNumber: 3 },
    _debugOwner: owner,
  }
  const host = {
    type: 'button',
    return: component,
    memoizedProps: {},
    _debugSource: { fileName: 'Panel.jsx', lineNumber: 9, columnNumber: 5 },
  }
  return { owner, component, host }
}

describe('inspector fiber walker', () => {
  it('finds component, owner, host source, and ancestry from a DOM node', () => {
    const tree = makeFiberTree()
    const element = document.createElement('button')
    Object.defineProperty(element, '__reactFiber$test', { value: tree.host, enumerable: true })

    expect(getFiberFromElement(element)).toBe(tree.host)
    expect(inspectElement(element)).toMatchObject({
      name: 'Button',
      props: { label: 'Save' },
      owner: 'Panel',
      source: { fileName: 'Panel.jsx', lineNumber: 8, columnNumber: 3 },
      hostSource: { fileName: 'Panel.jsx', lineNumber: 9, columnNumber: 5 },
    })
    expect(getComponentInfo(tree.host)?.name).toBe('Button')
    expect(getComponentChain(tree.host).map(({ name }) => name)).toEqual(['Button', 'Panel'])
  })

  it('returns an empty result for non-React DOM nodes', () => {
    expect(getFiberFromElement(document.createElement('div'))).toBeNull()
  })
})

describe('inspector highlighter', () => {
  it('renders highlighted lines and optional line numbers', async () => {
    const highlighter = await createInspectorHighlighter()
    const html = highlighter.codeToHtml('const value = 1', {
      lang: 'javascript',
      decorations: [{ start: { line: 0 }, properties: { class: 'selected' } }],
    })
    expect(html).toContain('highlighted-line')
    expect(html).toContain('class="line-number"')
    expect(highlighter.codeToHtml('<tag>', { lineNumbers: false })).not.toContain('line-number')
  })
})

describe('inspector mouse mode', () => {
  it('selects the hovered element and cleans up listeners and overlays', () => {
    const onSelect = vi.fn()
    const onDeactivate = vi.fn()
    const element = document.createElement('button')
    document.body.appendChild(element)
    const mode = createMouseMode({ onSelect, onDeactivate })
    mode.activate()
    document.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, clientX: 10, clientY: 10 }))
    element.dispatchEvent(new MouseEvent('mousemove', { bubbles: true }))
    element.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }))

    expect(onSelect).toHaveBeenCalledWith(element)
    expect(onDeactivate).toHaveBeenCalledOnce()
    expect(mode.isActive()).toBe(false)
    expect(document.getElementById('sb-inspector-overlay')).toBeNull()
    element.remove()
  })

  it('keeps and removes an explicit persistent highlight', () => {
    const element = document.createElement('div')
    document.body.appendChild(element)
    const mode = createMouseMode()
    mode.showHighlight(element)
    expect(document.getElementById('sb-inspector-overlay')).not.toBeNull()
    mode.hideHighlight()
    expect(document.getElementById('sb-inspector-overlay')).toBeNull()
    element.remove()
  })
})
