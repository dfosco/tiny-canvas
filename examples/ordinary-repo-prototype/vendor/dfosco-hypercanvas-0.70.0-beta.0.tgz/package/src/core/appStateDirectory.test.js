import path from 'node:path'
import { describe, expect, it } from 'vitest'
import { resolveHypercanvasAppStateDirectory } from './appStateDirectory.js'

describe('Hypercanvas app-state directory', () => {
  it('uses the configured state directory when a host supplies one', () => {
    expect(resolveHypercanvasAppStateDirectory({
      environment: { HYPERCANVAS_APP_STATE_DIR: 'state' },
      platform: 'darwin',
      home: '/Users/test',
    })).toBe(path.resolve('state'))
  })

  it('uses the macOS Application Support directory without a wrapper', () => {
    expect(resolveHypercanvasAppStateDirectory({ environment: { HOME: '/Users/test' }, platform: 'darwin' }))
      .toBe('/Users/test/Library/Application Support/Hypercanvas')
  })

  it('uses roaming application data on Windows', () => {
    expect(resolveHypercanvasAppStateDirectory({
      environment: { APPDATA: 'C:\\Users\\test\\AppData\\Roaming' },
      platform: 'win32',
    })).toBe(path.resolve('C:\\Users\\test\\AppData\\Roaming', 'Hypercanvas'))
  })

  it('respects XDG_DATA_HOME on Linux', () => {
    expect(resolveHypercanvasAppStateDirectory({
      environment: { XDG_DATA_HOME: '/home/test/.data' },
      platform: 'linux',
    })).toBe('/home/test/.data/hypercanvas')
  })
})
