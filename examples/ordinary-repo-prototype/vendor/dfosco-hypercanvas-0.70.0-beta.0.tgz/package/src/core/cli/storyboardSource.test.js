import { describe, expect, it, vi } from 'vitest'
import { runStoryboardSourceCommand } from './storyboardSource.js'

describe('Storyboard source CLI', () => {
  it('maps inspect source path to the matching API query field', async () => {
    const request = { get: vi.fn().mockResolvedValue({ nodes: [] }), post: vi.fn() }
    await runStoryboardSourceCommand(['inspect', 'prototypes/booking.view.tsx'], request)
    expect(request.get).toHaveBeenCalledWith('/_hypercanvas/storyboards/source?path=prototypes%2Fbooking.view.tsx')
    expect(request.post).not.toHaveBeenCalled()
  })

  it('maps edit flags one-to-one to the typed command request fields', async () => {
    const request = { get: vi.fn(), post: vi.fn().mockResolvedValue({ revision: 'next' }) }
    await runStoryboardSourceCommand([
      'edit',
      '--notebook-id', 'nb-1',
      '--generation', '7',
      '--path', 'prototypes/booking.view.tsx',
      '--expected-revision', 'a'.repeat(64),
      '--target', '{"sourcePath":"prototypes/booking.view.tsx","nodeId":"jsx-12"}',
      '--prop', 'title',
      '--value', '"Flight"',
    ], request)

    expect(request.post).toHaveBeenCalledWith('/_hypercanvas/storyboards/source/prop', {
      notebookId: 'nb-1',
      generation: 7,
      path: 'prototypes/booking.view.tsx',
      expectedRevision: 'a'.repeat(64),
      type: 'setProp',
      target: { sourcePath: 'prototypes/booking.view.tsx', nodeId: 'jsx-12' },
      prop: 'title',
      value: 'Flight',
    })
  })

  it('maps layout flags one-to-one to the typed command request fields', async () => {
    const request = { get: vi.fn(), post: vi.fn().mockResolvedValue({ revision: 'next' }) }
    await runStoryboardSourceCommand([
      'layout', '--notebook-id', 'nb-1', '--generation', '7', '--path', 'prototypes/booking.view.tsx',
      '--expected-revision', 'a'.repeat(64), '--target', '{"sourcePath":"prototypes/booking.view.tsx","nodeId":"card"}',
      '--field', 'gap', '--value', '16',
    ], request)

    expect(request.post).toHaveBeenCalledWith('/_hypercanvas/storyboards/source/layout', {
      notebookId: 'nb-1', generation: 7, path: 'prototypes/booking.view.tsx', expectedRevision: 'a'.repeat(64),
      type: 'setLayout', target: { sourcePath: 'prototypes/booking.view.tsx', nodeId: 'card' }, field: 'gap', value: 16,
    })
  })

  it('maps a binding command one-to-one to the source API request', async () => {
    const request = { get: vi.fn(), post: vi.fn().mockResolvedValue({ revision: 'next' }) }
    await runStoryboardSourceCommand([
      'binding', '--notebook-id', 'nb-1', '--generation', '7', '--path', 'prototypes/TravelBooking/state.ts',
      '--expected-revision', 'a'.repeat(64), '--control-id', 'payment-submit', '--action-id', 'payment-failure',
      '--condition-id', '"payment-ready"',
    ], request)

    expect(request.post).toHaveBeenCalledWith('/_hypercanvas/storyboards/source/binding', {
      notebookId: 'nb-1', generation: 7, path: 'prototypes/TravelBooking/state.ts', expectedRevision: 'a'.repeat(64),
      type: 'setBinding', controlId: 'payment-submit', actionId: 'payment-failure', conditionId: 'payment-ready',
    })
  })

  it('maps undo and redo flags one-to-one to distinct source-history endpoints', async () => {
    const request = { get: vi.fn(), post: vi.fn().mockResolvedValue({ history: { canUndo: false, canRedo: true } }) }
    const shared = ['--notebook-id', 'nb-1', '--generation', '7', '--path', 'prototypes/booking.view.tsx', '--expected-revision', 'a'.repeat(64)]
    await runStoryboardSourceCommand(['undo', ...shared], request)
    await runStoryboardSourceCommand(['redo', ...shared], request)

    expect(request.post).toHaveBeenNthCalledWith(1, '/_hypercanvas/storyboards/source/undo', {
      notebookId: 'nb-1', generation: 7, path: 'prototypes/booking.view.tsx', expectedRevision: 'a'.repeat(64), type: 'undoSource',
    })
    expect(request.post).toHaveBeenNthCalledWith(2, '/_hypercanvas/storyboards/source/redo', {
      notebookId: 'nb-1', generation: 7, path: 'prototypes/booking.view.tsx', expectedRevision: 'a'.repeat(64), type: 'redoSource',
    })
  })

  it('maps delete flags one-to-one to the typed command request fields', async () => {
    const request = { get: vi.fn(), post: vi.fn().mockResolvedValue({ revision: 'next' }) }
    await runStoryboardSourceCommand([
      'delete',
      '--notebook-id', 'nb-1',
      '--generation', '7',
      '--path', 'prototypes/booking.view.tsx',
      '--expected-revision', 'a'.repeat(64),
      '--target', '{"sourcePath":"prototypes/booking.view.tsx","nodeId":"booking-card"}',
    ], request)

    expect(request.post).toHaveBeenCalledWith('/_hypercanvas/storyboards/source/delete', {
      notebookId: 'nb-1',
      generation: 7,
      path: 'prototypes/booking.view.tsx',
      expectedRevision: 'a'.repeat(64),
      type: 'deleteNode',
      target: { sourcePath: 'prototypes/booking.view.tsx', nodeId: 'booking-card' },
    })
  })

  it('maps insert flags one-to-one to the typed command request fields', async () => {
    const request = { get: vi.fn(), post: vi.fn().mockResolvedValue({ revision: 'next' }) }
    await runStoryboardSourceCommand([
      'insert', '--notebook-id', 'nb-1', '--generation', '7', '--path', 'prototypes/booking.view.tsx',
      '--expected-revision', 'a'.repeat(64), '--target', '{"sourcePath":"prototypes/booking.view.tsx","nodeId":"parent"}',
      '--slot', 'children', '--index', '2', '--component', 'CardTitle', '--props', '{"title":"Inserted"}',
    ], request)

    expect(request.post).toHaveBeenCalledWith('/_hypercanvas/storyboards/source/insert', {
      notebookId: 'nb-1', generation: 7, path: 'prototypes/booking.view.tsx', expectedRevision: 'a'.repeat(64),
      type: 'insertNode', target: { sourcePath: 'prototypes/booking.view.tsx', nodeId: 'parent' },
      slot: 'children', index: 2, component: 'CardTitle', props: { title: 'Inserted' },
    })
  })

  it('maps duplicate flags one-to-one to the typed command request fields', async () => {
    const request = { get: vi.fn(), post: vi.fn().mockResolvedValue({ revision: 'next' }) }
    await runStoryboardSourceCommand([
      'duplicate', '--notebook-id', 'nb-1', '--generation', '7', '--path', 'prototypes/booking.view.tsx',
      '--expected-revision', 'a'.repeat(64), '--target', '{"sourcePath":"prototypes/booking.view.tsx","nodeId":"first"}',
      '--slot', 'children', '--index', '1',
    ], request)

    expect(request.post).toHaveBeenCalledWith('/_hypercanvas/storyboards/source/duplicate', {
      notebookId: 'nb-1', generation: 7, path: 'prototypes/booking.view.tsx', expectedRevision: 'a'.repeat(64),
      type: 'duplicateNode', target: { sourcePath: 'prototypes/booking.view.tsx', nodeId: 'first' },
      slot: 'children', index: 1,
    })
  })

  it('maps reorder flags one-to-one to the typed command request fields', async () => {
    const request = { get: vi.fn(), post: vi.fn().mockResolvedValue({ revision: 'next' }) }
    await runStoryboardSourceCommand([
      'reorder', '--notebook-id', 'nb-1', '--generation', '7', '--path', 'prototypes/booking.view.tsx',
      '--expected-revision', 'a'.repeat(64), '--target', '{"sourcePath":"prototypes/booking.view.tsx","nodeId":"first"}',
      '--index', '1',
    ], request)

    expect(request.post).toHaveBeenCalledWith('/_hypercanvas/storyboards/source/reorder', {
      notebookId: 'nb-1', generation: 7, path: 'prototypes/booking.view.tsx', expectedRevision: 'a'.repeat(64),
      type: 'reorderNode', target: { sourcePath: 'prototypes/booking.view.tsx', nodeId: 'first' }, index: 1,
    })
  })

  it('maps reparent flags one-to-one to the typed command request fields', async () => {
    const request = { get: vi.fn(), post: vi.fn().mockResolvedValue({ revision: 'next' }) }
    await runStoryboardSourceCommand([
      'reparent', '--notebook-id', 'nb-1', '--generation', '7', '--path', 'prototypes/booking.view.tsx',
      '--expected-revision', 'a'.repeat(64), '--target', '{"sourcePath":"prototypes/booking.view.tsx","nodeId":"moving"}',
      '--parent', '{"sourcePath":"prototypes/booking.view.tsx","nodeId":"parent"}', '--slot', 'children', '--index', '2',
    ], request)

    expect(request.post).toHaveBeenCalledWith('/_hypercanvas/storyboards/source/reparent', {
      notebookId: 'nb-1', generation: 7, path: 'prototypes/booking.view.tsx', expectedRevision: 'a'.repeat(64),
      type: 'reparentNode', target: { sourcePath: 'prototypes/booking.view.tsx', nodeId: 'moving' },
      parent: { sourcePath: 'prototypes/booking.view.tsx', nodeId: 'parent' }, slot: 'children', index: 2,
    })
  })

  it('rejects incomplete or malformed command arguments before making a request', async () => {
    const request = { get: vi.fn(), post: vi.fn() }
    await expect(runStoryboardSourceCommand(['edit', '--generation', '7'], request)).rejects.toThrow(/Usage:/)
    await expect(runStoryboardSourceCommand(['edit', '--notebook-id', 'nb', '--generation', '7', '--path', 'prototypes/x.tsx', '--expected-revision', 'a', '--prop', 'title', '--target', 'bad', '--value', '"x"'], request)).rejects.toThrow(/valid JSON/)
    await expect(runStoryboardSourceCommand(['layout', '--notebook-id', 'nb', '--generation', '7', '--path', 'prototypes/x.tsx', '--expected-revision', 'a', '--field', 'gap', '--target', '{}', '--value', 'bad'], request)).rejects.toThrow(/valid JSON/)
    await expect(runStoryboardSourceCommand(['delete', '--notebook-id', 'nb', '--generation', '7', '--path', 'prototypes/x.tsx', '--expected-revision', 'a', '--target', 'bad'], request)).rejects.toThrow(/valid JSON/)
    await expect(runStoryboardSourceCommand(['insert', '--notebook-id', 'nb', '--generation', '7', '--path', 'prototypes/x.tsx', '--expected-revision', 'a', '--target', '{}', '--slot', 'children', '--index', '0', '--component', 'X', '--props', 'bad'], request)).rejects.toThrow(/valid JSON/)
    expect(request.post).not.toHaveBeenCalled()
  })
})
