import { describe, expect, it, vi } from 'vitest'
import { get } from './cliHelpers.js'
import { hostToolsHelp, runHostToolsCommand } from './hostTools.js'

function request() {
  return { get: vi.fn(async (path) => ({ method: 'GET', path })) }
}

describe('host tools CLI', () => {
  it('maps preflight directly to the read-only diagnostics route', async () => {
    const api = request()
    await expect(runHostToolsCommand(['preflight'], api)).resolves.toEqual({ method: 'GET', path: '/_hypercanvas/host-tools/preflight' })
    expect(api.get).toHaveBeenCalledOnce()
  })

  it.each(['plan', 'install', 'status', 'cancel'])('rejects retired host-tools %s command', async (command) => {
    const api = request()
    await expect(runHostToolsCommand([command])).rejects.toThrow(`Unknown host-tools command: ${command}`)
    expect(api.get).not.toHaveBeenCalled()
  })

  it('provides only diagnostic help without making a request', async () => {
    const api = request()
    expect(hostToolsHelp()).toContain('preflight')
    expect(hostToolsHelp()).not.toMatch(/\b(install|plan|cancel|status)\b/i)
    await expect(runHostToolsCommand(['--help'], api)).resolves.toMatchObject({ help: expect.stringContaining('preflight') })
    expect(api.get).not.toHaveBeenCalled()
  })

  it('uses the explicit workspace service URL with its branch base path', async () => {
    const previousBase = process.env.VITE_BASE_PATH
    const previousServer = process.env.STORYBOARD_SERVER_URL
    const previousHypercanvas = process.env.HYPERCANVAS_SERVER_URL
    process.env.VITE_BASE_PATH = '/branch--feature/'
    process.env.HYPERCANVAS_SERVER_URL = 'http://localhost:4321/branch--feature/'
    delete process.env.STORYBOARD_SERVER_URL
    const fetch = vi.fn(async () => ({ ok: true, json: async () => ({ status: 'supported' }) }))
    vi.stubGlobal('fetch', fetch)

    try {
      await get('/_hypercanvas/host-tools/preflight')
      expect(fetch.mock.calls[0][0]).toBe('http://localhost:4321/branch--feature/_hypercanvas/host-tools/preflight')
    } finally {
      if (previousBase === undefined) delete process.env.VITE_BASE_PATH
      else process.env.VITE_BASE_PATH = previousBase
      if (previousServer === undefined) delete process.env.STORYBOARD_SERVER_URL
      else process.env.STORYBOARD_SERVER_URL = previousServer
      if (previousHypercanvas === undefined) delete process.env.HYPERCANVAS_SERVER_URL
      else process.env.HYPERCANVAS_SERVER_URL = previousHypercanvas
    }
  })
})
