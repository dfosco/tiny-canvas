import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import notebookRoutesPlugin from './vite-routes-plugin.js'

const roots = []

function notebook() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'hypercanvas-routes-'))
  roots.push(root)
  fs.mkdirSync(path.join(root, 'prototypes', 'Landing'), { recursive: true })
  fs.writeFileSync(path.join(root, 'prototypes', 'Landing', 'index.jsx'), 'export default function Landing() {}')
  return root
}

afterEach(() => {
  delete process.env.HYPERCANVAS_NOTEBOOK_ROOT
  for (const root of roots.splice(0)) fs.rmSync(root, { recursive: true, force: true })
})

describe('notebook route Vite plugin', () => {
  it('maps external prototype modules to their router keys', () => {
    const root = notebook()
    process.env.HYPERCANVAS_NOTEBOOK_ROOT = root
    const plugin = notebookRoutesPlugin()
    const source = plugin.load('\0virtual:hypercanvas-notebook-routes')

    expect(source).toContain('"/src/prototypes/Landing/index.jsx"')
    expect(source).not.toContain('/src/prototypes/prototypes/')
    expect(source).toContain(path.join(root, 'prototypes', 'Landing', 'index.jsx'))
  })

  it('discovers public prototype layouts while excluding private underscore helpers', () => {
    const root = notebook()
    const prototypeDir = path.join(root, 'prototypes', 'Landing')
    const privateDir = path.join(prototypeDir, '_private')
    fs.mkdirSync(privateDir, { recursive: true })
    fs.writeFileSync(path.join(prototypeDir, '_layout.jsx'), 'export default function Layout() {}')
    fs.writeFileSync(path.join(prototypeDir, '_private.jsx'), 'export default function Helper() {}')
    fs.writeFileSync(path.join(privateDir, '_layout.jsx'), 'export default function PrivateLayout() {}')
    process.env.HYPERCANVAS_NOTEBOOK_ROOT = root
    const plugin = notebookRoutesPlugin()
    const source = plugin.load('\0virtual:hypercanvas-notebook-routes')

    expect(source).toContain('"/src/prototypes/Landing/_layout.jsx"')
    expect(source).not.toContain('"/src/prototypes/Landing/_private.jsx"')
    expect(source).not.toContain('"/src/prototypes/Landing/_private/_layout.jsx"')
  })

  it('keeps the runtime and generated route parents on the same retained-frame contract', () => {
    const files = [
      path.resolve(process.cwd(), 'src/library/routes.jsx'),
      path.resolve(process.cwd(), 'packages/storyboard/scaffold/src/library/routes.jsx'),
    ]
    for (const file of files) {
      const source = fs.readFileSync(file, 'utf8')
      expect(source).toMatch(/const prototypeRoutes = generateRegularRoutes[\s\S]*?Component: \(\) => null/)
      expect(source).toMatch(/const prototypeLayoutRoute = \{[\s\S]*?Component: \(\) => <ContentFrame kind="prototype" \/>/)
    }
  })

  it('uses flow-declared routes for prototype index modules', () => {
    const root = notebook()
    fs.writeFileSync(path.join(root, 'prototypes', 'Landing', 'success.flow.json'), JSON.stringify({ route: '/StartupSignup' }))
    process.env.HYPERCANVAS_NOTEBOOK_ROOT = root
    const plugin = notebookRoutesPlugin()
    const source = plugin.load('\0virtual:hypercanvas-notebook-routes')

    expect(source).toContain('"/src/prototypes/StartupSignup/index.jsx"')
  })

  it('discovers .view.tsx source modules separately from routed prototype pages', () => {
    const root = notebook()
    const view = path.join(root, 'prototypes', 'TravelBooking', 'Checkout.view.tsx')
    fs.mkdirSync(path.dirname(view), { recursive: true })
    fs.writeFileSync(view, 'export default function Checkout() { return null }')
    process.env.HYPERCANVAS_NOTEBOOK_ROOT = root
    const plugin = notebookRoutesPlugin()
    const source = plugin.load('\0virtual:hypercanvas-notebook-routes')

    expect(source).toContain('export const STORYBOARD_VIEWS')
    expect(source).toContain('"TravelBooking/Checkout": () => import(')
    expect(source).toContain(view)
    expect(source).not.toContain('"/src/prototypes/TravelBooking/Checkout.view.tsx"')
  })

  it('discovers Storyboard view modules from a consumer source root', () => {
    const project = fs.mkdtempSync(path.join(os.tmpdir(), 'hypercanvas-consumer-'))
    roots.push(project)
    const sourceRoot = path.join(project, 'src')
    const view = path.join(sourceRoot, 'prototypes', 'Landing', 'Home.view.tsx')
    fs.mkdirSync(path.dirname(view), { recursive: true })
    fs.writeFileSync(view, 'export default function Home() { return null }')
    const previousCwd = process.cwd()
    process.chdir(project)
    try {
      process.env.HYPERCANVAS_NOTEBOOK_ROOT = ''
      const plugin = notebookRoutesPlugin()
      const source = plugin.load('\0virtual:hypercanvas-notebook-routes')

      expect(source).toContain('"Landing/Home": () => import(')
      expect(source).toContain(path.join(sourceRoot, 'prototypes', 'Landing', 'Home.view.tsx'))
    } finally {
      process.chdir(previousCwd)
    }
  })

  it('invalidates routes when the active Notebook changes', () => {
    const root = notebook()
    process.env.HYPERCANVAS_NOTEBOOK_ROOT = root
    const listeners = {}
    const server = {
      moduleGraph: { getModuleById: () => null },
      watcher: { on: (event, listener) => { listeners[event] = listener } },
      ws: { send: vi.fn() },
    }
    const plugin = notebookRoutesPlugin()
    plugin.configureServer(server)

    server.__hypercanvasNotebookRoutesReload()
    expect(server.ws.send).toHaveBeenCalledWith({ type: 'full-reload' })

    // Edits to existing components/styles are owned by Fast Refresh.
    for (const filename of ['Home.view.tsx', 'index.jsx', 'helper.mts', 'style.module.css']) {
      listeners.change(path.join(root, 'prototypes', 'Landing', filename))
    }
    expect(server.ws.send).toHaveBeenCalledTimes(1)

    // A flow route edit really can change route keys.
    listeners.change(path.join(root, 'prototypes', 'Landing', 'success.flow.json'))
    expect(server.ws.send).toHaveBeenCalledTimes(2)

    // New/removed source files still change the module route inventory.
    listeners.add(path.join(root, 'prototypes', 'Landing', 'New.view.tsx'))
    listeners.unlink(path.join(root, 'prototypes', 'Landing', 'Old.view.tsx'))
    expect(server.ws.send).toHaveBeenCalledTimes(4)
  })
})
