import { describe, expect, it, vi } from 'vitest'
import { createHostToolsBrowserClient, hostToolsApiBase } from './browser-client.js'

function jsonResponse(payload, { ok = true, status = 200 } = {}) {
  return { ok, status, json: vi.fn().mockResolvedValue(payload) }
}

describe('read-only host-tools browser client', () => {
  it('keeps diagnostics under a branch base path', async () => {
    const fetchImpl = vi.fn().mockResolvedValue(jsonResponse({ status: 'supported' }))
    const client = createHostToolsBrowserClient({ fetchImpl, basePath: '/branch--feature/' })

    await client.preflight()

    expect(fetchImpl).toHaveBeenCalledWith('/branch--feature/_hypercanvas/host-tools/preflight', { method: 'GET' })
    expect(hostToolsApiBase('/')).toBe('/_hypercanvas/host-tools')
    expect(client).not.toHaveProperty('install')
  })

  it('surfaces a safe diagnostics failure', async () => {
    const fetchImpl = vi.fn().mockResolvedValue(jsonResponse({
      error: { message: 'Host tool diagnostics failed' },
    }, { ok: false, status: 500 }))
    const client = createHostToolsBrowserClient({ fetchImpl })

    await expect(client.preflight()).rejects.toMatchObject({
      status: 500,
      message: 'Host tool diagnostics failed',
    })
  })
})
