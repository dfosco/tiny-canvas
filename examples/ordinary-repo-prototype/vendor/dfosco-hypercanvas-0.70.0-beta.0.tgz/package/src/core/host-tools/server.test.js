import { describe, expect, it, vi } from 'vitest'
import { createHostToolsHandler } from './server.js'

function setup(overrides = {}) {
  const preflight = overrides.preflight || vi.fn(async () => ({ status: 'supported' }))
  const response = { status: null, body: null }
  const handler = createHostToolsHandler({
    preflight,
    sendJson: (_res, status, body) => Object.assign(response, { status, body }),
  })
  async function invoke(method, path) {
    response.status = null
    response.body = null
    await handler({ method }, {}, { method, path })
    return { ...response }
  }
  return { preflight, invoke }
}

describe('read-only host tools server handler', () => {
  it('serves preflight diagnostics', async () => {
    const { invoke, preflight } = setup()
    expect(await invoke('GET', '/preflight')).toEqual({ status: 200, body: { status: 'supported' } })
    expect(preflight).toHaveBeenCalledOnce()
  })

  it.each([
    ['POST', '/preflight'],
    ['POST', '/plan'],
    ['POST', '/install'],
    ['GET', '/operations/op-1'],
    ['POST', '/operations/op-1/cancel'],
  ])('retires installer route %s %s', async (method, path) => {
    const { invoke, preflight } = setup()
    expect(await invoke(method, path)).toMatchObject({ status: 404, body: { error: { code: 'ROUTE_NOT_FOUND' } } })
    expect(preflight).not.toHaveBeenCalled()
  })

  it('does not expose preflight exceptions', async () => {
    const { invoke } = setup({ preflight: vi.fn(async () => { throw new Error('secret path') }) })
    const result = await invoke('GET', '/preflight')
    expect(result).toEqual({ status: 500, body: { error: { code: 'HOST_TOOLS_FAILED', message: 'Host tool diagnostics failed' } } })
    expect(JSON.stringify(result)).not.toContain('secret path')
  })
})
