import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { list, registryPath } from './serverRegistry.js'

const roots = []

afterEach(() => {
  for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true })
})

describe('worktree server registry', () => {
  it('keeps valid persisted entries and drops malformed entries during pruning', () => {
    const root = mkdtempSync(join(tmpdir(), 'hypercanvas-server-registry-'))
    roots.push(root)
    const file = registryPath(root)
    mkdirSync(join(root, '.hypercanvas'), { recursive: true })
    writeFileSync(file, JSON.stringify({
      servers: {
        alive: {
          id: 'alive',
          worktree: 'feature',
          pid: process.pid,
          port: 4321,
          background: false,
          startedAt: '2026-10-09T00:00:00.000Z',
        },
        malformed: { id: 'malformed', worktree: 'feature', pid: 'not-a-pid', port: 4322 },
      },
    }))

    expect(list(root)).toEqual([expect.objectContaining({ id: 'alive', port: 4321 })])
    expect(JSON.parse(readFileSync(file, 'utf8')).servers).toEqual({
      alive: expect.objectContaining({ pid: process.pid }),
    })
  })
})
