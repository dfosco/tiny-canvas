// @vitest-environment node
import path from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { loadConfigFromFile } from 'vite'
import configFactory from '../../../../../vite.config.js'

const envKey = 'STORYBOARD_VITE_CACHE_DIR'
const notebookRootKey = 'HYPERCANVAS_NOTEBOOK_ROOT'
const originalNotebookRoot = process.env[notebookRootKey]
const callConfig = () => configFactory({ command: 'serve', mode: 'development' })

afterEach(() => {
  delete process.env[envKey]
  if (originalNotebookRoot === undefined) delete process.env[notebookRootKey]
  else process.env[notebookRootKey] = originalNotebookRoot
})

describe('vite cacheDir wiring', () => {
  it('resolves cacheDir from STORYBOARD_VITE_CACHE_DIR when set', () => {
    process.env[envKey] = '/tmp/hypercanvas-cache-probe'
    expect(callConfig().cacheDir).toBe(path.resolve('/tmp/hypercanvas-cache-probe'))
  })

  it('leaves cacheDir undefined so vite keeps its default when unset', () => {
    delete process.env[envKey]
    expect(callConfig().cacheDir).toBeUndefined()
  })
})

describe('external Notebook config', () => {
  it('loads Vite config when the Notebook has no application-level storyboard config', async () => {
    const root = path.resolve('fixtures/notebooks/empty-notebook')
    process.env[notebookRootKey] = root
    const loaded = await loadConfigFromFile(
      { command: 'serve', mode: 'development' },
      path.resolve('vite.config.js'),
    )
    expect(loaded?.config).toBeTruthy()
  })
})
