import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { compactCanvas, findCanvasFiles } from './compact.js'
import { materializeFromText } from './materializer.js'

const roots = []

afterEach(() => {
  for (const root of roots.splice(0)) fs.rmSync(root, { recursive: true, force: true })
})

describe('Notebook canvas compaction discovery', () => {
  it('discovers canvases from the content-only canvas directory', () => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'sb-compact-notebook-'))
    roots.push(root)
    fs.mkdirSync(path.join(root, 'canvas', 'Folder'), { recursive: true })
    fs.writeFileSync(path.join(root, 'canvas', 'Folder', 'page.canvas.jsonl'), '{}\n')

    expect(findCanvasFiles(root)).toEqual([{
      name: path.join('Folder', 'page'),
      filePath: path.join(root, 'canvas', 'Folder', 'page.canvas.jsonl'),
      size: 3,
    }])
  })
})

describe('canvas format compaction guard', () => {
  it('keeps an unsupported canvas unchanged during forced compaction', () => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'sb-compact-version-'))
    roots.push(root)
    const filePath = path.join(root, 'future.canvas.jsonl')
    const raw = '{"event":"canvas_created","formatVersion":7,"widgets":[]}\n'
    fs.writeFileSync(filePath, raw)

    expect(() => compactCanvas(filePath, { force: true })).toThrow('Unsupported canvas formatVersion: 7')
    expect(fs.readFileSync(filePath, 'utf8')).toBe(raw)
  })

  it('preserves v2 format, scroll axis and materialized geometry in a compact baseline', () => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'sb-compact-v2-'))
    roots.push(root)
    const filePath = path.join(root, 'layout.canvas.jsonl')
    const source = fs.readFileSync(path.resolve(process.cwd(), 'packages/storyboard/test/fixtures/canvas-document/v2-layout.jsonl'), 'utf8')
    fs.writeFileSync(filePath, source)

    compactCanvas(filePath, { force: true })
    const compacted = fs.readFileSync(filePath, 'utf8')
    expect(JSON.parse(compacted).formatVersion).toBe(2)
    expect(materializeFromText(compacted)).toMatchObject({
      scroll: { axis: 'vertical' },
      widgets: [{ id: 'note-1', position: { x: 24, y: 24 }, props: { width: 300, height: 160 } }, { id: 'frame-1', position: { x: 24, y: 200 } }],
      sources: [{ export: 'PrimaryButtons', position: { x: 24, y: 824 }, width: 560, height: 400 }],
    })
  })

  it('compacts an undo restoration to the restored v2 state and discards its history', () => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'sb-compact-v2-restored-'))
    roots.push(root)
    const filePath = path.join(root, 'layout-restored.canvas.jsonl')
    const source = fs.readFileSync(path.resolve(process.cwd(), 'packages/storyboard/test/fixtures/canvas-document/v2-layout-restored.jsonl'), 'utf8')
    fs.writeFileSync(filePath, source)

    compactCanvas(filePath, { force: true })
    const compacted = fs.readFileSync(filePath, 'utf8')
    const event = JSON.parse(compacted)
    expect(event.event).toBe('canvas_created')
    expect(event.formatVersion).toBe(2)
    expect(compacted).not.toContain('canvas_layout_restored')
    expect(materializeFromText(compacted)).toMatchObject({
      scroll: { axis: 'both', snap: true },
      widgets: [{ id: 'without-props', position: { x: 1, y: 2 } }, { id: 'width-only', position: { x: 3, y: 4 }, props: { content: 'keep', width: 180 } }],
    })
    expect(materializeFromText(compacted).sources).toBeUndefined()
  })
})
