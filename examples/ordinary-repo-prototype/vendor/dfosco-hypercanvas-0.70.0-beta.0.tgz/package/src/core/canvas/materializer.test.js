import { describe, it, expect } from 'vitest'
import { readFileSync } from 'node:fs'
import path from 'node:path'
import { parseCanvasJsonl, materialize, materializeFromText, serializeEvent, applyEvent, validateCanvasJsonl, captureCanvasLayoutRestoration, reverseCanvasLayoutRestoration } from './materializer.js'

describe('parseCanvasJsonl', () => {
  it('parses multiple JSONL lines', () => {
    const text = '{"event":"canvas_created","title":"Test"}\n{"event":"widget_added","widget":{"id":"w1"}}\n'
    const events = parseCanvasJsonl(text)
    expect(events).toHaveLength(2)
    expect(events[0].event).toBe('canvas_created')
    expect(events[1].event).toBe('widget_added')
  })

  it('skips blank lines', () => {
    const text = '{"event":"canvas_created"}\n\n\n{"event":"widget_added","widget":{"id":"w1"}}\n'
    const events = parseCanvasJsonl(text)
    expect(events).toHaveLength(2)
  })

  it('skips malformed lines', () => {
    const text = '{"event":"canvas_created"}\nnot json\n{"event":"widget_added","widget":{"id":"w1"}}\n'
    const events = parseCanvasJsonl(text)
    expect(events).toHaveLength(2)
  })

  it('parses concatenated JSON objects on a single line', () => {
    const text = '{"event":"canvas_created","title":"Test"}{"event":"source_updated","sources":[]}'
    const events = parseCanvasJsonl(text)
    expect(events).toHaveLength(2)
    expect(events[0].event).toBe('canvas_created')
    expect(events[1].event).toBe('source_updated')
  })

  it('handles braces inside JSON strings', () => {
    const text = '{"event":"canvas_created","title":"A {title}"}{"event":"widget_added","widget":{"id":"w1","props":{"text":"x}"}}}'
    const events = parseCanvasJsonl(text)
    expect(events).toHaveLength(2)
    expect(events[0].title).toBe('A {title}')
    expect(events[1].widget.props.text).toBe('x}')
  })

  it('returns empty array for empty input', () => {
    expect(parseCanvasJsonl('')).toEqual([])
    expect(parseCanvasJsonl('\n\n')).toEqual([])
  })
})

describe('materialize', () => {
  it('materializes a canvas_created event', () => {
    const events = [
      { event: 'canvas_created', timestamp: '2026-01-01', title: 'Test', grid: true, gridSize: 24, widgets: [] },
    ]
    const state = materialize(events)
    expect(state.title).toBe('Test')
    expect(state.grid).toBe(true)
    expect(state.gridSize).toBe(24)
    expect(state.widgets).toEqual([])
    // event metadata should be stripped
    expect(state.event).toBeUndefined()
    expect(state.timestamp).toBeUndefined()
  })

  it('applies widget_added events', () => {
    const events = [
      { event: 'canvas_created', timestamp: '2026-01-01', title: 'Test', widgets: [] },
      { event: 'widget_added', timestamp: '2026-01-02', widget: { id: 'w1', type: 'sticky-note', position: { x: 0, y: 0 }, props: { text: 'Hello', color: 'yellow' } } },
      { event: 'widget_added', timestamp: '2026-01-03', widget: { id: 'w2', type: 'markdown', position: { x: 100, y: 100 }, props: { content: '# Test' } } },
    ]
    const state = materialize(events)
    expect(state.widgets).toHaveLength(2)
    expect(state.widgets[0].id).toBe('w1')
    expect(state.widgets[1].id).toBe('w2')
  })

  it('applies widget_updated events', () => {
    const events = [
      { event: 'canvas_created', timestamp: '2026-01-01', title: 'Test', widgets: [
        { id: 'w1', type: 'sticky-note', position: { x: 0, y: 0 }, props: { text: 'Original', color: 'yellow' } },
      ] },
      { event: 'widget_updated', timestamp: '2026-01-02', widgetId: 'w1', props: { text: 'Updated' } },
    ]
    const state = materialize(events)
    expect(state.widgets[0].props.text).toBe('Updated')
    expect(state.widgets[0].props.color).toBe('yellow') // unchanged props preserved
  })

  it('applies widget_moved events', () => {
    const events = [
      { event: 'canvas_created', timestamp: '2026-01-01', title: 'Test', widgets: [
        { id: 'w1', type: 'sticky-note', position: { x: 0, y: 0 }, props: {} },
      ] },
      { event: 'widget_moved', timestamp: '2026-01-02', widgetId: 'w1', position: { x: 300, y: 400 } },
    ]
    const state = materialize(events)
    expect(state.widgets[0].position).toEqual({ x: 300, y: 400 })
  })

  it('applies widget_removed events', () => {
    const events = [
      { event: 'canvas_created', timestamp: '2026-01-01', title: 'Test', widgets: [
        { id: 'w1', type: 'sticky-note', position: { x: 0, y: 0 }, props: {} },
        { id: 'w2', type: 'markdown', position: { x: 100, y: 100 }, props: {} },
      ] },
      { event: 'widget_removed', timestamp: '2026-01-02', widgetId: 'w1' },
    ]
    const state = materialize(events)
    expect(state.widgets).toHaveLength(1)
    expect(state.widgets[0].id).toBe('w2')
  })

  it('applies settings_updated events', () => {
    const events = [
      { event: 'canvas_created', timestamp: '2026-01-01', title: 'Test', grid: true, gridSize: 24, widgets: [] },
      { event: 'settings_updated', timestamp: '2026-01-02', settings: { gridSize: 12, title: 'Updated Title' } },
    ]
    const state = materialize(events)
    expect(state.gridSize).toBe(12)
    expect(state.title).toBe('Updated Title')
    expect(state.grid).toBe(true) // unchanged setting preserved
  })

  it('applies source_updated events', () => {
    const events = [
      { event: 'canvas_created', timestamp: '2026-01-01', title: 'Test', sources: [{ export: 'A' }], widgets: [] },
      { event: 'source_updated', timestamp: '2026-01-02', sources: [{ export: 'B' }, { export: 'C' }] },
    ]
    const state = materialize(events)
    expect(state.sources).toEqual([{ export: 'B' }, { export: 'C' }])
  })

  it('applies widgets_replaced events (bulk update)', () => {
    const events = [
      { event: 'canvas_created', timestamp: '2026-01-01', title: 'Test', widgets: [
        { id: 'w1', type: 'sticky-note', position: { x: 0, y: 0 }, props: {} },
      ] },
      { event: 'widgets_replaced', timestamp: '2026-01-02', widgets: [
        { id: 'w1', type: 'sticky-note', position: { x: 50, y: 50 }, props: {} },
        { id: 'w3', type: 'markdown', position: { x: 200, y: 200 }, props: {} },
      ] },
    ]
    const state = materialize(events)
    expect(state.widgets).toHaveLength(2)
    expect(state.widgets[0].position).toEqual({ x: 50, y: 50 })
    expect(state.widgets[1].id).toBe('w3')
  })

  it('returns empty object for empty event stream', () => {
    expect(materialize([])).toEqual({})
  })

  it('silently ignores unknown event types', () => {
    const events = [
      { event: 'canvas_created', timestamp: '2026-01-01', title: 'Test', widgets: [] },
      { event: 'future_event', timestamp: '2026-01-02', data: 'whatever' },
    ]
    const state = materialize(events)
    expect(state.title).toBe('Test')
  })

  it('handles a full lifecycle: create, add, update, move, remove', () => {
    const events = [
      { event: 'canvas_created', timestamp: '1', title: 'Canvas', grid: true, gridSize: 24, colorMode: 'auto', widgets: [] },
      { event: 'widget_added', timestamp: '2', widget: { id: 'w1', type: 'sticky-note', position: { x: 0, y: 0 }, props: { text: 'Hello', color: 'yellow' } } },
      { event: 'widget_added', timestamp: '3', widget: { id: 'w2', type: 'markdown', position: { x: 100, y: 0 }, props: { content: '# Title' } } },
      { event: 'widget_updated', timestamp: '4', widgetId: 'w1', props: { text: 'Updated hello' } },
      { event: 'widget_moved', timestamp: '5', widgetId: 'w2', position: { x: 200, y: 300 } },
      { event: 'widget_added', timestamp: '6', widget: { id: 'w3', type: 'sticky-note', position: { x: 400, y: 0 }, props: { text: 'Temp', color: 'red' } } },
      { event: 'widget_removed', timestamp: '7', widgetId: 'w3' },
      { event: 'settings_updated', timestamp: '8', settings: { gridSize: 12 } },
    ]
    const state = materialize(events)
    expect(state.title).toBe('Canvas')
    expect(state.gridSize).toBe(12)
    expect(state.widgets).toHaveLength(2)
    expect(state.widgets[0]).toEqual({ id: 'w1', type: 'sticky-note', position: { x: 0, y: 0 }, props: { text: 'Updated hello', color: 'yellow' } })
    expect(state.widgets[1]).toEqual({ id: 'w2', type: 'markdown', position: { x: 200, y: 300 }, props: { content: '# Title' } })
  })
})

describe('connectors', () => {
  const baseEvents = [
    { event: 'canvas_created', timestamp: '1', title: 'Test', widgets: [
      { id: 'w1', type: 'sticky-note', position: { x: 0, y: 0 }, props: {} },
      { id: 'w2', type: 'markdown', position: { x: 200, y: 0 }, props: {} },
      { id: 'w3', type: 'sticky-note', position: { x: 400, y: 0 }, props: {} },
    ] },
  ]

  const connector = {
    id: 'connector-001',
    type: 'connector',
    connectorType: 'default',
    start: { widgetId: 'w1', anchor: 'right' },
    end: { widgetId: 'w2', anchor: 'left' },
    meta: {},
  }

  it('materializes connector_added events into connectors array', () => {
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
    ])
    expect(state.connectors).toHaveLength(1)
    expect(state.connectors[0].id).toBe('connector-001')
  })

  it('derives connectorIds on widgets from connectors', () => {
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
    ])
    expect(state.widgets.find((w) => w.id === 'w1').connectorIds).toEqual(['connector-001'])
    expect(state.widgets.find((w) => w.id === 'w2').connectorIds).toEqual(['connector-001'])
    expect(state.widgets.find((w) => w.id === 'w3').connectorIds).toBeUndefined()
  })

  it('removes connectors with connector_removed', () => {
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
      { event: 'connector_removed', timestamp: '3', connectorId: 'connector-001' },
    ])
    expect(state.connectors).toHaveLength(0)
    // connectorIds should not appear on widgets when no connectors reference them
    expect(state.widgets.find((w) => w.id === 'w1').connectorIds).toBeUndefined()
  })

  it('cascades connector removal when widget is removed', () => {
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
      { event: 'widget_removed', timestamp: '3', widgetId: 'w1' },
    ])
    expect(state.connectors).toHaveLength(0)
    expect(state.widgets).toHaveLength(2)
  })

  it('cleans orphaned connectors on widgets_replaced', () => {
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
      { event: 'widgets_replaced', timestamp: '3', widgets: [
        { id: 'w2', type: 'markdown', position: { x: 200, y: 0 }, props: {} },
        { id: 'w3', type: 'sticky-note', position: { x: 400, y: 0 }, props: {} },
      ] },
    ])
    // w1 removed by replacement, so connector referencing w1 is orphaned
    expect(state.connectors).toHaveLength(0)
  })

  it('supports multiple connectors on the same widget', () => {
    const conn2 = {
      id: 'connector-002',
      type: 'connector',
      connectorType: 'default',
      start: { widgetId: 'w2', anchor: 'right' },
      end: { widgetId: 'w3', anchor: 'left' },
      meta: {},
    }
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
      { event: 'connector_added', timestamp: '3', connector: conn2 },
    ])
    expect(state.connectors).toHaveLength(2)
    expect(state.widgets.find((w) => w.id === 'w2').connectorIds).toEqual(
      expect.arrayContaining(['connector-001', 'connector-002']),
    )
    expect(state.widgets.find((w) => w.id === 'w2').connectorIds).toHaveLength(2)
  })

  it('initializes connectors array when none existed', () => {
    const state = materialize([
      { event: 'canvas_created', timestamp: '1', title: 'Empty', widgets: [
        { id: 'w1', type: 'sticky-note', position: { x: 0, y: 0 }, props: {} },
        { id: 'w2', type: 'sticky-note', position: { x: 100, y: 0 }, props: {} },
      ] },
      { event: 'connector_added', timestamp: '2', connector },
    ])
    expect(state.connectors).toHaveLength(1)
  })

  it('updates connector anchors in-place via connector_updated', () => {
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
      { event: 'connector_updated', timestamp: '3', connectorId: 'connector-001', updates: {
        startAnchor: 'bottom',
        endAnchor: 'top',
      } },
    ])
    expect(state.connectors).toHaveLength(1)
    expect(state.connectors[0].start.widgetId).toBe('w1')
    expect(state.connectors[0].start.anchor).toBe('bottom')
    expect(state.connectors[0].end.widgetId).toBe('w2')
    expect(state.connectors[0].end.anchor).toBe('top')
  })

  it('updates only startAnchor when endAnchor is omitted', () => {
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
      { event: 'connector_updated', timestamp: '3', connectorId: 'connector-001', updates: {
        startAnchor: 'top',
      } },
    ])
    expect(state.connectors[0].start.anchor).toBe('top')
    expect(state.connectors[0].end.anchor).toBe('left')
  })

  it('does not leak startAnchor/endAnchor as top-level connector properties', () => {
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
      { event: 'connector_updated', timestamp: '3', connectorId: 'connector-001', updates: {
        startAnchor: 'bottom',
        endAnchor: 'top',
      } },
    ])
    expect(state.connectors[0]).not.toHaveProperty('startAnchor')
    expect(state.connectors[0]).not.toHaveProperty('endAnchor')
  })

  it('preserves meta when updating anchors', () => {
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
      { event: 'connector_updated', timestamp: '3', connectorId: 'connector-001', updates: {
        meta: { color: 'blue' },
      } },
      { event: 'connector_updated', timestamp: '4', connectorId: 'connector-001', updates: {
        startAnchor: 'bottom',
      } },
    ])
    expect(state.connectors[0].start.anchor).toBe('bottom')
    expect(state.connectors[0].meta.color).toBe('blue')
  })

  describe('presentational fields (className/style/data/endpoint overrides)', () => {
    it('preserves className/style/data/endpoint overrides set at creation time', () => {
      const styledConnector = {
        ...connector,
        className: 'demo-arrow important',
        style: { '--connector-stroke': '#ff00ff', '--connector-stroke-width': '3px' },
        data: { variant: 'dashed', color: 'fuchsia' },
        startEndpoint: 'none',
        endEndpoint: 'arrow-end',
      }
      const state = materialize([
        ...baseEvents,
        { event: 'connector_added', timestamp: '2', connector: styledConnector },
      ])
      expect(state.connectors[0].className).toBe('demo-arrow important')
      expect(state.connectors[0].style['--connector-stroke']).toBe('#ff00ff')
      expect(state.connectors[0].data.variant).toBe('dashed')
      expect(state.connectors[0].startEndpoint).toBe('none')
      expect(state.connectors[0].endEndpoint).toBe('arrow-end')
    })

    it('shallow-merges style and data across multiple connector_updated events', () => {
      const state = materialize([
        ...baseEvents,
        { event: 'connector_added', timestamp: '2', connector },
        { event: 'connector_updated', timestamp: '3', connectorId: 'connector-001', updates: {
          style: { '--connector-stroke': '#ff00ff' },
          data: { variant: 'dashed' },
        } },
        { event: 'connector_updated', timestamp: '4', connectorId: 'connector-001', updates: {
          style: { '--connector-stroke-width': '2px' },
          data: { color: 'fuchsia' },
        } },
      ])
      expect(state.connectors[0].style).toEqual({
        '--connector-stroke': '#ff00ff',
        '--connector-stroke-width': '2px',
      })
      expect(state.connectors[0].data).toEqual({ variant: 'dashed', color: 'fuchsia' })
    })

    it('replaces className wholesale when string-valued and clears on null', () => {
      const state = materialize([
        ...baseEvents,
        { event: 'connector_added', timestamp: '2', connector: { ...connector, className: 'old' } },
        { event: 'connector_updated', timestamp: '3', connectorId: 'connector-001', updates: { className: 'new bold' } },
      ])
      expect(state.connectors[0].className).toBe('new bold')

      const cleared = materialize([
        ...baseEvents,
        { event: 'connector_added', timestamp: '2', connector: { ...connector, className: 'old' } },
        { event: 'connector_updated', timestamp: '3', connectorId: 'connector-001', updates: { className: null } },
      ])
      expect(cleared.connectors[0]).not.toHaveProperty('className')
    })

    it('clears style/data entirely when explicit null is passed', () => {
      const state = materialize([
        ...baseEvents,
        { event: 'connector_added', timestamp: '2', connector: {
          ...connector,
          style: { '--connector-stroke': '#f00' },
          data: { variant: 'dashed' },
        } },
        { event: 'connector_updated', timestamp: '3', connectorId: 'connector-001', updates: { style: null, data: null } },
      ])
      expect(state.connectors[0]).not.toHaveProperty('style')
      expect(state.connectors[0]).not.toHaveProperty('data')
    })

    it('updates endpoint shape overrides via connector_updated', () => {
      const state = materialize([
        ...baseEvents,
        { event: 'connector_added', timestamp: '2', connector },
        { event: 'connector_updated', timestamp: '3', connectorId: 'connector-001', updates: {
          startEndpoint: 'arrow-start',
          endEndpoint: 'arrow-end',
        } },
      ])
      expect(state.connectors[0].startEndpoint).toBe('arrow-start')
      expect(state.connectors[0].endEndpoint).toBe('arrow-end')
    })
  })

  it('sets manual waypoints via connector_waypoints_set', () => {
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
      { event: 'connector_waypoints_set', timestamp: '3', connectorId: 'connector-001', waypoints: [
        { dx: 100, dy: 0, tHint: 0.33 },
        { dx: 100, dy: 200, tHint: 0.66 },
      ] },
    ])
    expect(state.connectors[0].waypoints).toHaveLength(2)
    expect(state.connectors[0].waypoints[0]).toEqual({ dx: 100, dy: 0, tHint: 0.33 })
    expect(state.connectors[0].waypoints[1]).toEqual({ dx: 100, dy: 200, tHint: 0.66 })
  })

  it('replaces existing waypoints on subsequent connector_waypoints_set', () => {
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
      { event: 'connector_waypoints_set', timestamp: '3', connectorId: 'connector-001', waypoints: [{ dx: 50, dy: 0 }] },
      { event: 'connector_waypoints_set', timestamp: '4', connectorId: 'connector-001', waypoints: [{ dx: 75, dy: 25 }, { dx: 100, dy: 50 }] },
    ])
    expect(state.connectors[0].waypoints).toHaveLength(2)
    expect(state.connectors[0].waypoints[0].dx).toBe(75)
  })

  it('drops waypoints via connector_waypoints_cleared', () => {
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
      { event: 'connector_waypoints_set', timestamp: '3', connectorId: 'connector-001', waypoints: [{ dx: 100, dy: 0 }] },
      { event: 'connector_waypoints_cleared', timestamp: '4', connectorId: 'connector-001' },
    ])
    expect(state.connectors[0].waypoints).toBeUndefined()
  })

  it('connector_waypoints_set on missing connector is a no-op', () => {
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
      { event: 'connector_waypoints_set', timestamp: '3', connectorId: 'does-not-exist', waypoints: [{ dx: 100, dy: 0 }] },
    ])
    expect(state.connectors[0].waypoints).toBeUndefined()
  })

  it('coerces non-array waypoints payload to empty array', () => {
    const state = materialize([
      ...baseEvents,
      { event: 'connector_added', timestamp: '2', connector },
      { event: 'connector_waypoints_set', timestamp: '3', connectorId: 'connector-001', waypoints: null },
    ])
    expect(state.connectors[0].waypoints).toEqual([])
  })
})

describe('materializeFromText', () => {
  it('parses and materializes in one step', () => {
    const text = '{"event":"canvas_created","timestamp":"2026-01-01","title":"Test","widgets":[]}\n{"event":"widget_added","timestamp":"2026-01-02","widget":{"id":"w1","type":"sticky-note","position":{"x":0,"y":0},"props":{"text":"Hello"}}}\n'
    const state = materializeFromText(text)
    expect(state.title).toBe('Test')
    expect(state.widgets).toHaveLength(1)
    expect(state.widgets[0].props.text).toBe('Hello')
  })

  it('accepts legacy streams without a format version and strips version 1 from state', () => {
    expect(materializeFromText('{"event":"canvas_created","title":"Legacy","widgets":[]}').title).toBe('Legacy')
    const state = materializeFromText('{"event":"canvas_created","formatVersion":1,"title":"Versioned","widgets":[]}')
    expect(state.title).toBe('Versioned')
    expect(state.formatVersion).toBeUndefined()
  })

  it('accepts explicit format v2 and rejects versions it does not support', () => {
    expect(materializeFromText('{"event":"canvas_created","formatVersion":2,"widgets":[]}').scroll.axis).toBe('both')
    expect(() => materializeFromText('{"event":"canvas_created","formatVersion":3,"widgets":[]}'))
      .toThrow('Unsupported canvas formatVersion: 3')
  })

  it('skips malformed known events and keeps unknown events as no-ops', () => {
    const state = materialize([
      { event: 'canvas_created', title: 'Stable', widgets: [] },
      { event: 'widget_added', widget: null },
      { event: 'widget_added', widget: { props: { text: 'missing identity' } } },
      { event: 'widgets_replaced', widgets: [{ props: { text: 'missing identity' } }] },
      { event: 'connector_added', connector: { id: 'missing-endpoints' } },
      { event: 'connectors_replaced', connectors: [{ id: 'missing-endpoints' }] },
      { event: 'future_event', payload: 1 },
    ])
    expect(state.title).toBe('Stable')
    expect(state.widgets).toEqual([])
    expect(state.connectors).toEqual([])
  })
})

describe('canvas v2 compound layout', () => {
  const fixture = (name) => readFileSync(path.resolve(process.cwd(), `packages/storyboard/test/fixtures/canvas-document/${name}`), 'utf8')
  const baseline = {
    event: 'canvas_created',
    formatVersion: 2,
    scroll: { axis: 'both', custom: true },
    widgets: [
      { id: 'w1', type: 'sticky-note', position: { x: 1, y: 2 }, props: { text: 'keep', width: 100, height: 60, custom: 'widget' }, custom: 'record' },
      { id: 'w2', type: 'markdown', position: { x: 3, y: 4 }, props: { content: 'keep', width: 200, height: 80 } },
    ],
    sources: [{ export: 'PrimaryButtons', position: { x: 5, y: 6 }, width: 300, height: 120, custom: 'source' }],
    connectors: [{ id: 'c1', start: { widgetId: 'w1' }, end: { widgetId: 'w2' }, meta: { keep: true } }],
  }
  const layout = {
    event: 'canvas_layout_updated',
    scroll: { axis: 'vertical' },
    widgets: [
      { id: 'w1', position: { x: 24, y: 24 }, width: 120, height: 70 },
      { id: 'w2', position: { x: 24, y: 110 }, width: 220, height: 90 },
    ],
    sources: [{ export: 'PrimaryButtons', position: { x: 24, y: 220 }, width: 320, height: 140 }],
  }

  it('replays layout into scroll.axis and existing renderer geometry while preserving other fields', () => {
    const state = materialize([baseline, layout])
    expect(state.scroll).toEqual({ axis: 'vertical', custom: true })
    expect(state.widgets[0]).toMatchObject({ id: 'w1', position: { x: 24, y: 24 }, props: { text: 'keep', width: 120, height: 70, custom: 'widget' }, custom: 'record' })
    expect(state.widgets.map((widget) => widget.id)).toEqual(['w1', 'w2'])
    expect(state.sources[0]).toEqual({ export: 'PrimaryButtons', position: { x: 24, y: 220 }, width: 320, height: 140, custom: 'source' })
    expect(state.connectors[0].meta.keep).toBe(true)
  })

  it('defaults missing legacy scroll.axis to both', () => {
    expect(materialize([{ event: 'canvas_created', title: 'legacy', widgets: [] }]).scroll.axis).toBe('both')
  })

  it('rejects v2 layout semantics in a v1 stream and fails closed on required unknown events', () => {
    expect(() => materialize([{ ...baseline, formatVersion: 1 }, layout])).toThrow('requires canvas formatVersion 2')
    expect(() => materialize([baseline, { event: 'future_layout', required: true }])).toThrow('Unsupported required canvas event: future_layout')
  })

  it('keeps optional unknown events ignorable', () => {
    expect(materialize([baseline, { event: 'future_decoration', data: 1 }]).widgets).toHaveLength(2)
  })

  it('rejects malformed layouts without mutating a partial state', () => {
    expect(() => materialize([baseline, { ...layout, widgets: [layout.widgets[0], layout.widgets[0]] }]))
      .toThrow('Duplicate widget in canvas layout: w1')
    expect(() => materialize([baseline, { ...layout, sources: [] }]))
      .toThrow('must include every persisted JSX source')
  })

  it('reports strict JSONL diagnostics with line numbers', () => {
    expect(validateCanvasJsonl(`${JSON.stringify(baseline)}\nnot json\n`)).toMatchObject([
      { code: 'malformed_json', line: 2 },
    ])
    expect(validateCanvasJsonl(`${JSON.stringify(baseline)}\n${JSON.stringify({ event: 'future_layout', required: true })}`))
      .toMatchObject([{ code: 'incompatible_required_event', line: 2, event: 'future_layout' }])
    expect(validateCanvasJsonl(`${JSON.stringify({ ...baseline, formatVersion: 1 })}\n${JSON.stringify(layout)}`))
      .toMatchObject([{ code: 'incompatible_format', line: 2, event: 'canvas_layout_updated' }])
    expect(validateCanvasJsonl(`${JSON.stringify(baseline)}\n${JSON.stringify(baseline)}`))
      .toMatchObject([{ code: 'invalid_event', line: 2, event: 'canvas_created' }])
  })

  it('reports malformed known non-layout events strictly while tolerant playback skips them', () => {
    const malformedAdded = { event: 'widget_added', widget: { type: 'sticky-note' } }
    const malformedUpdated = { event: 'widget_updated', widgetId: '', props: {} }
    const text = [baseline, malformedAdded, malformedUpdated].map((event) => JSON.stringify(event)).join('\n')

    expect(validateCanvasJsonl(text)).toMatchObject([
      { code: 'invalid_event', line: 2, event: 'widget_added' },
      { code: 'invalid_event', line: 3, event: 'widget_updated' },
    ])
    expect(materializeFromText(text)).toEqual(materialize([baseline]))
  })

  it('requires complete moved positions for authoring while preserving tolerant partial-position playback', () => {
    const header = { event: 'canvas_created', widgets: [{ id: 'w1', position: { x: 0, y: 0 } }] }
    const partialMove = { event: 'widget_moved', widgetId: 'w1', position: { x: 24 } }
    const text = `${JSON.stringify(header)}\n${JSON.stringify(partialMove)}`

    expect(validateCanvasJsonl(text)).toMatchObject([
      { code: 'invalid_event', line: 2, event: 'widget_moved' },
    ])
    expect(materialize([header, partialMove]).widgets[0].position).toEqual({ x: 24 })
  })

  it('replays the shared fixtures and rejects incompatible or invalid fixture streams', () => {
    expect(materializeFromText(fixture('v1-legacy.jsonl')).scroll.axis).toBe('both')
    const replayed = materializeFromText(fixture('v2-layout.jsonl'))
    const compacted = materializeFromText(fixture('v2-compacted.jsonl'))
    expect(replayed.scroll.axis).toBe('vertical')
    expect(replayed.widgets[0]).toMatchObject({ id: 'note-1', position: { x: 24, y: 24 } })
    expect(compacted.scroll.axis).toBe('vertical')
    expect(compacted.widgets[0]).toMatchObject({ id: 'note-1', position: { x: 24, y: 24 } })
    expect(materializeFromText(fixture('unknown-optional.jsonl')).widgets).toEqual([])
    expect(() => materializeFromText(fixture('invalid-layout.jsonl'))).toThrow('Duplicate widget in canvas layout')
    expect(() => materializeFromText(fixture('unknown-required.jsonl'))).toThrow('Unsupported required canvas event')
    expect(validateCanvasJsonl(fixture('unknown-optional.jsonl'))).toEqual([])
    expect(validateCanvasJsonl(fixture('unknown-required.jsonl'))).toMatchObject([
      { code: 'incompatible_required_event', line: 2, event: 'future_layout_v3' },
    ])
    expect(validateCanvasJsonl(fixture('invalid-layout.jsonl'))).toMatchObject([
      { code: 'invalid_event', line: 2, event: 'canvas_layout_updated' },
    ])
    expect(validateCanvasJsonl(fixture('invalid-moved-position.jsonl'))).toMatchObject([
      { code: 'invalid_event', line: 2, event: 'widget_moved' },
    ])
    expect(materializeFromText(fixture('invalid-moved-position.jsonl')).widgets[0].position).toEqual({ x: 24 })
  })

  it('captures and replays undo and redo for missing geometry keys and layout-added sources', () => {
    const before = {
      scroll: { axis: 'both', snap: true },
      widgets: [
        { id: 'without-props', position: { x: 1, y: 2 } },
        { id: 'width-only', position: { x: 3, y: 4 }, props: { content: 'keep', width: 180 } },
      ],
    }
    const forward = {
      ...layout,
      widgets: [
        { id: 'without-props', position: { x: 20, y: 20 }, width: 100, height: 60 },
        { id: 'width-only', position: { x: 20, y: 90 }, width: 180, height: 70 },
      ],
      sources: [{ export: 'AddedComp', position: { x: 20, y: 180 }, width: 300, height: 120 }],
    }
    const undo = captureCanvasLayoutRestoration(before, forward)
    const forwardState = applyEvent(before, forward)
    expect(undo).toMatchObject({ event: 'canvas_layout_restored', required: true, action: 'undo' })
    expect(undo.snapshot.widgets[0].restore).toMatchObject({ width: { present: false }, height: { present: false }, propsContainer: 'absent' })
    expect(undo.snapshot.widgets[1].restore).toMatchObject({ width: { present: true, value: 180 }, height: { present: false }, propsContainer: 'object' })
    expect(undo.snapshot.sources[0].restore).toEqual({ present: false })

    const undone = applyEvent(forwardState, undo)
    expect(undone.scroll).toEqual({ axis: 'both', snap: true })
    expect(undone.widgets[0]).toEqual({ id: 'without-props', position: { x: 1, y: 2 } })
    expect(undone.widgets[1]).toEqual({ id: 'width-only', position: { x: 3, y: 4 }, props: { content: 'keep', width: 180 } })
    expect(undone.sources).toBeUndefined()

    const redo = reverseCanvasLayoutRestoration(undo)
    const redone = applyEvent(undone, redo)
    expect(redone.scroll.axis).toBe('vertical')
    expect(redone.widgets[0].props).toEqual({ width: 100, height: 60 })
    expect(redone.sources).toEqual([{ export: 'AddedComp', position: { x: 20, y: 180 }, width: 300, height: 120 }])
  })

  it('preserves absent and null props containers across two complete undo/redo cycles', () => {
    for (const props of [undefined, null]) {
      const widget = { id: 'w1', position: { x: 1, y: 2 }, ...(props === undefined ? {} : { props }) }
      const before = { scroll: { axis: 'both' }, widgets: [widget], sources: [] }
      const forward = { ...layout, widgets: [{ id: 'w1', position: { x: 10, y: 20 }, width: 100, height: 60 }], sources: [] }
      const undo = captureCanvasLayoutRestoration(before, forward)
      const afterForward = applyEvent(before, forward)
      const afterUndo1 = applyEvent(afterForward, undo)
      const redo = reverseCanvasLayoutRestoration(undo)
      const afterRedo = applyEvent(afterUndo1, redo)
      const undo2 = reverseCanvasLayoutRestoration(redo)
      const afterUndo2 = applyEvent(afterRedo, undo2)

      expect(Object.prototype.hasOwnProperty.call(afterUndo2.widgets[0], 'props')).toBe(props !== undefined)
      expect(afterUndo2.widgets[0].props).toEqual(props)
    }
  })

  it('treats expected propsContainer as restoration metadata while guarding geometry keys', () => {
    const before = { scroll: { axis: 'both' }, widgets: [{ id: 'w1' }], sources: [] }
    const forward = { ...layout, widgets: [{ id: 'w1', position: { x: 10, y: 20 }, width: 100, height: 60 }], sources: [] }
    const undo = captureCanvasLayoutRestoration(before, forward)
    const afterUndo = applyEvent(applyEvent(before, forward), undo)
    const editedAfterUndo = { ...afterUndo, widgets: [{ ...afterUndo.widgets[0], props: { text: 'independent edit' } }] }
    const afterRedo = applyEvent(editedAfterUndo, reverseCanvasLayoutRestoration(undo))
    expect(afterRedo.widgets[0].props).toEqual({ text: 'independent edit', width: 100, height: 60 })
  })

  it('preserves unrelated edits and rejects stale layout-owned source removal atomically', () => {
    const before = {
      scroll: { axis: 'both', snap: true },
      widgets: [{ id: 'w1', position: { x: 1, y: 2 }, props: { text: 'before', custom: 'keep' } }],
      sources: [{ export: 'Existing', position: { x: 4, y: 5 }, width: 80, height: 40, owner: 'authored' }],
    }
    const forward = { ...layout, widgets: [{ id: 'w1', position: { x: 20, y: 20 }, width: 100, height: 60 }], sources: [
      { export: 'Existing', position: { x: 20, y: 100 }, width: 90, height: 45 },
      { export: 'AddedComp', position: { x: 20, y: 180 }, width: 300, height: 120 },
    ] }
    const undo = captureCanvasLayoutRestoration(before, forward)
    const laidOut = applyEvent(before, forward)
    const independentlyEdited = {
      ...laidOut,
      widgets: [{ ...laidOut.widgets[0], props: { ...laidOut.widgets[0].props, text: 'new content' } }, { id: 'new-widget', props: { text: 'unrelated' } }],
      sources: [...laidOut.sources.map((source) => source.export === 'Existing' ? { ...source, owner: 'edited metadata' } : source), { export: 'Independent', owner: 'other work' }],
    }
    const undone = applyEvent(independentlyEdited, undo)
    expect(undone.widgets[0].props).toEqual({ text: 'new content', custom: 'keep' })
    expect(undone.widgets[1]).toEqual({ id: 'new-widget', props: { text: 'unrelated' } })
    expect(undone.sources).toEqual([
      { export: 'Existing', position: { x: 4, y: 5 }, width: 80, height: 40, owner: 'edited metadata' },
      { export: 'Independent', owner: 'other work' },
    ])

    const stale = { ...laidOut, sources: laidOut.sources.map((source) => source.export === 'AddedComp' ? { ...source, owner: 'independent edit' } : source) }
    expect(() => applyEvent(stale, undo)).toThrow('canvas_layout_restored source conflict: AddedComp')
    expect(stale.scroll.axis).toBe('vertical')
    expect(stale.widgets[0].position).toEqual({ x: 20, y: 20 })
    expect(stale.sources.find((source) => source.export === 'AddedComp').owner).toBe('independent edit')
  })

  it('validates restored events, duplicate snapshot identities, and v2 requirement', () => {
    const before = { scroll: { axis: 'both' }, widgets: [{ id: 'w1', props: {} }], sources: [] }
    const forward = { ...layout, widgets: [{ id: 'w1', position: { x: 1, y: 2 }, width: 100, height: 60 }], sources: [] }
    const undo = captureCanvasLayoutRestoration(before, forward)
    expect(() => materialize([{ ...baseline, formatVersion: 1 }, undo])).toThrow('canvas_layout_restored requires canvas formatVersion 2')
    expect(() => applyEvent(applyEvent(before, forward), { ...undo, snapshot: { ...undo.snapshot, widgets: [undo.snapshot.widgets[0], undo.snapshot.widgets[0]] } }))
      .toThrow('Duplicate widget in canvas_layout_restored snapshot')
    expect(validateCanvasJsonl(`${JSON.stringify(baseline)}\n${JSON.stringify({ ...undo, snapshot: { ...undo.snapshot, widgets: [] } })}`))
      .toMatchObject([{ code: 'invalid_event', line: 2, event: 'canvas_layout_restored' }])
  })

  it('requires a value key for present snapshots and round-trips absent/null source containers through redo', () => {
    const malformed = {
      event: 'canvas_layout_restored', required: true, action: 'undo',
      snapshot: {
        axis: { expected: 'vertical', restore: 'both' },
        widgets: [{ id: 'w1', expected: { position: { present: true }, width: { present: false }, height: { present: false }, propsContainer: 'object' }, restore: { position: { present: false }, width: { present: false }, height: { present: false }, propsContainer: 'absent' } }],
        sources: [], sourcesContainer: { expected: 'array', restore: 'absent' },
      },
    }
    expect(() => applyEvent({ widgets: [{ id: 'w1', position: { x: 1, y: 1 }, props: {} }], scroll: { axis: 'vertical' }, sources: [] }, malformed))
      .toThrow('Invalid required canvas_layout_restored event')
    expect(() => serializeEvent(malformed)).toThrow('Invalid required canvas_layout_restored event')
    expect(validateCanvasJsonl(fixture('invalid-layout-restored-missing-value.jsonl')))
      .toMatchObject([{ code: 'invalid_event', line: 2, event: 'canvas_layout_restored' }])

    const mismatchedSource = {
      event: 'canvas_layout_restored', required: true, action: 'redo',
      snapshot: {
        axis: { expected: 'both', restore: 'vertical' }, widgets: [],
        sources: [{ export: 'OwnedExport', expected: { present: false }, restore: { present: true, index: 0, record: { export: 'DifferentExport' } } }],
        sourcesContainer: { expected: 'array', restore: 'array' },
      },
    }
    expect(() => applyEvent({ scroll: { axis: 'both' }, widgets: [], sources: [] }, mismatchedSource))
      .toThrow('Mismatched source export in canvas_layout_restored snapshot')

    for (const sources of [undefined, null]) {
      const { sources: _baseSources, ...baselineWithoutSources } = baseline
      const baselineWithContainer = { ...baselineWithoutSources, widgets: [{ id: 'w1', position: { x: 1, y: 2 }, props: {} }], ...(sources === undefined ? {} : { sources }) }
      const forward = { ...layout, widgets: [{ id: 'w1', position: { x: 10, y: 20 }, width: 100, height: 60 }], sources: [] }
      const before = materialize([baselineWithContainer])
      const undo = captureCanvasLayoutRestoration(before, forward)
      const forwardState = applyEvent(before, forward)
      const undone = applyEvent(forwardState, undo)
      expect(Object.prototype.hasOwnProperty.call(undone, 'sources')).toBe(sources !== undefined)
      if (sources === null) expect(undone.sources).toBeNull()
      else expect(undone.sources).toBeUndefined()
      const redone = applyEvent(undone, reverseCanvasLayoutRestoration(undo))
      expect(redone.sources).toEqual([])
      expect(redone.widgets[0].props).toEqual({ width: 100, height: 60 })
    }
  })

  it('replays the shared layout restoration fixture and compacts to the restored state', () => {
    const restored = materializeFromText(fixture('v2-layout-restored.jsonl'))
    expect(restored.scroll.axis).toBe('both')
    expect(restored.widgets[0]).toEqual({ id: 'without-props', position: { x: 1, y: 2 } })
    expect(restored.widgets[1].props).toEqual({ content: 'keep', width: 180 })
    expect(restored.sources).toBeUndefined()
  })

  it('materializes the real reference canvas subset through the public state shape', () => {
    const state = materializeFromText(fixture('button-patterns-reference.jsonl'))
    expect(state.widgets.map((widget) => widget.type)).toEqual(['sticky-note', 'markdown', 'sticky-note', 'prototype', 'sticky-note'])
    expect(state.sources.map((source) => source.export)).toEqual(['PrimaryButtons', 'DangerButtons'])
    expect(state.scroll.axis).toBe('both')
  })
})

describe('serializeEvent', () => {
  it('serializes an event to a single line', () => {
    const event = { event: 'widget_added', timestamp: '2026-01-01', widget: { id: 'w1' } }
    const line = serializeEvent(event)
    expect(line).not.toContain('\n')
    expect(JSON.parse(line)).toEqual(event)
  })

  it('rejects unsupported version markers and malformed known events', () => {
    expect(() => serializeEvent({ event: 'canvas_created', formatVersion: 8 })).toThrow(/Unsupported canvas formatVersion/)
    expect(() => serializeEvent({ event: 'widget_added', widget: null })).toThrow(/malformed canvas event/)
    expect(() => serializeEvent({ event: 'future_layout', required: true })).toThrow(/unsupported required canvas event/)
  })
})

describe('applyEvent (single-event applier for client-side optimistic undo/redo)', () => {
  it('widget_added: appends to widgets, leaves other arrays alone', () => {
    const before = { widgets: [{ id: 'a' }], connectors: [], sources: [{ export: 's' }] }
    const after = applyEvent(before, { event: 'widget_added', widget: { id: 'b' } })
    expect(after.widgets).toEqual([{ id: 'a' }, { id: 'b' }])
    expect(after.connectors).toBe(before.connectors)
    expect(after.sources).toBe(before.sources)
  })

  it('widget_moved: replaces position on the matching widget only', () => {
    const before = { widgets: [{ id: 'a', position: { x: 0, y: 0 } }, { id: 'b', position: { x: 10, y: 10 } }], connectors: [] }
    const after = applyEvent(before, { event: 'widget_moved', widgetId: 'a', position: { x: 5, y: 5 } })
    expect(after.widgets[0]).toEqual({ id: 'a', position: { x: 5, y: 5 } })
    expect(after.widgets[1]).toBe(before.widgets[1])
  })

  it('widget_updated: merges props on the matching widget only', () => {
    const before = { widgets: [{ id: 'a', props: { color: 'pink', text: 'hi' } }], connectors: [] }
    const after = applyEvent(before, { event: 'widget_updated', widgetId: 'a', props: { color: 'green' } })
    expect(after.widgets[0].props).toEqual({ color: 'green', text: 'hi' })
  })

  it('widget_removed: drops the widget and cascades to dependent connectors', () => {
    const before = {
      widgets: [{ id: 'a' }, { id: 'b' }],
      connectors: [
        { id: 'c1', start: { widgetId: 'a' }, end: { widgetId: 'b' } },
        { id: 'c2', start: { widgetId: 'b' }, end: { widgetId: 'b' } },
      ],
    }
    const after = applyEvent(before, { event: 'widget_removed', widgetId: 'a' })
    expect(after.widgets).toEqual([{ id: 'b' }])
    expect(after.connectors).toEqual([{ id: 'c2', start: { widgetId: 'b' }, end: { widgetId: 'b' } }])
  })

  it('connector_added / connector_removed: round-trip is identity', () => {
    const start = { widgets: [], connectors: [{ id: 'c1', start: { widgetId: 'a' }, end: { widgetId: 'b' } }] }
    const added = applyEvent(start, { event: 'connector_added', connector: { id: 'c2', start: { widgetId: 'b' }, end: { widgetId: 'a' } } })
    expect(added.connectors).toHaveLength(2)
    const removed = applyEvent(added, { event: 'connector_removed', connectorId: 'c2' })
    expect(removed.connectors).toEqual(start.connectors)
  })

  it('source_updated: replaces sources, returns new state ref', () => {
    const before = { widgets: [], connectors: [], sources: [{ export: 'A' }] }
    const after = applyEvent(before, { event: 'source_updated', sources: [{ export: 'B' }] })
    expect(after.sources).toEqual([{ export: 'B' }])
    expect(after).not.toBe(before)
  })

  it('unknown events return the same state reference (cheap no-op detection)', () => {
    const before = { widgets: [{ id: 'a' }], connectors: [] }
    const after = applyEvent(before, { event: 'mystery_event', payload: 42 })
    expect(after).toBe(before)
  })

  it('matches materialize() when folding a sequence event-by-event', () => {
    const events = [
      { event: 'canvas_created', widgets: [{ id: 'a', position: { x: 0, y: 0 } }], connectors: [] },
      { event: 'widget_moved', widgetId: 'a', position: { x: 10, y: 10 } },
      { event: 'widget_added', widget: { id: 'b' } },
      { event: 'widget_removed', widgetId: 'a' },
    ]
    let stepwise = {}
    for (const evt of events) stepwise = applyEvent(stepwise, evt)
    const full = materialize(events)
    expect(stepwise.widgets).toEqual(full.widgets)
    expect(stepwise.connectors).toEqual(full.connectors)
  })

  it('applies an undo inverse event (widget_moved with prevPosition swapped) correctly', () => {
    // Simulate what POST /undo returns: a forward widget_moved that swaps
    // position ↔ prevPosition, tagged with meta.kind = 'undo'.
    const before = { widgets: [{ id: 'a', position: { x: 100, y: 100 } }], connectors: [] }
    const inverseEvent = {
      event: 'widget_moved',
      widgetId: 'a',
      position: { x: 0, y: 0 },
      prevPosition: { x: 100, y: 100 },
      meta: { kind: 'undo', of: 'evt_xxx' },
    }
    const after = applyEvent(before, inverseEvent)
    expect(after.widgets[0].position).toEqual({ x: 0, y: 0 })
  })
})
