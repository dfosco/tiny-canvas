// @vitest-environment node
import assert from 'node:assert/strict'
import { afterEach, it } from 'vitest'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { setImmediate as nextTurn } from 'node:timers/promises'
import { createCanvasHandler } from './server.js'
import { materializeFromText, serializeEvent } from './materializer.js'
import * as registry from './terminal-registry.js'
import * as config from './terminal-config.js'
import { withTerminalStartup, terminalWidgetStartupKey } from './terminal-runtime.js'
import { initPaseoTerminalRuntime, resetPaseoTerminalRuntimeForTests } from './paseo-terminal-runtime.js'
import { initPaseoAgentRuntime, _resetPaseoAgentRuntime } from './paseo-agent-runtime.js'

// Exercise the real handler, lifecycle, registry, config and JSONL storage.
// Only the remote Paseo transport is simulated; no lifecycle modules are mocked.
const cleanups = []
afterEach(async () => {
  for (const cleanup of cleanups.splice(0).reverse()) await cleanup()
})

async function fixture(widgets = []) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'hypercanvas-widget-delete-'))
  execFileSync('git', ['init', '--quiet', root])
  execFileSync('git', ['-C', root, '-c', 'user.name=Lifecycle test', '-c', 'user.email=lifecycle@example.invalid', 'commit', '--allow-empty', '--quiet', '-m', 'Fixture'])
  const canvasDir = path.join(root, 'src', 'canvas')
  fs.mkdirSync(canvasDir, { recursive: true })
  const file = path.join(canvasDir, 'lifecycle.canvas.jsonl')
  fs.writeFileSync(file, serializeEvent({ event: 'canvas_created', timestamp: new Date().toISOString(), title: 'Lifecycle', widgets, connectors: [], gridSize: 24 }) + '\n')
  let terminals = []
  let killFails = false
  let archiveFails = false
  let killGate = null
  let notifyKillStarted = null
  let nativeCreationAllowed = false
  let nativeSequence = 0
  let idSequence = 0
  const calls = { kills: [], archives: [], creates: [], nativeCreates: [] }
  const connection = {
    client: { workspaces: {
      ref: () => ({ current: () => ({ id: 'workspace-fixture', workspaceDirectory: root }), refresh: async () => ({ id: 'workspace-fixture' }) }),
      open: async () => ({ id: 'workspace-fixture', workspaceDirectory: root }),
    } },
    daemon: {
      onTerminalStreamEvent: () => () => {},
      subscribeRawMessages: () => () => {},
      subscribeConnectionStatus: listener => { listener({ status: 'connected' }); return () => {} },
      async listTerminals() { return { terminals } },
      async createTerminal(cwd, name, _request, options) {
        const terminal = { id: `terminal-${++idSequence}`, name, cwd, workspaceId: options.workspaceId }
        terminals.push(terminal)
        calls.creates.push(terminal.id)
        return { terminal }
      },
      async killTerminal(terminalId) {
        calls.kills.push(terminalId)
        notifyKillStarted?.()
        if (killGate) await killGate
        if (killFails) return { terminalId, success: false }
        terminals = terminals.filter(item => item.id !== terminalId)
        return { terminalId, success: true }
      },
      async close() {},
    },
    getConnectionState: () => ({ status: 'connected' }),
    async close() {},
  }
  const pty = await initPaseoTerminalRuntime(root, { connection })
  registry.initRegistry(root)
  config.initTerminalConfig(root)
  const nativeHandles = new Map()
  const nativeHandle = agentId => {
    if (nativeHandles.has(agentId)) return nativeHandles.get(agentId)
    const state = { id: agentId, workspaceId: 'workspace-fixture', archivedAt: null }
    const handle = {
      id: agentId,
      workspaceId: 'workspace-fixture',
      current: () => state,
      refresh: async () => ({ agent: state }),
      subscribe: () => () => {},
      timeline: { subscribe: () => () => {} },
      async archive() {
        calls.archives.push(agentId)
        if (archiveFails) throw new Error('Native archive refused')
        state.archivedAt = new Date().toISOString()
        return { success: true }
      },
    }
    nativeHandles.set(agentId, handle)
    return handle
  }
  const native = await initPaseoAgentRuntime({
    root,
    daemonReady: true,
    daemon: { getConnectionState: () => ({ status: 'connected' }), close() {} },
    client: {
      workspaces: { ref: () => ({ agents: { async create() {
        if (!nativeCreationAllowed) throw new Error('Unexpected native agent recreation')
        const agentId = `native-created-${++nativeSequence}`
        calls.nativeCreates.push(agentId)
        return nativeHandle(agentId)
      } } }) },
      agents: { ref: nativeHandle },
    },
    workspaceIdResolver: async () => 'workspace-fixture',
  })
  let response = null
  const handler = createCanvasHandler({
    root,
    workspaceIdResolver: async () => 'workspace-fixture',
    sendJson(_res, status, body) { response = { status, body } },
  })
  const invoke = async (route, method, body) => {
    response = null
    await handler(null, { writeHead() {}, end() {} }, { path: route, method, body: { name: 'lifecycle', ...body } })
    return response
  }
  const addSession = async widget => {
    if (widget.type === 'agent-chat') {
      config.writeTerminalConfig({ branch: 'test', canvasId: 'lifecycle', widgetId: widget.id, workspaceId: 'workspace-fixture', widgetProps: widget.props })
      return null
    }
    const { entry } = registry.registerSession({ branch: 'test', canvasId: 'lifecycle', widgetId: widget.id })
    config.writeTerminalConfig({ branch: 'test', canvasId: 'lifecycle', widgetId: widget.id, workspaceId: 'workspace-fixture', sessionId: entry.sessionId })
    const created = await pty.create({ sessionId: entry.sessionId, workspaceId: 'workspace-fixture', cwd: root })
    return { entry, terminalId: created.terminalId }
  }
  cleanups.push(async () => {
    registry.resetRegistryForTests()
    _resetPaseoAgentRuntime()
    await resetPaseoTerminalRuntimeForTests()
    fs.rmSync(root, { recursive: true, force: true })
  })
  return {
    root, file, invoke, addSession, pty, native, calls,
    read: () => materializeFromText(fs.readFileSync(file, 'utf8')),
    terminals: () => terminals,
    failKills: value => { killFails = value },
    failArchives: value => { archiveFails = value },
    allowNativeCreation: () => { nativeCreationAllowed = true },
    pauseKills: () => {
      let release
      killGate = new Promise(resolve => { release = resolve })
      const started = new Promise(resolve => { notifyKillStarted = resolve })
      return { started, release }
    },
  }
}

const widget = (id, type) => ({ id, type, position: { x: 24, y: 24 }, props: type === 'agent-chat' ? { agentId: `native-${id}` } : {} })

for (const type of ['terminal', 'agent', 'agent-chat']) {
  it(`deleting a ${type} widget closes its execution and writes a tombstone`, async () => {
    const target = widget('target', type)
    const f = await fixture([target])
    const session = await f.addSession(target)
    const result = await f.invoke('/widget', 'DELETE', { widgetId: target.id })
    assert.equal(result.status, 200, JSON.stringify(result.body))
    assert.deepEqual(f.read().widgets, [])
    if (type === 'agent-chat') assert.deepEqual(f.calls.archives, ['native-target'])
    else {
      assert.deepEqual(f.calls.kills, [session.terminalId])
      assert.deepEqual(f.terminals(), [])
      assert.equal(registry.getSession(session.entry.sessionId), null)
    }
    assert.equal(config.readTerminalConfigById(target.id).deleted, true)
  })
}

it('batch widget deletion closes every selected terminal and native agent', async () => {
  const widgets = [widget('first', 'terminal'), widget('second', 'agent-chat')]
  const f = await fixture(widgets)
  for (const item of widgets) await f.addSession(item)
  const result = await f.invoke('/batch', 'POST', { operations: widgets.map(item => ({ op: 'delete-widget', widgetId: item.id })) })
  assert.equal(result.status, 200, JSON.stringify(result.body))
  assert.deepEqual(f.read().widgets, [])
  assert.equal(f.calls.kills.length, 1)
  assert.deepEqual(f.calls.archives, ['native-second'])
})

it('full canvas replacement closes removed widget sessions', async () => {
  const target = widget('target', 'terminal')
  const survivor = { id: 'note', type: 'sticky-note', position: { x: 960, y: 24 }, props: { text: 'keep' } }
  const f = await fixture([target, survivor])
  await f.addSession(target)
  const result = await f.invoke('/update', 'PUT', { widgets: [survivor], replaceAll: true })
  assert.equal(result.status, 200, JSON.stringify(result.body))
  assert.deepEqual(f.read().widgets.map(item => item.id), ['note'])
  assert.deepEqual(f.terminals(), [])
  assert.equal(f.calls.kills.length, 1)
})

it('deleting a whole canvas closes every owning session before deleting the file', async () => {
  const widgets = [widget('shell', 'terminal'), widget('native', 'agent-chat')]
  const f = await fixture(widgets)
  for (const item of widgets) await f.addSession(item)
  const result = await f.invoke('/delete-canvas', 'DELETE', {})
  assert.equal(result.status, 200, JSON.stringify(result.body))
  assert.equal(fs.existsSync(f.file), false)
  assert.deepEqual(f.terminals(), [])
  assert.deepEqual(f.calls.archives, ['native-native'])
})

it('failed terminal close preserves the widget and identity, and successful retry deletes them', async () => {
  const target = widget('target', 'terminal')
  const f = await fixture([target])
  const session = await f.addSession(target)
  f.failKills(true)
  const failed = await f.invoke('/widget', 'DELETE', { widgetId: target.id })
  assert.equal(failed.status, 500)
  assert.deepEqual(f.read().widgets.map(item => item.id), ['target'])
  assert.equal(config.readTerminalConfigById(target.id).deleted, false)
  assert.ok(registry.getSession(session.entry.sessionId))
  assert.equal(f.terminals().length, 1)
  f.failKills(false)
  assert.equal((await f.invoke('/widget', 'DELETE', { widgetId: target.id })).status, 200)
  assert.deepEqual(f.read().widgets, [])
  assert.deepEqual(f.terminals(), [])
})

it('failed native archive preserves its widget and reverses the pending tombstone', async () => {
  const target = widget('target', 'agent-chat')
  const f = await fixture([target])
  await f.addSession(target)
  f.failArchives(true)
  const result = await f.invoke('/widget', 'DELETE', { widgetId: target.id })
  assert.equal(result.status, 500)
  assert.deepEqual(f.read().widgets.map(item => item.id), ['target'])
  assert.equal(config.readTerminalConfigById(target.id).deleted, false)
})

it('undo restores a removed widget without relaunching its killed session, and redo deletes again', async () => {
  const target = widget('target', 'terminal')
  const f = await fixture([target])
  await f.addSession(target)
  const removed = await f.invoke('/widget', 'DELETE', { widgetId: target.id })
  const restored = await f.invoke('/undo', 'POST', { eventId: removed.body.eventId })
  assert.equal(restored.status, 200, JSON.stringify(restored.body))
  assert.deepEqual(f.read().widgets.map(item => item.id), ['target'])
  assert.equal(config.readTerminalConfigById(target.id).deleted, false)
  assert.deepEqual(f.terminals(), [])
  assert.equal(f.calls.creates.length, 1)
  const redone = await f.invoke('/redo', 'POST', { eventId: restored.body.eventId })
  assert.equal(redone.status, 200, JSON.stringify(redone.body))
  assert.deepEqual(f.read().widgets, [])
  assert.equal(config.readTerminalConfigById(target.id).deleted, true)
})

it('widget deletion waits for the shared startup operation then closes its newly created session', async () => {
  const target = widget('target', 'terminal')
  const f = await fixture([target])
  let resume
  const gate = new Promise(resolve => { resume = resolve })
  const starting = withTerminalStartup(terminalWidgetStartupKey(f.root, target.id), async () => { await gate; return f.addSession(target) })
  const deleting = f.invoke('/widget', 'DELETE', { widgetId: target.id })
  await nextTurn()
  assert.equal(f.calls.kills.length, 0)
  assert.equal(f.calls.creates.length, 0)
  resume()
  const session = await starting
  assert.equal((await deleting).status, 200)
  assert.deepEqual(f.calls.kills, [session.terminalId])
  assert.deepEqual(f.terminals(), [])
  assert.equal(config.readTerminalConfigById(target.id).deleted, true)
})

it('a removed native widget rejects delayed creation before reaching the SDK', async () => {
  const target = widget('target', 'agent-chat')
  const f = await fixture([target])
  await f.addSession(target)
  assert.equal((await f.invoke('/widget', 'DELETE', { widgetId: target.id })).status, 200)
  await assert.rejects(f.native.createAgent({ config: { provider: 'codex' }, context: { canvasId: 'lifecycle', widgetId: target.id } }), /widget has been removed/)
})

it('a retained PUT preserves the deletion marker while terminal shutdown is pending', async () => {
  const target = widget('target', 'terminal')
  const f = await fixture([target])
  await f.addSession(target)
  const shutdown = f.pauseKills()
  const deleting = f.invoke('/widget', 'DELETE', { widgetId: target.id })
  try {
    await shutdown.started
    assert.equal(config.readTerminalConfigById(target.id).deleted, true)
    const retained = await f.invoke('/update', 'PUT', { widgets: [{ ...target, position: { x: 72, y: 24 } }] })
    assert.equal(retained.status, 200, JSON.stringify(retained.body))
    assert.equal(config.readTerminalConfigById(target.id).deleted, true)
  } finally {
    shutdown.release()
    await deleting
  }
  assert.equal(config.readTerminalConfigById(target.id).deleted, true)
  assert.deepEqual(f.terminals(), [])
  assert.deepEqual(f.read().widgets, [])
})

it('native creation without a saved widget config persists the resulting agent identity for deletion', async () => {
  const target = { ...widget('target', 'agent-chat'), props: {} }
  const f = await fixture([target])
  assert.equal(config.readTerminalConfigById(target.id), null)
  f.allowNativeCreation()
  const result = await f.native.createAgent({ config: { provider: 'codex' }, context: { canvasId: 'lifecycle', widgetId: target.id } })
  const saved = config.readTerminalConfigById(target.id)
  assert.equal(saved?.lastAgentId, result.agent.id)
  assert.equal(saved?.canvasId, 'lifecycle')
  assert.deepEqual(f.calls.nativeCreates, [result.agent.id])
  assert.equal((await f.invoke('/widget', 'DELETE', { widgetId: target.id })).status, 200)
  assert.deepEqual(f.calls.archives, [result.agent.id])
  assert.deepEqual(f.read().widgets, [])
})
