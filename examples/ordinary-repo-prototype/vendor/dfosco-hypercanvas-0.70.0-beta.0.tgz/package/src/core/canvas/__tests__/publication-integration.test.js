/**
 * Publication integration: generate a fresh portable publication from the
 * site-frame fixture Notebook and prove the strongest regression boundary —
 * `npm ci` and `npm run build` succeed from inside the generated `publish/`
 * directory, the Pages outputs exist, @dfosco dependencies resolve from
 * npmjs, and every published snapshot URL references a real file (never
 * `/undefined`).
 *
 * Uses the real npm and network; run via `npm run test:integration`.
 */
import { describe, expect, it } from 'vitest'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { materializeProject } from '../../notebook/publishing/generator.js'
import { buildProject } from '../../notebook/publishing/build.js'

const execFileAsync = promisify(execFile)
const FIXTURE = path.resolve('fixtures/notebooks/site-frame-notebook')

function temp(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), `publication-integration-${name}-`))
}

function walkFiles(root) {
  const files = []
  const walk = (directory) => {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const full = path.join(directory, entry.name)
      if (entry.isDirectory()) walk(full)
      else if (entry.isFile()) files.push(path.relative(root, full).split(path.sep).join('/'))
    }
  }
  walk(root)
  return files
}

describe('fresh publication build integration', () => {
  it('generates a complete publication and builds it from inside publish/', { timeout: 600_000 }, async () => {
    const notebook = temp('notebook')
    fs.cpSync(FIXTURE, notebook, { recursive: true })
    const output = path.join(temp('output'), 'publish')

    const project = await materializeProject({ notebookRoot: notebook, destination: output, mode: 'external' })
    expect(project.warnings.map(warning => warning.code)).toEqual([])

    // Complete scaffold inventory.
    for (const required of [
      'package.json',
      'package-lock.json',
      'hypercanvas.config.json',
      'vendor/hypercanvas/package.json',
      'vendor/hypercanvas/hypercanvas.config.json',
      'vendor/hypercanvas/scripts/gen-themes-css.mjs',
      'vendor/hypercanvas/vite.ui.config.js',
      'vendor/hypercanvas/vite.canvas.config.js',
      'vendor/hypercanvas/dist/core/vite/server-plugin.js',
      'vendor/hypercanvas/dist/core/vite/server-plugin.d.ts',
      'vendor/hypercanvas/dist/internals/vite/data-plugin.js',
      'vendor/hypercanvas/src/core/styles/tailwind.css',
      'src/library/workspace-entry.jsx',
    ]) {
      expect(fs.existsSync(path.join(output, ...required.split('/'))), required).toBe(true)
    }
    const vendoredTailwind = fs.readFileSync(path.join(output, 'vendor/hypercanvas/src/core/styles/tailwind.css'), 'utf8')
    expect(vendoredTailwind).toContain('url("../../../assets/fonts/HubotSans/Hubot-Sans.woff2")')
    expect(fs.readFileSync(path.join(output, '.npmrc'), 'utf8')).toBe('@dfosco:registry=https://registry.npmjs.org/\n')

    // Route-specific snapshot identity survives publication: two Site Frames
    // with different routes reference two distinct persisted snapshots.
    const payload = JSON.parse(fs.readFileSync(path.join(output, 'index.html'), 'utf8').match(/window\.__HYPERCANVAS_NOTEBOOK_PUBLICATION__=([^<]+)/)[1])
    const frames = payload.pages.find(page => page.type === 'canvas').siteFrames
    expect(Object.keys(frames).sort()).toEqual(['docs-guide', 'docs-home-frame'])
    expect(frames['docs-guide'].snapshot).toMatch(/assets\/canvas\/snapshots\/frames\/[0-9a-f]{32}\/[0-9a-f]{32}-light\.png$/)
    expect(frames['docs-guide'].snapshotDark).toMatch(/-dark\.png$/)
    expect(frames['docs-home-frame'].snapshot).not.toBe(frames['docs-guide'].snapshot)
    for (const pathKey of ['snapshot', 'snapshotDark']) {
      const snapshotPath = frames['docs-guide'][pathKey] || frames['docs-home-frame'][pathKey]
      if (!snapshotPath) continue
      expect(fs.existsSync(path.join(output, 'public', ...snapshotPath.split('/'))), snapshotPath).toBe(true)
      expect(snapshotPath.includes('/undefined')).toBe(false)
    }

    // The strongest regression: install and build from inside the generated
    // publication — exactly what the Pages workflow runs.
    fs.rmSync(path.join(output, 'node_modules'), { recursive: true, force: true })
    fs.rmSync(path.join(output, 'dist'), { recursive: true, force: true })
    for (const bundle of [
      'storyboard-ui.js', 'storyboard-ui.css', 'tailwind.css',
      'tiny-canvas.js', 'tiny-canvas.css',
    ]) {
      fs.rmSync(path.join(output, 'vendor/hypercanvas/dist', bundle), { force: true })
    }
    fs.rmSync(path.join(output, 'src/router.ts'), { force: true })
    let dist
    try {
      const result = await buildProject({ projectDir: output, basePath: '/site-frame-fixture/' })
      dist = result.dist
    } catch (error) {
      throw new Error(`${error.message}\n${error.detail || ''}`)
    }

    // GitHub Pages outputs.
    for (const artifact of ['index.html', '404.html', '.nojekyll']) {
      expect(fs.existsSync(path.join(dist, ...artifact.split('/'))), artifact).toBe(true)
    }

    // The vendored runtime actually built: `build:runtime` produced its
    // bundles inside vendor/hypercanvas/dist (gitignored, reproducible).
    for (const bundle of ['storyboard-ui.js', 'storyboard-ui.css', 'tailwind.css', 'tiny-canvas.js', 'tiny-canvas.css']) {
      expect(fs.existsSync(path.join(output, 'vendor/hypercanvas/dist', bundle)), bundle).toBe(true)
    }
    const distInventory = walkFiles(dist)
    // The site build inlines those bundles into real app chunks.
    expect(distInventory.some(entry => entry.endsWith('.js'))).toBe(true)
    expect(distInventory.some(entry => entry.includes('CanvasPage'))).toBe(true)

    // Snapshot previews survive the real build: no /undefined anywhere and
    // every referenced snapshot exists in dist/.
    for (const entry of distInventory.filter(entry => /\.(?:html|json)$/.test(entry))) {
      expect(fs.readFileSync(path.join(dist, ...entry.split('/')), 'utf8').includes('/undefined'), entry).toBe(false)
    }
    for (const pathKey of ['snapshot', 'snapshotDark']) {
      const snapshotPath = frames['docs-guide'][pathKey] || frames['docs-home-frame'][pathKey]
      if (!snapshotPath) continue
      expect(fs.existsSync(path.join(dist, ...snapshotPath.split('/'))), snapshotPath).toBe(true)
    }

    // npmjs is authoritative for the publication's @dfosco dependencies.
    const lockfile = JSON.parse(fs.readFileSync(path.join(output, 'package-lock.json'), 'utf8'))
    expect(lockfile.packages['node_modules/@dfosco/statefully']?.resolved).toMatch(/^https:\/\/registry\.npmjs\.org\/@dfosco\/statefully\//)
    expect(lockfile.packages['node_modules/react-is']?.resolved).toMatch(/^https:\/\/registry\.npmjs\.org\/react-is\//)
    const listed = await execFileAsync('npm', ['ls', '@dfosco/statefully', 'react-is'], { cwd: output, encoding: 'utf8' })
    expect(listed.stdout).toContain('@dfosco/statefully@')
    expect(listed.stdout).toContain('react-is@')
  })
})
