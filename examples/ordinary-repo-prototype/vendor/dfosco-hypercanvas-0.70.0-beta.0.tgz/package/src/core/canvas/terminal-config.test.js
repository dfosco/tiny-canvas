import { describe, it, expect, beforeEach, afterEach } from 'vitest'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  initTerminalConfig,
  writeTerminalConfig,
  recordAgentSession,
  getLastAgentSession,
  getConfigKey,
  buildSquadBootstrapPrompt,
} from './terminal-config.js'

let root
beforeEach(() => {
  root = mkdtempSync(join(tmpdir(), 'sb-term-cfg-'))
  initTerminalConfig(root)
})
afterEach(() => { try { rmSync(root, { recursive: true, force: true }) } catch { /* empty */ } })

describe('terminal-config: agent session persistence', () => {
  it('bootstraps numbered Squad write/scan behavior and explicit attention delivery', () => {
    const prompt = buildSquadBootstrapPrompt('agent-a')
    expect(prompt).toContain('storyboard squad list')
    expect(prompt).toContain('Record every turn')
    expect(prompt).toContain('Never invent or predict a number')
    expect(prompt).toContain('between turns and before going idle')
    expect(prompt).toContain('acknowledgement is receipt, not completion')
    expect(prompt).toContain('The only message kinds are information and instruction')
    expect(prompt).toContain('storyboard squad reply')
    expect(prompt).toContain('actual IDs returned by canvas creation')
    expect(prompt).toContain('acknowledges EACH returned result number')
    expect(prompt).toContain('visually connected only')
    expect(prompt).not.toContain('storyboard inbox poll')
    expect(prompt).not.toContain('storyboard hub context')
  })

  it('records and reads back the captured session id, agent id, and timestamp', () => {
    writeTerminalConfig({
      branch: 'main',
      canvasId: 'design',
      widgetId: 'agent-foo',
      serverUrl: 'http://localhost:1234',
    })
    recordAgentSession({
      branch: 'main',
      canvasId: 'design',
      widgetId: 'agent-foo',
      agentId: 'copilot',
      sessionId: 'abcd-1234',
    })
    const got = getLastAgentSession({ branch: 'main', canvasId: 'design', widgetId: 'agent-foo' })
    expect(got?.sessionId).toBe('abcd-1234')
    expect(got?.agentId).toBe('copilot')
    expect(typeof got?.capturedAt).toBe('string')
  })

  it('returns null when no session has been recorded', () => {
    writeTerminalConfig({ branch: 'main', canvasId: 'c', widgetId: 'agent-bar' })
    expect(getLastAgentSession({ branch: 'main', canvasId: 'c', widgetId: 'agent-bar' })).toBeNull()
  })

  it('no-ops on empty session id', () => {
    writeTerminalConfig({ branch: 'main', canvasId: 'c', widgetId: 'agent-baz' })
    const result = recordAgentSession({ branch: 'main', canvasId: 'c', widgetId: 'agent-baz', sessionId: '' })
    expect(result).toBeNull()
  })

  it('exposes a stable per-widget config key', () => {
    const a = getConfigKey('main', 'design', 'agent-x')
    const b = getConfigKey('main', 'design', 'agent-x')
    expect(a).toBe(b)
    expect(a).toMatch(/^[0-9a-f]{16}$/)
    expect(getConfigKey('other', 'design', 'agent-x')).not.toBe(a)
  })
})
