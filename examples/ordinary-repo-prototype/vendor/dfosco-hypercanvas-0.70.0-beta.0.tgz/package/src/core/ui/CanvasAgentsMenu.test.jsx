import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { vi } from 'vitest'
import { getConfig } from '../index.js'
import CanvasAgentsMenu from './CanvasAgentsMenu.jsx'

vi.mock('../index.js', () => ({ getConfig: vi.fn() }))
vi.mock('./Icon.jsx', () => ({ default: ({ name }) => <span aria-hidden="true">{name}</span> }))

const agentsConfig = {
  agents: {
    codex: { label: 'Codex CLI', startupCommand: 'codex', icon: 'codex' },
    claude: { label: 'Claude Code', startupCommand: 'claude', icon: 'claude' },
  },
}

function preflight(overrides = {}) {
  return {
    status: 'supported',
    support: { status: 'supported', platform: 'darwin', arch: 'arm64' },
    baseline: { status: 'missing', minimumNodeMajor: 22 },
    agents: {
      codex: { status: 'missing', path: null, version: null },
      claude: { status: 'missing', path: null, version: null },
    },
    ...overrides,
  }
}

function client(overrides = {}) {
  return { preflight: vi.fn().mockResolvedValue(preflight()), ...overrides }
}

async function openAgentsMenu(user) {
  await user.click(screen.getByRole('button', { name: 'Add agent' }))
  await screen.findByText(/Core Node\/npm baseline: missing/)
}

beforeEach(() => {
  vi.clearAllMocks()
  getConfig.mockReturnValue(agentsConfig)
})

afterEach(() => {
  vi.unstubAllGlobals()
})

describe('CanvasAgentsMenu', () => {
  it('launches an installed CLI even when its generic version probe fails', async () => {
    const user = userEvent.setup()
    const hostClient = client({
      preflight: vi.fn().mockResolvedValue(preflight({
        agents: {
          codex: { status: 'installed', path: '/Users/test/.local/bin/codex', version: null, reason: 'nonzero_exit' },
        },
      })),
    })
    const listener = vi.fn()
    document.addEventListener('storyboard:canvas:add-widget', listener)
    render(<CanvasAgentsMenu canvasName="research" hostToolsClient={hostClient} />)

    await openAgentsMenu(user)
    expect(screen.getByText('Found, version check failed')).toBeVisible()
    await user.click(screen.getByRole('menuitem', { name: /Codex CLI/ }))

    expect(listener).toHaveBeenCalledOnce()
    expect(listener.mock.calls[0][0].detail).toEqual({
      type: 'agent',
      canvasName: 'research',
      props: { agentId: 'codex', startupCommand: 'codex' },
    })
    document.removeEventListener('storyboard:canvas:add-widget', listener)
  })

  it('does not offer an installer when a tool is missing and keeps missing-agent launch diagnosable', async () => {
    const user = userEvent.setup()
    const hostClient = client()
    const listener = vi.fn()
    document.addEventListener('storyboard:canvas:add-widget', listener)
    render(<CanvasAgentsMenu canvasName="research" hostToolsClient={hostClient} />)

    await openAgentsMenu(user)
    expect(screen.getAllByText('Not found')).not.toHaveLength(0)
    expect(screen.getByText(/Missing CLIs are user-managed/)).toBeVisible()
    expect(screen.queryByText(/Manage Agent CLIs|Install selected|setup plan/i)).not.toBeInTheDocument()
    await user.click(screen.getByRole('menuitem', { name: /Codex CLI/ }))
    expect(listener).toHaveBeenCalledOnce()
    document.removeEventListener('storyboard:canvas:add-widget', listener)
  })

  it('shows unsupported diagnostics without assuming response fields exist', async () => {
    const user = userEvent.setup()
    const hostClient = client({
      preflight: vi.fn().mockResolvedValue({ status: 'unsupported', support: { status: 'unsupported' }, baseline: null, agents: null }),
    })
    const { unmount } = render(<CanvasAgentsMenu hostToolsClient={hostClient} />)

    await user.click(screen.getByRole('button', { name: 'Add agent' }))
    expect(await screen.findAllByText('Unsupported')).not.toHaveLength(0)
    expect(screen.getAllByText('Unsupported').length).toBeGreaterThan(0)
    unmount()

  })

  it('uses the CoreUIBar branch base path for browser preflight', async () => {
    const user = userEvent.setup()
    const fetchImpl = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: vi.fn().mockResolvedValue(preflight()),
    })
    vi.stubGlobal('fetch', fetchImpl)
    render(<CanvasAgentsMenu basePath="/branch--agent-setup/" />)

    await openAgentsMenu(user)

    expect(fetchImpl).toHaveBeenCalledWith('/branch--agent-setup/_hypercanvas/host-tools/preflight', { method: 'GET' })
  })
})
