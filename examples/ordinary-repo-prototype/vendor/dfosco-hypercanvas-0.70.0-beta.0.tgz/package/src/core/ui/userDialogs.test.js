import { beforeEach, afterEach, describe, expect, it } from 'vitest'
import { requestText, requestConfirmation } from './userDialogs.js'

beforeEach(() => {
  Object.defineProperty(HTMLDialogElement.prototype, 'showModal', { configurable: true, value() {
    this.setAttribute('open', '')
    this.querySelector('[autofocus]')?.focus()
  } })
  Object.defineProperty(HTMLDialogElement.prototype, 'close', { configurable: true, value(value = '') {
    this.returnValue = value
    this.removeAttribute('open')
    this.dispatchEvent(new Event('close'))
  } })
})
afterEach(() => {
  document.body.replaceChildren()
  delete HTMLDialogElement.prototype.showModal
  delete HTMLDialogElement.prototype.close
})

function submit(dialog) {
  dialog.querySelector('form').dispatchEvent(new Event('submit', { cancelable: true }))
}

describe('asynchronous authoring dialogs', () => {
  it('submits edited text and returns focus to the initiating control', async () => {
    const trigger = document.createElement('button')
    document.body.append(trigger)
    trigger.focus()
    const result = requestText('Page title', 'Original title')
    const dialog = document.querySelector('dialog')
    const input = dialog.querySelector('input')
    expect(document.activeElement).toBe(input)
    expect(input.value).toBe('Original title')
    input.value = 'Renamed title'
    submit(dialog)
    expect(await result).toBe('Renamed title')
    expect(document.querySelector('dialog')).toBeNull()
    expect(document.activeElement).toBe(trigger)
  })

  it('cancels text input without applying the edited value', async () => {
    const result = requestText('Page title', 'Original')
    const dialog = document.querySelector('dialog')
    dialog.querySelector('input').value = 'Do not save'
    dialog.querySelector('button').click()
    expect(await result).toBeNull()
  })

  it('keeps blank text from being submitted', async () => {
    const result = requestText('Section name')
    const dialog = document.querySelector('dialog')
    const input = dialog.querySelector('input')
    input.value = '   '
    input.dispatchEvent(new Event('input'))
    expect(dialog.querySelector('button[type="submit"]').disabled).toBe(true)
    submit(dialog)
    expect(dialog.open).toBe(true)
    dialog.close()
    expect(await result).toBeNull()
  })

  it('renders untrusted file names as text and defaults destructive focus to Cancel', async () => {
    const message = 'Delete <img src=x onerror=alert(1)>?'
    const result = requestConfirmation(message)
    const dialog = document.querySelector('dialog')
    expect(dialog.querySelector('p').textContent).toBe(message)
    expect(dialog.querySelector('img')).toBeNull()
    expect(document.activeElement.textContent).toBe('Cancel')
    dialog.close()
    expect(await result).toBe(false)
  })

  it('requires explicit submission to confirm a destructive action', async () => {
    const result = requestConfirmation('Delete these files?')
    submit(document.querySelector('dialog'))
    expect(await result).toBe(true)
  })
})
