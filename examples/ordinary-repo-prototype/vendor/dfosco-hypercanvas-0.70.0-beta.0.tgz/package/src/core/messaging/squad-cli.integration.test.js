import { afterEach, describe, expect, it } from 'vitest'
import { execFile } from 'node:child_process'
import { createServer } from 'node:http'
import { promisify } from 'node:util'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { createMessagingRoutes } from './routes.js'
import { JsonlAdapter } from './storage/jsonl-adapter.js'
import { initBus, resetBus } from './bus.js'
import { buildCoreRuntime } from '../../../scripts/build-core-runtime.mjs'

const execFileAsync = promisify(execFile)
const roots = []
const servers = []

afterEach(async () => {
  resetBus()
  for (const server of servers.splice(0)) await new Promise((resolve) => server.close(resolve))
  for (const root of roots.splice(0)) fs.rmSync(root, { recursive: true, force: true })
})

describe('Messaging CLI → Core route integration', () => {
  it('preserves message field mappings and round-trips Squad attachments and file references', async () => {
    const runtimeRoot = fs.mkdtempSync(path.resolve('packages/storyboard/.squad-cli-runtime-'))
    roots.push(runtimeRoot)
    const { destination: compiledCoreRoot } = buildCoreRuntime({
      sourceRoot: path.resolve('packages/storyboard/src/core'),
      distRoot: path.join(runtimeRoot, 'dist'),
      emitDeclarations: false,
    })
    const cliPath = path.join(compiledCoreRoot, 'cli/index.js')

    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'squad-cli-integration-'))
    roots.push(root)
    const adapter = new JsonlAdapter({ root })
    await adapter.init()
    initBus(adapter)

    const submissions = []
    const route = createMessagingRoutes({
      sendJson: (res, status, value) => {
        res.writeHead(status, { 'Content-Type': 'application/json' })
        res.end(JSON.stringify(value))
      },
      getSquadContext: async () => ({ root, workspaceId: 'notebook-test', daemonId: 'paseo-test' }),
      getSquadDeliveryOptions: async () => ({
        sessionFor: async (widgetId) => `session-${widgetId}`,
        isReady: () => true,
        submitTerminalText: async (sessionId, text, options) => {
          submissions.push({ sessionId, text, options })
          return { accepted: true, submitted: true }
        },
      }),
    })
    const server = createServer(async (req, res) => {
      const chunks = []
      for await (const chunk of req) chunks.push(chunk)
      await route(req, res, {
        method: req.method,
        path: req.url.replace(/^\/_(?:storyboard|hypercanvas)\/messages/, '') || '/',
        body: Buffer.concat(chunks).toString('utf8') || undefined,
      })
    })
    servers.push(server)
    await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
    const address = server.address()
    const env = {
      ...process.env,
      HYPERCANVAS_SERVER_URL: `http://127.0.0.1:${address.port}`,
      HYPERCANVAS_WIDGET_ID: 'leader',
    }
    const runCli = async (...args) => {
      const { stdout } = await execFileAsync(process.execPath, [cliPath, 'squad', ...args], { env })
      return JSON.parse(stdout.trim())
    }

    const runMessagesCli = async (...args) => {
      const { stdout } = await execFileAsync(process.execPath, [cliPath, 'messages', ...args], { env })
      return JSON.parse(stdout.trim())
    }

    const publishedMessage = await runMessagesCli(
      'publish', '--channel', 'cli:events', '--type', 'cli:published', '--sender', 'leader',
      '--body', 'CLI event', '--payload', '{"source":"cli"}',
    )
    expect(publishedMessage.event).toMatchObject({
      channel: 'cli:events', type: 'cli:published', senderId: 'leader', body: 'CLI event', source: 'cli',
    })
    const readMessages = await runMessagesCli('read', '--channel', 'cli:events', '--type', 'cli:')
    expect(readMessages.events).toHaveLength(1)
    expect(readMessages.events[0].id).toBe(publishedMessage.event.id)
    await expect(runMessagesCli(
      'publish', '--channel', 'cli:events', '--type', 'cli:bad-payload', '--payload', '[]',
    )).rejects.toThrow()

    const created = await runCli('create', 'Review', '--members', 'worker-a,worker-b')
    const squadId = created.squad.squadId
    const attachments = ['Read the patch summary', { checks: ['null safety', 'retry'] }]
    const files = ['src/example.js', 'docs/review.json']
    const appended = await runCli(
      'append', squadId,
      '--kind', 'instruction',
      '--description', 'Review this change',
      '--to', 'worker-a,worker-b',
      '--inject',
      '--attachments', JSON.stringify(attachments),
      '--files', JSON.stringify(files),
    )
    expect(appended.entry).toMatchObject({ number: 1, author: 'leader', attachments, files })
    expect(appended.delivery).toHaveLength(2)
    expect(submissions).toMatchObject([
      {
        sessionId: 'session-worker-a',
        text: `Review this change\n\nSquad ledger reference:\n${JSON.stringify({ squadId, number: 1 }, null, 2)}`,
        options: { submit: true, paste: true },
      },
      {
        sessionId: 'session-worker-b',
        text: `Review this change\n\nSquad ledger reference:\n${JSON.stringify({ squadId, number: 1 }, null, 2)}`,
        options: { submit: true, paste: true },
      },
    ])

    const fetched = await runCli('get', squadId, '1')
    expect(fetched.entry).toMatchObject({ number: 1, attachments, files })
    const passive = await runCli('append', squadId, '--kind', 'information', '--description', 'Room-only update')
    const disabled = await runCli(
      'append', squadId, '--kind', 'instruction', '--description', 'No injection', '--to', 'worker-a', '--inject', 'false',
    )
    expect(passive).toMatchObject({ entry: { kind: 'information' }, delivery: [] })
    expect(disabled).toMatchObject({ entry: { kind: 'instruction', inject: false }, delivery: [] })
    expect(disabled.entry.number).toBe(passive.entry.number + 1)
    expect(submissions).toHaveLength(2)

    // Qualify a fresh canvas relationship through the real compiled CLI and HTTP route.
    fs.mkdirSync(path.join(root, 'canvas'))
    const canvasPath = path.join(root, 'canvas', 'welcome.canvas.jsonl')
    fs.writeFileSync(canvasPath, JSON.stringify({ event: 'canvas_created', widgets: ['leader', 'worker-a', 'worker-b'].map((id, index) => ({
      id, type: 'agent', position: { x: index * 700, y: 100 }, props: { width: 500, height: 300 },
    })) }) + '\n')
    const canvasRoom = await runCli('create', 'Canvas review', '--canvas', 'welcome', '--members', 'worker-a,worker-b')
    expect(canvasRoom.squad.squadId).toBe(squadId) // Adopt the existing same-member room, preserving its history.
    expect(fs.readFileSync(canvasPath, 'utf8').split('\n').filter((line) => line.includes('connector_added'))).toHaveLength(2)
    await runCli('broadcast', '--canvas', 'welcome', '--enabled', 'false', '--squad', squadId)
    expect((await runCli('list')).squads[0]).toMatchObject({ broadcast: { enabled: false }, activeMemberIds: [] })
    await expect(runCli('append', squadId, '--kind', 'instruction', '--description', 'Disabled', '--to', 'worker-a', '--inject')).rejects.toThrow()
    expect(submissions).toHaveLength(2)
    await runCli('broadcast', '--canvas', 'welcome', '--enabled', 'true', '--squad', squadId)
    const assignment = await runCli('append', squadId, '--kind', 'instruction', '--description', 'Review connected canvas', '--to', 'worker-a,worker-b', '--inject')
    expect(assignment.delivery).toMatchObject([{ recipient: 'worker-a', status: 'submitted' }, { recipient: 'worker-b', status: 'submitted' }])
    const peerCli = async (widgetId, ...args) => {
      const { stdout } = await execFileAsync(process.execPath, [cliPath, 'squad', ...args], { env: { ...env, HYPERCANVAS_WIDGET_ID: widgetId } })
      return JSON.parse(stdout.trim())
    }
    for (const peer of ['worker-a', 'worker-b']) {
      await peerCli(peer, 'reply', squadId, String(assignment.entry.number), '--response', 'ack', '--description', 'Received')
      const result = await peerCli(peer, 'reply', squadId, String(assignment.entry.number), '--response', 'result', '--description', 'Review complete')
      expect(result.entry).toMatchObject({ kind: 'information', response: 'result', replyTo: assignment.entry.number, author: peer })
      await runCli('reply', squadId, String(result.entry.number), '--response', 'ack', '--description', 'Result accepted')
    }
    const finalWork = (await runCli('reconcile', squadId)).work.filter((work) => work.number === assignment.entry.number)
    expect(finalWork).toMatchObject([{ recipient: 'worker-a', state: 'completed' }, { recipient: 'worker-b', state: 'completed' }])
    expect(submissions).toHaveLength(4)
    await expect(runCli('broadcast', '--canvas', 'welcome', '--enabled', 'maybe')).rejects.toThrow()
    await expect(peerCli('worker-a', 'append', squadId, '--kind', 'result', '--description', 'Invalid kind')).rejects.toThrow()
  }, 60_000)
})
