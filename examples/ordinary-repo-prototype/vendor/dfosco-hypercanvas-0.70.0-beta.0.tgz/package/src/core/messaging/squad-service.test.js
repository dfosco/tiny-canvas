import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { SquadService } from './squad-service.js'

const roots = []
function setup(identity = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'squad-service-'))
  roots.push(root)
  return new SquadService({ root, workspaceId: 'notebook-a', daemonId: 'daemon-a', ...identity })
}

afterEach(() => {
  for (const root of roots.splice(0)) fs.rmSync(root, { recursive: true, force: true })
})

describe('SquadService', () => {
  it('creates workspace/daemon-scoped membership and supports numbered room operations', async () => {
    const service = setup()
    const squad = await service.create({ leaderId: 'agent-a', memberIds: ['agent-b'], name: 'Review' })
    expect(squad.members).toEqual({ 'agent-a': { role: 'leader' }, 'agent-b': { role: 'member' } })
    const entry = await service.append(squad.squadId, 'agent-a', {
      kind: 'instruction', description: 'Review parser', to: ['agent-b'], inject: true,
    })
    expect(entry).toMatchObject({ number: 1, author: 'agent-a' })
    const reply = await service.append(squad.squadId, 'agent-b', {
      kind: 'information', description: 'Done', replyTo: 1, response: 'result',
    })
    expect(reply).toMatchObject({ number: 2, replyTo: 1, author: 'agent-b' })
    expect(await service.read(squad.squadId, 'agent-a', { after: 1 })).toMatchObject([{ number: 2 }])
    expect(await service.get(squad.squadId, 'agent-a', 1)).toMatchObject({ number: 1 })
    expect((await service.list('agent-b')).map((item) => item.squadId)).toEqual([squad.squadId])
  })

  it('rejects non-members, non-members as recipients, unauthorized replies, and wrong daemon bindings', async () => {
    const service = setup()
    const squad = await service.create({ leaderId: 'agent-a', memberIds: ['agent-b'] })
    await expect(service.append(squad.squadId, 'outsider', { kind: 'information', description: 'x' }))
      .rejects.toThrow('not a member')
    await expect(service.append(squad.squadId, 'agent-a', { kind: 'instruction', description: 'x', to: ['outsider'] }))
      .rejects.toThrow('Every recipient')
    await service.append(squad.squadId, 'agent-a', { kind: 'instruction', description: 'x', to: ['agent-b'] })
    await expect(service.append(squad.squadId, 'agent-c', { kind: 'information', description: 'reply', replyTo: 1, response: 'result' }))
      .rejects.toThrow('not a member')
    const otherDaemon = new SquadService({ root: service.root, workspaceId: 'notebook-a', daemonId: 'daemon-b' })
    await expect(otherDaemon.read(squad.squadId, 'agent-a')).rejects.toThrow('different Notebook workspace or Paseo daemon')
  })

  it('persists exact workspace/daemon agent bindings and replacement history outside room entries', async () => {
    const service = setup()
    const squad = await service.create({ leaderId: 'agent-a' })
    await service.bindAgent(squad.squadId, 'agent-a', { agentId: 'paseo-agent-1', provider: 'openai', transition: 'created' })
    await service.bindAgent(squad.squadId, 'agent-a', { agentId: 'paseo-agent-1', provider: 'openai', transition: 'resumed' })
    await service.bindAgent(squad.squadId, 'agent-a', {
      agentId: 'paseo-agent-2', provider: 'openai', transition: 'created', reason: 'Native resume failed: agent is archived',
    })
    expect(await service.getAgentBinding(squad.squadId, 'agent-a')).toMatchObject({
      agentId: 'paseo-agent-2', workspaceId: 'notebook-a', daemonId: 'daemon-a',
    })
    const history = JSON.parse(fs.readFileSync(path.join(service.baseDir, squad.squadId, 'agent-bindings.json'), 'utf8')).history
    expect(history.map((item) => item.transition)).toEqual(['created', 'resumed', 'replaced'])
    expect(history[2].reason).toContain('Native resume failed')
    const restarted = new SquadService({ root: service.root, workspaceId: 'notebook-a', daemonId: 'daemon-a' })
    expect(await restarted.getAgentBinding(squad.squadId, 'agent-a')).toMatchObject({ agentId: 'paseo-agent-2' })
    expect(await service.read(squad.squadId, 'agent-a')).toEqual([])
  })

  it('finds a persisted native binding and appends server-only lifecycle/permission events', async () => {
    const service = setup()
    const squad = await service.create({ leaderId: 'agent-a' })
    await service.bindAgent(squad.squadId, 'agent-a', { agentId: 'paseo-agent-a', provider: 'openai' })
    expect(await service.findAgentBindings('paseo-agent-a')).toMatchObject([{ squadId: squad.squadId, widgetId: 'agent-a' }])
    const event = await service.appendSystemEvent(squad.squadId, 'system.permission.resolved', 'Permission allow', {
      agentId: 'paseo-agent-a', requestId: 'request-1', decision: 'allow', decidedBy: 'user',
    })
    expect(event).toMatchObject({ number: 1, author: 'system', kind: 'system.permission.resolved' })
    expect(await service.read(squad.squadId, 'agent-a')).toMatchObject([{ number: 1, author: 'system' }])
  })

  it('reconciles per-recipient replies and requires a leader acknowledgement after the result', async () => {
    const service = setup()
    const squad = await service.create({ leaderId: 'leader', memberIds: ['worker'] })
    await service.append(squad.squadId, 'leader', { kind: 'instruction', description: 'Build it', to: ['worker'] })
    expect(await service.reconcile(squad.squadId, 'worker')).toMatchObject([{ number: 1, state: 'awaiting_ack' }])
    await service.append(squad.squadId, 'worker', { kind: 'information', description: 'Started', replyTo: 1, response: 'ack' })
    expect(await service.reconcile(squad.squadId, 'worker')).toMatchObject([{ number: 1, state: 'acknowledged' }])
    const result = await service.append(squad.squadId, 'worker', { kind: 'information', description: 'Done', replyTo: 1, response: 'result' })
    expect(await service.reconcile(squad.squadId, 'worker')).toMatchObject([{ number: 1, state: 'awaiting_leader_ack', result: { number: result.number } }])
    await service.append(squad.squadId, 'leader', { kind: 'information', description: 'Accepted', replyTo: result.number, response: 'ack' })
    expect(await service.reconcile(squad.squadId, 'worker')).toMatchObject([{ number: 1, state: 'completed' }])
  })

  it('allows only the current leader to promote manually or nudge a member', async () => {
    const service = setup()
    const squad = await service.create({ leaderId: 'leader-a', memberIds: ['leader-b'] })
    await expect(service.promoteLeader(squad.squadId, 'leader-b', 'leader-a')).rejects.toThrow('Only the current Squad leader')
    const promoted = await service.promoteLeader(squad.squadId, 'leader-a', 'leader-b')
    expect(promoted).toMatchObject({ leaderId: 'leader-b', members: { 'leader-b': { role: 'leader' }, 'leader-a': { role: 'member' } } })
    expect(await service.read(squad.squadId, 'leader-a')).toMatchObject([{ kind: 'system.leader.promoted', number: 1 }])
    await expect(service.nudgeMember(squad.squadId, 'leader-a', 'leader-b')).rejects.toThrow('Only the current Squad leader')
    const nudge = await service.nudgeMember(squad.squadId, 'leader-b', 'leader-a')
    expect(nudge).toMatchObject({ number: 2, kind: 'instruction', to: ['leader-a'], inject: true })
  })

  it('keeps B and C reply state distinct and prevents a member replying for another recipient', async () => {
    const service = setup()
    const squad = await service.create({ leaderId: 'leader', memberIds: ['worker-b', 'worker-c'] })
    await service.append(squad.squadId, 'leader', {
      kind: 'instruction', description: 'Separate reviews', to: ['worker-b', 'worker-c'],
    })
    await service.append(squad.squadId, 'worker-b', {
      kind: 'information', description: 'B received it', replyTo: 1, response: 'ack',
    })
    const bOnlyInstruction = await service.append(squad.squadId, 'leader', {
      kind: 'instruction', description: 'Only B should work this one', to: ['worker-b'],
    })
    await expect(service.append(squad.squadId, 'worker-c', {
      kind: 'information', description: 'Pretend B is done', replyTo: bOnlyInstruction.number, response: 'result',
    })).rejects.toThrow('was not a recipient')
    await service.append(squad.squadId, 'worker-c', {
      kind: 'information', description: 'C is working', replyTo: 1, response: 'status',
    })
    const bState = await service.reconcile(squad.squadId, 'worker-b')
    const cState = await service.reconcile(squad.squadId, 'worker-c')
    expect(bState[0].state).toBe('acknowledged')
    expect(cState[0].state).toBe('in_progress')
    expect(bState[0].replies.map((reply) => reply.author)).toEqual(['worker-b'])
    expect(cState[0].replies.map((reply) => reply.author)).toEqual(['worker-c'])
  })
})
