import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { SquadService } from './squad-service.js'
import { connectedAgentIds } from './squad-canvas.js'
import { deliverSquadEntry } from './squad-delivery.js'
import { materializeFromText, serializeEvent } from '../canvas/materializer.js'

let root, filePath, service
const widget = (id, type = 'agent') => ({ id, type, position: { x: id.length * 100, y: 100 }, props: { width: 500, height: 300 } })
const connector = (id, from, to) => ({ id, type: 'connector', start: { widgetId: from, anchor: 'bottom' }, end: { widgetId: to, anchor: 'top' }, meta: {} })
function write(widgets, connectors = []) {
  fs.writeFileSync(filePath, serializeEvent({ event: 'canvas_created', widgets, connectors }) + '\n')
}
function append(event) { fs.appendFileSync(filePath, serializeEvent(event) + '\n') }
function canvas() { return materializeFromText(fs.readFileSync(filePath, 'utf8')) }
beforeEach(() => {
  root = fs.mkdtempSync(path.join(os.tmpdir(), 'squad-broadcast-'))
  fs.mkdirSync(path.join(root, 'canvas'))
  filePath = path.join(root, 'canvas', 'welcome.canvas.jsonl')
  service = new SquadService({ root, workspaceId: 'notebook', daemonId: 'daemon' })
})
afterEach(() => fs.rmSync(root, { recursive: true, force: true }))

describe('Canvas Squad relationship mode', () => {
  it('creates visible peer wiring once, preserves identity through concurrent toggles and gates off-mode work', async () => {
    write([widget('leader'), widget('peer-a'), widget('peer-b'), widget('doc', 'markdown')])
    const squad = await service.create({ canvasId: 'welcome', leaderId: 'leader', memberIds: ['peer-a', 'peer-b'] })
    expect(canvas().connectors).toHaveLength(2)
    expect(connectedAgentIds(canvas(), 'leader')).toEqual(['leader', 'peer-a', 'peer-b'])
    const initial = await service.append(squad.squadId, 'leader', { kind: 'instruction', description: 'Build', to: ['peer-a'] })
    const off = await service.setBroadcast('welcome', 'peer-a', false, squad.squadId)
    expect(off.broadcast.enabled).toBe(false)
    expect((await service.list('leader'))[0].activeMemberIds).toEqual([])
    expect(canvas().connectors).toHaveLength(2)
    await expect(service.append(squad.squadId, 'leader', { kind: 'instruction', description: 'Must not route', to: ['peer-a'] })).rejects.toThrow('Broadcast is off')
    await expect(service.nudgeMember(squad.squadId, 'leader', 'peer-a')).rejects.toThrow('Broadcast is off')
    expect(await service.reconcile(squad.squadId, 'peer-a')).toEqual([])
    expect((await service.read(squad.squadId, 'peer-a'))[0].number).toBe(initial.number)
    const again = new SquadService({ root, workspaceId: 'notebook', daemonId: 'daemon' })
    const enabled = await Promise.all([service.setBroadcast('welcome', 'leader', true), again.setBroadcast('welcome', 'peer-a', true)])
    expect(enabled.map((room) => room.squadId)).toEqual([squad.squadId, squad.squadId])
    const recreated = await again.create({ canvasId: 'welcome', leaderId: 'leader', memberIds: ['peer-b', 'peer-a'] })
    expect(recreated.squadId).toBe(squad.squadId)
    expect(canvas().connectors).toHaveLength(2)
    expect(await again.list('leader')).toHaveLength(1)
    expect((await again.read(squad.squadId, 'leader'))).toHaveLength(1)
  })

  it('keeps ordinary links passive, excludes document bridges and stops communication when disconnected', async () => {
    write([widget('leader'), widget('peer'), widget('outsider'), widget('doc', 'markdown')], [
      connector('agent-link', 'leader', 'peer'), connector('doc-link', 'leader', 'doc'), connector('bridge', 'doc', 'outsider'),
    ])
    expect(await service.list('leader')).toEqual([])
    const room = await service.setBroadcast('welcome', 'leader', true)
    expect(Object.keys(room.members).sort()).toEqual(['leader', 'peer'])
    expect(await service.list('outsider')).toEqual([])
    await expect(service.setBroadcast('welcome', 'outsider', false, room.squadId)).rejects.toThrow('Only a Squad member')
    append({ event: 'connector_removed', connectorId: 'agent-link' })
    await expect(service.append(room.squadId, 'leader', { kind: 'instruction', description: 'No route', to: ['peer'] })).rejects.toThrow('no longer connected')
    expect((await service.list('peer'))[0].activeMemberIds).toEqual(['leader'])
    // The disconnected peer cannot accidentally create an overlapping new room.
    await expect(service.setBroadcast('welcome', 'peer', true)).rejects.toThrow('Connect another agent')
    append({ event: 'connector_added', connector: connector('reconnect', 'peer', 'leader') })
    expect((await service.list('peer'))[0].activeMemberIds).toEqual(['leader', 'peer'])
  })

  it('checks relationship mode again before writing queued input and retries the same ledger entry', async () => {
    write([widget('leader'), widget('peer')])
    const room = await service.create({ canvasId: 'welcome', leaderId: 'leader', memberIds: ['peer'] })
    const entry = await service.append(room.squadId, 'leader', { kind: 'instruction', description: 'Review', to: ['peer'], inject: true })
    const submit = vi.fn(async () => ({ accepted: true, submitted: true }))
    const cancelled = await deliverSquadEntry(service, room.squadId, entry, {
      sessionFor: async () => { await service.setBroadcast('welcome', 'leader', false, room.squadId); return 'session-peer' },
      isReady: () => true, submitTerminalText: submit,
    })
    expect(cancelled).toMatchObject([{ recipient: 'peer', status: 'failed' }])
    expect(submit).not.toHaveBeenCalled()
    await service.setBroadcast('welcome', 'leader', true, room.squadId)
    const retried = await deliverSquadEntry(service, room.squadId, entry, {
      sessionFor: async () => 'session-peer', isReady: () => true, submitTerminalText: submit,
    })
    expect(retried).toMatchObject([{ recipient: 'peer', status: 'submitted' }])
    expect(submit).toHaveBeenCalledTimes(1)
    expect((await service.read(room.squadId, 'leader')).filter((item) => item.kind === 'instruction')).toHaveLength(1)
  })

  it('enables a chain without adding a new star, and reuses its room after a topology change', async () => {
    write(['leader', 'peer-a', 'peer-b'].map((id) => widget(id)), [
      connector('first', 'leader', 'peer-a'), connector('second', 'peer-a', 'peer-b'),
    ])
    const room = await service.setBroadcast('welcome', 'leader', true)
    expect(canvas().connectors).toHaveLength(2)
    await service.setBroadcast('welcome', 'leader', false, room.squadId)
    append({ event: 'connector_removed', connectorId: 'second' })
    const enabled = await service.setBroadcast('welcome', 'peer-a', true)
    expect(enabled.squadId).toBe(room.squadId)
    expect((await service.list('leader'))[0].activeMemberIds).toEqual(['leader', 'peer-a'])
    expect(await service.list('leader')).toHaveLength(1)
  })

  it('validates returned widget IDs before creating a room or wiring and never joins another canvas', async () => {
    write([widget('leader'), widget('peer')])
    const before = fs.readFileSync(filePath, 'utf8')
    await expect(service.create({ canvasId: 'welcome', leaderId: 'leader', memberIds: ['invented-peer'] })).rejects.toThrow('existing agent widget')
    expect(fs.readFileSync(filePath, 'utf8')).toBe(before)
    expect(await service.list('leader')).toEqual([])
    await expect(service.setBroadcast('../welcome', 'leader', true)).rejects.toThrow('not found')
    await expect(service.setBroadcast('welcome', 'leader', true)).rejects.toThrow('Connect another agent')
    write([widget('leader'), widget('peer'), { ...widget('invalid'), position: { x: 'bad', y: 100 } }])
    const invalid = fs.readFileSync(filePath, 'utf8')
    await expect(service.create({ canvasId: 'welcome', leaderId: 'leader', memberIds: ['peer', 'invalid'] })).rejects.toThrow('invalid canvas geometry')
    expect(fs.readFileSync(filePath, 'utf8')).toBe(invalid)
  })

  it('expands one active group only on explicit enable and refuses to merge active room histories', async () => {
    write(['leader', 'peer', 'other-leader', 'other-peer'].map((id) => widget(id)))
    const first = await service.create({ canvasId: 'welcome', leaderId: 'leader', memberIds: ['peer'] })
    const second = await service.create({ canvasId: 'welcome', leaderId: 'other-leader', memberIds: ['other-peer'] })
    append({ event: 'connector_added', connector: connector('join', 'peer', 'other-peer') })
    await expect(service.setBroadcast('welcome', 'leader', true, first.squadId)).rejects.toThrow('another active Squad')
    const before = fs.readFileSync(filePath, 'utf8')
    await expect(service.create({ canvasId: 'welcome', leaderId: 'leader', memberIds: ['other-peer'] })).rejects.toThrow('another active Squad')
    expect(fs.readFileSync(filePath, 'utf8')).toBe(before)
    await service.setBroadcast('welcome', 'other-leader', false, second.squadId)
    const combined = await service.setBroadcast('welcome', 'leader', true, first.squadId)
    expect(combined.squadId).toBe(first.squadId)
    expect(Object.keys(combined.members)).toHaveLength(4)
    expect((await service.list('other-peer')).find((room) => room.squadId === second.squadId).broadcast.enabled).toBe(false)
  })

  it('requires each peer result and leader acknowledgement before showing the group complete', async () => {
    write(['leader', 'peer-a', 'peer-b'].map((id) => widget(id)))
    const room = await service.create({ canvasId: 'welcome', leaderId: 'leader', memberIds: ['peer-a', 'peer-b'] })
    const assignment = await service.append(room.squadId, 'leader', { kind: 'instruction', description: 'Review', to: ['peer-a', 'peer-b'] })
    for (const peer of ['peer-a', 'peer-b']) {
      await service.append(room.squadId, peer, { kind: 'information', description: 'Waiting', replyTo: assignment.number, response: 'blocked' })
      await service.append(room.squadId, peer, { kind: 'information', description: 'Received', replyTo: assignment.number, response: 'ack' })
      const result = await service.append(room.squadId, peer, { kind: 'information', description: 'Done', replyTo: assignment.number, response: 'result' })
      await expect(service.append(room.squadId, peer, { kind: 'information', description: 'Self approval', replyTo: result.number, response: 'ack' })).rejects.toThrow('Only the current Squad leader')
      await service.append(room.squadId, 'leader', { kind: 'information', description: 'Accepted', replyTo: result.number, response: 'ack' })
    }
    expect(await service.reconcile(room.squadId, 'leader')).toMatchObject([
      { recipient: 'peer-a', state: 'completed' }, { recipient: 'peer-b', state: 'completed' },
    ])
  })
})
