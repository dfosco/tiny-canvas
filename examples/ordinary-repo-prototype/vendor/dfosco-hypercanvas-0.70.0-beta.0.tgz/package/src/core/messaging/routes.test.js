import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { initBus, resetBus } from './bus.js'
import { createMessagingRoutes } from './routes.js'
import { JsonlAdapter } from './storage/jsonl-adapter.js'

function responseRecorder() {
  return {
    status: null,
    headers: null,
    body: '',
    writeHead(status, headers) { this.status = status; this.headers = headers },
    end(body = '') { this.body += body },
  }
}

function sendJson(res, status, value) {
  res.writeHead(status, { 'Content-Type': 'application/json' })
  res.end(JSON.stringify(value))
}

let root
beforeEach(async () => {
  resetBus()
  root = fs.mkdtempSync(path.join(os.tmpdir(), 'squad-routes-'))
  const adapter = new JsonlAdapter({ root })
  await adapter.init()
  initBus(adapter)
})
afterEach(() => {
  resetBus()
  fs.rmSync(root, { recursive: true, force: true })
})

describe('Squad and generic messaging HTTP routes', () => {
  it('does not expose legacy Hub, presence, inbox, or direct-message routes', async () => {
    const route = createMessagingRoutes({ sendJson })
    for (const [method, routePath] of [
      ['GET', '/hub/context?widgetId=agent'],
      ['GET', '/hub/canvas'],
      ['POST', '/hub/dissolve'],
      ['GET', '/presence'],
      ['GET', '/inbox/read?widgetId=agent'],
      ['POST', '/message/send'],
      ['POST', '/request/send'],
    ]) {
      const req = { method, headers: { accept: 'application/json', 'content-type': 'application/json' } }
      const res = responseRecorder()
      await route(req, res, { method, path: routePath })
      expect(res.status, `${method} ${routePath}`).toBe(404)
    }
  })

  it('creates and operates a numbered Squad through matching Core routes', async () => {
    const submitted = []
    let ready = true
    const squadRoute = createMessagingRoutes({
      sendJson,
      getSquadContext: async () => ({ root, workspaceId: 'notebook', daemonId: 'paseo' }),
      getSquadDeliveryOptions: async () => ({
        sessionFor: async () => 'reviewer-session',
        isReady: () => ready,
        submitTerminalText: async (sessionId, text, options) => {
          submitted.push({ sessionId, text, options })
          return { accepted: true, submitted: true }
        },
      }),
    })
    async function invokeSquad(method, routePath, body) {
      const req = { method, headers: { accept: 'application/json', 'content-type': 'application/json' } }
      const res = responseRecorder()
      await squadRoute(req, res, { method, path: routePath, body: body === undefined ? undefined : JSON.stringify(body) })
      return { status: res.status, data: JSON.parse(res.body) }
    }

    const created = await invokeSquad('POST', '/squads', { widgetId: 'leader', memberIds: ['reviewer'], name: 'Review' })
    expect(created.status).toBe(201)
    const squadId = created.data.squad.squadId
    const appended = await invokeSquad('POST', `/squad/${squadId}/entry?widgetId=leader`, {
      kind: 'instruction', description: 'Review parser', to: ['reviewer'], inject: true,
    })
    expect(appended).toMatchObject({ status: 201, data: { entry: { number: 1, author: 'leader' }, delivery: [{ status: 'submitted' }] } })
    expect(submitted).toHaveLength(1)
    expect(submitted[0]).toMatchObject({
      sessionId: 'reviewer-session',
      text: 'Review parser\n\nSquad ledger reference:\n{\n  "squadId": "' + squadId + '",\n  "number": 1\n}',
      options: { submit: true, paste: true },
    })
    const reply = await invokeSquad('POST', `/squad/${squadId}/entry?widgetId=reviewer`, {
      kind: 'information', description: 'Done', replyTo: 1, response: 'result',
    })
    expect(reply.data.entry).toMatchObject({ number: 4, replyTo: 1, author: 'reviewer' })
    expect((await invokeSquad('GET', `/squad/${squadId}/room?widgetId=leader&after=1`)).data.entries)
      .toMatchObject([{ number: 2, kind: 'system.delivery.attempt' }, { number: 3, kind: 'system.delivery.attempt' }, { number: 4 }])
    expect((await invokeSquad('GET', `/squad/${squadId}/entry/1?widgetId=leader`)).data.entry.number).toBe(1)
    expect((await invokeSquad('GET', `/squad/${squadId}/room?widgetId=intruder`)).status).toBe(403)
    const concurrent = await Promise.all(Array.from({ length: 12 }, (_, index) => invokeSquad(
      'POST', `/squad/${squadId}/entry?widgetId=leader`, { kind: 'information', description: `parallel ${index}` },
    )))
    expect(concurrent.map((result) => result.data.entry.number).sort((a, b) => a - b))
      .toEqual(Array.from({ length: 12 }, (_, index) => index + 5))

    ready = false
    const failed = await invokeSquad('POST', `/squad/${squadId}/entry?widgetId=leader`, {
      kind: 'instruction', description: 'Review retry path', to: ['reviewer'], inject: true,
    })
    expect(failed.data.delivery).toMatchObject([{ status: 'failed' }])
    const committedNumber = failed.data.entry.number
    ready = true
    const retried = await invokeSquad('POST', `/squad/${squadId}/entry/${committedNumber}/deliver?widgetId=leader`, { force: false })
    expect(retried.data).toMatchObject({ entry: { number: committedNumber }, delivery: [{ status: 'submitted' }] })
    expect((await invokeSquad('GET', `/squad/${squadId}/entry/${committedNumber}?widgetId=leader`)).data.entry.number)
      .toBe(committedNumber)
    await expect(invokeSquad('POST', `/squad/${squadId}/entry/${committedNumber}/deliver?widgetId=leader`, { force: false }))
      .resolves.toMatchObject({ status: 409 })
  })

  it('does not inject entries when injection is omitted or explicitly false', async () => {
    const deliveryOptions = vi.fn(async () => ({}))
    const squadRoute = createMessagingRoutes({
      sendJson,
      getSquadContext: async () => ({ root, workspaceId: 'notebook', daemonId: 'paseo' }),
      getSquadDeliveryOptions: deliveryOptions,
    })
    async function invoke(method, routePath, body) {
      const req = { method, headers: { accept: 'application/json', 'content-type': 'application/json' } }
      const res = responseRecorder()
      await squadRoute(req, res, { method, path: routePath, body: JSON.stringify(body) })
      return { status: res.status, data: JSON.parse(res.body) }
    }
    const created = await invoke('POST', '/squads', { widgetId: 'leader', memberIds: ['member'] })
    const squadId = created.data.squad.squadId
    const passive = await invoke('POST', `/squad/${squadId}/entry?widgetId=leader`, {
      kind: 'information', description: 'Visible to the room', to: ['member'],
    })
    const explicitFalse = await invoke('POST', `/squad/${squadId}/entry?widgetId=leader`, {
      kind: 'instruction', description: 'Ledger only', to: ['member'], inject: false,
    })
    expect(passive.data).toMatchObject({ entry: { number: 1 }, delivery: [] })
    expect(explicitFalse.data).toMatchObject({ entry: { number: 2, inject: false }, delivery: [] })
    expect(deliveryOptions).not.toHaveBeenCalled()
  })

  it('exposes manual leader promotion and targeted nudge through Core routes', async () => {
    const submitted = []
    const squadRoute = createMessagingRoutes({
      sendJson,
      getSquadContext: async () => ({ root, workspaceId: 'notebook', daemonId: 'paseo' }),
      getSquadDeliveryOptions: async () => ({
        sessionFor: async (widgetId) => `${widgetId}-session`,
        isReady: () => true,
        submitTerminalText: async (_sessionId, text) => { submitted.push(text); return { accepted: true, submitted: true } },
      }),
    })
    async function invoke(method, routePath, body) {
      const req = { method, headers: { accept: 'application/json', 'content-type': 'application/json' } }
      const res = responseRecorder()
      await squadRoute(req, res, { method, path: routePath, body: JSON.stringify(body || {}) })
      return { status: res.status, data: JSON.parse(res.body) }
    }
    const created = await invoke('POST', '/squads', { widgetId: 'leader-a', memberIds: ['leader-b'] })
    const squadId = created.data.squad.squadId
    const promoted = await invoke('POST', `/squad/${squadId}/leader?widgetId=leader-a`, { targetWidgetId: 'leader-b' })
    expect(promoted.data.squad.leaderId).toBe('leader-b')
    expect((await invoke('POST', `/squad/${squadId}/nudge?widgetId=leader-a`, { targetWidgetId: 'leader-a' })).status).toBe(403)
    const nudge = await invoke('POST', `/squad/${squadId}/nudge?widgetId=leader-b`, { targetWidgetId: 'leader-a' })
    expect(nudge).toMatchObject({ status: 201, data: { entry: { number: 2, to: ['leader-a'], inject: true }, delivery: [{ status: 'submitted' }] } })
    expect(submitted[0]).toContain(`"squadId": "${squadId}"`)
  })
})
