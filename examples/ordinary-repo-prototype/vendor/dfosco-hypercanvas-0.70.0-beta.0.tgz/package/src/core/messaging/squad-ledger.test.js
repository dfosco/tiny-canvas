import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { SquadLedger, validateSquadMessage } from './squad-ledger.js'

const roots = []
function setup(now) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'squad-ledger-'))
  roots.push(root)
  return { root, ledger: new SquadLedger({ root, now }) }
}

afterEach(() => {
  for (const root of roots.splice(0)) fs.rmSync(root, { recursive: true, force: true })
})

describe('validateSquadMessage', () => {
  it('accepts minimal messages and raw JSON attachments', () => {
    expect(validateSquadMessage({
      kind: 'instruction', description: 'Review parser', to: ['agent-b'], inject: true,
      attachments: ['Focus on malformed input', { checks: ['empty'] }], files: ['reviews/parser.patch'],
    })).toEqual({ valid: true, errors: [] })
  })

  it('rejects writer metadata, unsafe paths, invalid replies, and injection without recipients', () => {
    expect(validateSquadMessage({ kind: 'information', description: 'Hi', number: 8 }).valid).toBe(false)
    expect(validateSquadMessage({ kind: 'instruction', description: 'Do', files: ['../secret'] }).valid).toBe(false)
    expect(validateSquadMessage({ kind: 'information', description: 'Hi', response: 'result' }).valid).toBe(false)
    expect(validateSquadMessage({ kind: 'information', description: 'Hi', inject: true }).valid).toBe(false)
  })
})

describe('SquadLedger', () => {
  it('serializes concurrent appends, assigns metadata, and restores numbering on restart', async () => {
    const { root } = setup(() => new Date('2026-10-02T14:00:00.000Z'))
    const entries = await Promise.all(Array.from({ length: 32 }, (_, index) => new SquadLedger({ root, now: () => new Date('2026-10-02T14:00:00.000Z') }).append('alpha', `agent-${index}`, {
      kind: 'information', description: `turn ${index}`,
    })))
    expect(entries.map((entry) => entry.number).sort((a, b) => a - b)).toEqual(Array.from({ length: 32 }, (_, i) => i + 1))
    expect(entries[0]).toMatchObject({ number: 1, timestamp: '2026-10-02T14:00:00.000Z', author: 'agent-0' })
    const restarted = new SquadLedger({ root })
    expect((await restarted.append('alpha', 'agent-next', { kind: 'information', description: 'after restart' })).number).toBe(33)
  })

  it('orders by append, not timestamp, and refuses corrupt or incomplete tails', async () => {
    const { root, ledger } = setup(() => new Date('2026-10-02T14:00:00.000Z'))
    await ledger.append('alpha', 'agent-a', { kind: 'information', description: 'first' })
    const filePath = path.join(root, '.hypercanvas/squads/alpha/room.jsonl')
    fs.appendFileSync(filePath, '{broken\n')
    await expect(ledger.append('alpha', 'agent-b', { kind: 'information', description: 'second' }))
      .rejects.toThrow('invalid JSON at line 2')
    fs.writeFileSync(filePath, `${JSON.stringify({ number: 1, timestamp: 'later', author: 'agent-a', kind: 'information', description: 'first' })}\npartial`)
    await expect(ledger.read('alpha')).rejects.toThrow('incomplete final line')
  })

  it('rejects replayed JSON values that are not valid numbered entries', async () => {
    const { root, ledger } = setup()
    const filePath = path.join(root, '.hypercanvas/squads/alpha/room.jsonl')
    fs.mkdirSync(path.dirname(filePath), { recursive: true })
    fs.writeFileSync(filePath, `${JSON.stringify(null)}\n`)

    await expect(ledger.read('alpha')).rejects.toThrow('numbering is invalid at line 1')
    fs.writeFileSync(filePath, `${JSON.stringify({
      number: 1,
      timestamp: '2026-10-02T14:00:00.000Z',
      author: 'agent-a',
      kind: 'instruction',
      description: '',
    })}\n`)
    await expect(ledger.append('alpha', 'agent-b', { kind: 'information', description: 'next' }))
      .rejects.toThrow('entry is invalid at line 1')
  })

  it('looks up stable numbered replies and filtered reads', async () => {
    const { ledger } = setup()
    await ledger.append('alpha', 'agent-a', { kind: 'instruction', description: 'Review' })
    await ledger.append('alpha', 'agent-b', { kind: 'information', description: 'Done', replyTo: 1, response: 'result' })
    expect(await ledger.get('alpha', 1)).toMatchObject({ number: 1, author: 'agent-a' })
    expect(await ledger.read('alpha', { after: 1 })).toMatchObject([{ number: 2, replyTo: 1 }])
  })

  it('assigns numbers to Core-authored system events without allowing client system kinds', async () => {
    const { ledger } = setup()
    const event = await ledger.appendSystem('alpha', 'system.permission.requested', 'Agent requested permission', {
      agentId: 'agent-a', requestId: 'request-1',
    })
    expect(event).toMatchObject({ number: 1, author: 'system', kind: 'system.permission.requested' })
    await expect(ledger.append('alpha', 'agent-a', {
      kind: 'system.permission.resolved', description: 'Allow it',
    })).rejects.toThrow('kind must be information or instruction')
  })
})
