import { describe, expect, it, vi } from 'vitest'
import { deliverSquadEntry, formatSquadInjection } from './squad-delivery.js'

function deliveryService(events = []) {
  return {
    events,
    async read() { return [...events] },
    async getAgentBinding() { return null },
    async appendSystemEvent(_squadId, kind, description, data) {
      events.push({ number: events.length + 1, kind, description, data })
    },
  }
}

describe('Squad attention delivery', () => {
  it('formats exactly the plaintext description plus the committed ledger reference', () => {
    expect(formatSquadInjection('squad-a', { number: 17, description: 'Review parser' }))
      .toBe('Review parser\n\nSquad ledger reference:\n{\n  "squadId": "squad-a",\n  "number": 17\n}')
  })

  it('submits the existing numbered entry once and does not duplicate successful delivery', async () => {
    const service = deliveryService()
    const submitTerminalText = vi.fn().mockResolvedValue({ accepted: true, submitted: true })
    const entry = { number: 3, author: 'leader', kind: 'instruction', description: 'Do work', to: ['agent-a'] }
    const options = { sessionFor: async () => 'session-a', isReady: () => true, submitTerminalText }
    await expect(deliverSquadEntry(service, 'squad-a', entry, options)).resolves.toMatchObject([{ status: 'submitted' }])
    await expect(deliverSquadEntry(service, 'squad-a', entry, options)).resolves.toMatchObject([{ status: 'already_submitted' }])
    expect(submitTerminalText).toHaveBeenCalledOnce()
    expect(submitTerminalText.mock.calls[0][1]).toContain('"number": 3')
    expect(service.events.map((event) => event.data.state)).toEqual(['pending', 'submitted'])
  })

  it('serializes concurrent retries for the same recipient and ledger number', async () => {
    const service = deliveryService()
    let release
    const gate = new Promise((resolve) => { release = resolve })
    const submitTerminalText = vi.fn(async () => {
      await gate
      return { accepted: true, submitted: true }
    })
    const entry = { number: 31, author: 'leader', kind: 'instruction', description: 'Do work', to: ['agent-a'] }
    const options = { sessionFor: async () => 'session-a', isReady: () => true, submitTerminalText }
    const first = deliverSquadEntry(service, 'squad-concurrent', entry, options)
    await Promise.resolve()
    const second = deliverSquadEntry(service, 'squad-concurrent', entry, options)
    release()
    const [firstResult, secondResult] = await Promise.all([first, second])
    expect(submitTerminalText).toHaveBeenCalledOnce()
    expect([firstResult[0].status, secondResult[0].status]).toContain('submitted')
    expect([firstResult[0].status, secondResult[0].status]).toContain('indeterminate')
  })

  it('recovers a known readiness failure against the same entry number', async () => {
    const service = deliveryService()
    let ready = false
    const submitTerminalText = vi.fn().mockResolvedValue({ accepted: true, submitted: true })
    const entry = { number: 8, author: 'leader', kind: 'instruction', description: 'Review', to: ['agent-a'] }
    const options = { sessionFor: async () => 'session-a', isReady: () => ready, submitTerminalText }
    await expect(deliverSquadEntry(service, 'squad-a', entry, options)).resolves.toMatchObject([{ status: 'failed' }])
    ready = true
    await expect(deliverSquadEntry(service, 'squad-a', entry, options)).resolves.toMatchObject([{ status: 'submitted' }])
    expect(submitTerminalText).toHaveBeenCalledOnce()
    expect(service.events.map((event) => event.data.number)).toEqual([8, 8, 8, 8])
  })

  it('does not silently resend an uncertain prior attempt; explicit force reuses its number', async () => {
    const events = [{ kind: 'system.delivery.attempt', data: { number: 9, recipient: 'agent-a', state: 'pending' } }]
    const service = deliveryService(events)
    const submitTerminalText = vi.fn().mockResolvedValue({ accepted: true, submitted: true })
    const entry = { number: 9, author: 'leader', kind: 'instruction', description: 'Review', to: ['agent-a'] }
    const options = { sessionFor: async () => 'session-a', isReady: () => true, submitTerminalText }
    await expect(deliverSquadEntry(service, 'squad-a', entry, options)).resolves.toMatchObject([{ status: 'indeterminate' }])
    expect(submitTerminalText).not.toHaveBeenCalled()
    await expect(deliverSquadEntry(service, 'squad-a', entry, { ...options, force: true }))
      .resolves.toMatchObject([{ status: 'submitted' }])
    expect(submitTerminalText).toHaveBeenCalledOnce()
    expect(submitTerminalText.mock.calls[0][1]).toContain('"number": 9')
  })

  it('does not inject passive entries without recipients', async () => {
    const service = deliveryService()
    const submitTerminalText = vi.fn()
    await expect(deliverSquadEntry(service, 'squad-a', {
      number: 1, author: 'leader', kind: 'information', description: 'Room note',
    }, { submitTerminalText })).resolves.toEqual([])
    expect(submitTerminalText).not.toHaveBeenCalled()
  })
})
